# Data Description

## Main WWTP Dataset

The main dataset is stored as one-minute multivariate process data.

- Raw file: `data/raw/device_data_wide_final_1min1.csv`
- Processed file: `data/processed/device_data_wide_final_1min1_filtered_ffill.csv`
- Chronological split metadata: `data/splits/main_chronological_split.csv`

The processed file was used in the main experiments. It contains the following columns:

```text
sample_time, In_Water, In_COD, In_AN, Main_AirV, N_On_DO, S_On_DO,
S_On_AN, N_CS, S_CS, Out_PH, Out_Water, Out_AN, Out_TN, Out_COD,
N_AddP_Sw, S_AddP_Sw, N1_MLRefP, N2_MLRefP, S1_MLRefP, S2_MLRefP,
Main_AirV_is_bad, Main_AirV_raw
```

`Main_AirV` is the forecasting target in the main dataset.

## Split Rule

The experiments use chronological splitting. The first 80% of source rows are used as the training source segment, and the remaining 20% are used as the test source segment before supervised window construction. Validation samples are split from the training segment inside the training routine.

## External Validation Dataset

The external validation dataset is from the DataFountain competition "Process Control of a Water Purification Plant: Aeration Volume Prediction". To reproduce the external validation experiment, place the downloaded file at:

```text
data/external/train_dataset.csv
```

The external script supports branch-specific targets via `--target-label label1` and `--target-label label2`.

## Data-Sharing Note

If the main WWTP operational data are subject to data-owner permission or operational confidentiality restrictions, remove `data/raw/` from the public release and retain the processed/anonymized data, split metadata, variable descriptions, and reproducibility scripts.

