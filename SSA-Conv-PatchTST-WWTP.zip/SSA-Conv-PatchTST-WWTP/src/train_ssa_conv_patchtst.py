# -*- coding: utf-8 -*-
"""
Single-model experiment script for TimeMixer / SSA-Conv-PatchTST.

This file keeps the user's chronological split / scaling / export workflow and
focuses on one production candidate at a time.
The feature-engineering branch supports several decomposition methods that can
be appended to the core process variables before model training:

- VMD
- CEEMDAN
- EWT
- WPD
- SSA
- STL
- MSTL

The decomposition is applied to the observed series before windowing, so this
remains an offline research script rather than a direct online deployment
recipe.
"""

import copy
import argparse
import gc
import importlib
import importlib.util
import math
import os
import random
import sys
import time
import types
import warnings
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import DataLoader, TensorDataset


# =========================
# 1. Paths and basic settings
# =========================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(SCRIPT_DIR)
INPUT_FILE = os.environ.get(
    "WWTP_INPUT_FILE",
    os.path.join(REPO_ROOT, "data", "processed", "device_data_wide_final_1min1_filtered_ffill.csv"),
)
OUTPUT_DIR = os.environ.get("WWTP_OUTPUT_DIR", os.path.join(REPO_ROOT, "results", "generated"))
TSLIB_ROOT = os.environ.get(
    "TSLIB_OFFICIAL_ROOT",
    r"C:\Users\71863\Documents\Playground\TSLib_official",
)
os.makedirs(OUTPUT_DIR, exist_ok=True)

if not os.path.isdir(TSLIB_ROOT):
    raise FileNotFoundError(
        f"TSLIB_OFFICIAL_ROOT not found: {TSLIB_ROOT}\n"
        "Set environment variable TSLIB_OFFICIAL_ROOT to your official TSLib path."
    )

if TSLIB_ROOT not in sys.path:
    sys.path.insert(0, TSLIB_ROOT)


def ensure_tslib_optional_dependencies() -> None:
    try:
        importlib.import_module("einops")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "Missing required dependency 'einops'. Install it in the same Python environment with:\n"
            r"D:\pc\pythonProject\.venv\Scripts\python.exe -m pip install einops"
        ) from exc

    if "reformer_pytorch" in sys.modules:
        return

    try:
        importlib.import_module("reformer_pytorch")
        return
    except ModuleNotFoundError:
        pass

    stub_module = types.ModuleType("reformer_pytorch")

    class LSHSelfAttention(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def forward(self, x, **kwargs):
            return x

    stub_module.LSHSelfAttention = LSHSelfAttention
    sys.modules["reformer_pytorch"] = stub_module


ensure_tslib_optional_dependencies()


TIME_COL = "sample_time"
TARGET_COL = "Main_AirV"
HORIZON_MINS = [30, 60, 90]
TRAIN_RATIO = 0.8
RANDOM_STATE = 7

SEQ_LEN = 180
LABEL_LEN = 60
PRED_LEN = max(HORIZON_MINS)
PATCH_LEN = 10

BATCH_SIZE = 64
EPOCHS = 100
PATIENCE = 10
LR = 1e-4
WEIGHT_DECAY = 1e-5
NUM_WORKERS = 0
PIN_MEMORY = torch.cuda.is_available()
USE_AMP = torch.cuda.is_available()

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

if torch.cuda.is_available():
    torch.backends.cudnn.benchmark = True

SSA_CONV_PATCHTST_PUBLIC_NAME = "SSA-Conv-PatchTST"
SSA_CONV_PATCHTST_KEYS = {SSA_CONV_PATCHTST_PUBLIC_NAME.lower()}

MODEL_NAME = SSA_CONV_PATCHTST_PUBLIC_NAME

BASE_FEATURE_COLS = [
    "In_Water",
    "In_COD",
    "In_AN",
    "N_On_DO",
    "S_On_DO",
    "Out_AN",
    "Out_TN",
    "Out_COD",
    "Main_AirV",  # target MUST be last
]

VMD_FEATURE_SOURCE_COLS = [
    "In_Water",
    "In_COD",
    "In_AN",
    "N_On_DO",
    "S_On_DO",
    "Out_AN",
    "Out_TN",
    "Out_COD",
    "Main_AirV",
]
DECOMP_METHOD = "vmd"
SUPPORTED_DECOMP_METHODS = ("vmd", "ceemdan", "ewt", "wpd", "ssa", "stl", "mstl")
DECOMP_DEFAULT_OUTPUT_TAG = "vmd"
DECOMP_NUM_COMPONENTS = 3
DECOMP_COMPONENT_MIN = 2
DECOMP_COMPONENT_MAX = 5
VMD_NUM_MODES = DECOMP_NUM_COMPONENTS
VMD_ALPHA = 2000.0
VMD_TAU = 0.0
VMD_DC = False
VMD_INIT = 1
VMD_TOL = 1e-6
VMD_MAX_ITERS = 250
CEEMDAN_TRIALS = 20
CEEMDAN_NOISE_WIDTH = 0.03
CEEMDAN_TRIAL_OPTIONS: Tuple[int, ...] = (10, 20, 30)
CEEMDAN_NOISE_OPTIONS: Tuple[float, ...] = (0.01, 0.03, 0.05)
EWT_MAX_BANDS = DECOMP_NUM_COMPONENTS
WPD_WAVELET = "db4"
WPD_MAX_LEVEL = 2
WPD_WAVELET_OPTIONS: Tuple[str, ...] = ("db2", "db4", "sym4", "coif1")
WPD_LEVEL_OPTIONS: Tuple[int, ...] = (2, 3, 4)
SSA_WINDOW = 60
SSA_WINDOW_OPTIONS: Tuple[int, ...] = (30, 60, 90, 120, 180)
SSA_FIXED_NUM_COMPONENTS = 4
SSA_FIXED_WINDOW = 120
SSA_SEARCH_MODE = "exact"
SSA_RERANK_TOPK = 6
SSA_RERANK_EPOCHS = 35
SSA_RERANK_PATIENCE = 5
STL_PERIOD = 1440
STL_PERIOD_OPTIONS: Tuple[int, ...] = (360, 720, 1440)
MSTL_PERIODS: Tuple[int, ...] = (1440, 10080)
MSTL_PERIOD_CANDIDATES: Tuple[Tuple[int, ...], ...] = (
    (360, 1440),
    (720, 1440),
    (1440, 10080),
)
WOA_POP_SIZE = 5
WOA_ITERS = 4
WOA_K_MIN = 2
WOA_K_MAX = 5
WOA_ALPHA_MIN = 500.0
WOA_ALPHA_MAX = 5000.0
WOA_PROXY_MAX_ROWS = 12000
DECOMP_SEARCH_MAX_CANDIDATES = 16
CEEMDAN_SEARCH_MAX_CANDIDATES = 3

EXTREME_TAIL_QUANTILE = 0.05
EXTREME_HORIZON_WEIGHTS = [1.75, 2.00, 2.25]
EXTREME_LOW_WEIGHTS = [1.15, 1.25, 1.35]
EXTREME_HIGH_WEIGHTS = [0.85, 0.75, 0.65]
DENSITY_NUM_BINS = 64
DENSITY_SMOOTH_SIGMA = 1.5
DENSITY_WEIGHT_BLEND = 0.35
DENSITY_WEIGHT_POWER = 0.5
FREEZE_TUNE_SOURCE_RATIO = 0.45
FREEZE_TUNE_STAGE1_RATIO = 0.30
FREEZE_TUNE_STAGE2_LR_SCALE = 0.25
ADAPTIVE_EXTREME_STRENGTH = 0.80
ADAPTIVE_DIRECTION_STRENGTH = 1.10
ADAPTIVE_DIRECTION_ERROR_POWER = 1.00
ADAPTIVE_HIGH_TAIL_SCALE = 0.90
ADAPTIVE_LOW_TAIL_SCALE = 1.00
ADAPTIVE_MAX_POINT_WEIGHT = 12.0
ASYM_EXTREME_STRENGTH = 0.90
ASYM_LOW_OVER_STRENGTH = 1.35
ASYM_HIGH_UNDER_STRENGTH = 1.55
ASYM_DIRECTION_ERROR_POWER = 1.00
ASYM_HIGH_TAIL_SCALE = 0.90
ASYM_LOW_TAIL_SCALE = 1.00
ASYM_TRANSITION_STRENGTH = 0.75
ASYM_MAX_POINT_WEIGHT = 16.0
ASYM_V2_EXTREME_STRENGTH = 1.00
ASYM_V2_LOW_OVER_STRENGTH = 1.45
ASYM_V2_HIGH_UNDER_STRENGTH = 1.90
ASYM_V2_DIRECTION_ERROR_POWER = 1.10
ASYM_V2_HIGH_TAIL_SCALE = 0.85
ASYM_V2_LOW_TAIL_SCALE = 1.00
ASYM_V2_TRANSITION_STRENGTH = 1.15
ASYM_V2_MAX_POINT_WEIGHT = 20.0
TRANSITION_TOP_QUANTILE = 0.90
EVENT_DELTA_LOSS_WEIGHT = 0.25
EVENT_BCE_LOSS_WEIGHT = 0.10
EVENT_TRANSITION_WEIGHT = 1.5
EVENT_TAIL_WEIGHT = 0.75
REFINE_BRANCH_HIDDEN = 128
REFINE_DELTA_LOSS_WEIGHT = 0.40
REFINE_EVENT_LOSS_WEIGHT = 0.08
REFINE_TRANSITION_WEIGHT = 1.75
ENGINEERING_LOW_THRESHOLDS = {30: None, 60: None, 90: None}
ENGINEERING_HIGH_THRESHOLDS = {30: None, 60: None, 90: None}
PLANT_NAME_CN = "达拉特旗污水处理厂"
PLANT_PROCESS_CN = "A2O + MBR + magnetic coagulation + ozone oxidation"
PLANT_DISCHARGE_STANDARD = "GB 18918-2002 Class 1A"
PLANT_REUSE_NOTE = "100% reclaimed water reuse to the industrial park"
FACTORY_DO_LOW = 2.0
FACTORY_DO_HIGH = 4.0
FACTORY_DO_CRITICAL_LOW = 1.0
FACTORY_DO_CRITICAL_HIGH = 6.0
FACTORY_PH_LOW = 6.0
FACTORY_PH_HIGH = 9.0
FACTORY_SONAN_WARNING = 2.0
FACTORY_SONAN_HIGH = 5.0
FACTORY_OUT_AN_WARNING = 4.0
FACTORY_OUT_AN_LIMIT = 5.0
FACTORY_OUT_TN_WARNING = 13.0
FACTORY_OUT_TN_LIMIT = 15.0
FACTORY_OUT_COD_WARNING = 45.0
FACTORY_OUT_COD_LIMIT = 50.0
FACTORY_REUSE_COD = FACTORY_OUT_COD_WARNING
FACTORY_REUSE_AN = FACTORY_OUT_AN_WARNING
FACTORY_REUSE_TN = FACTORY_OUT_TN_WARNING
FACTORY_SCENE_MIN_SAMPLES = 30
ABLATE_NO_SSA = False
ABLATE_NO_CONV = False
ABLATE_NO_ASYM = False
ABLATE_NO_DENSITY = False
ABLATE_NO_TRANSITION = False
USE_DENSITY_LOSS = False
UNIFORM_HORIZON_WEIGHT = float(np.mean(EXTREME_HORIZON_WEIGHTS))
UNIFORM_LOW_WEIGHT = float(np.mean(EXTREME_LOW_WEIGHTS))
UNIFORM_HIGH_WEIGHT = float(np.mean(EXTREME_HIGH_WEIGHTS))


# =========================
# 2. Hyperparameters
# =========================
@dataclass
class Config:
    task_name: str = "long_term_forecast"
    seq_len: int = SEQ_LEN
    label_len: int = LABEL_LEN
    pred_len: int = PRED_LEN
    patch_len: int = PATCH_LEN
    stride: int = PATCH_LEN

    d_model: int = 128
    d_ff: int = 128
    n_heads: int = 4
    e_layers: int = 2
    d_layers: int = 1
    dropout: float = 0.1
    activation: str = "gelu"
    factor: int = 3
    use_norm: bool = True

    enc_in: int = len(BASE_FEATURE_COLS)
    dec_in: int = len(BASE_FEATURE_COLS)
    c_out: int = len(BASE_FEATURE_COLS)
    features: str = "MS"
    embed: str = "timeF"
    freq: str = "t"

    moving_avg: int = 25
    top_k: int = 5
    num_kernels: int = 3
    num_class: int = 1
    individual: bool = False

    channel_independence: int = 1
    decomp_method: str = "moving_avg"
    down_sampling_layers: int = 3
    down_sampling_window: int = 2
    down_sampling_method: Optional[str] = "avg"

    kan_hidden_dim: int = 64
    kan_grid_size: int = 8
    kan_spline_order: int = 3
    kan_input_dropout: float = 0.05
    kan_grid_min: float = -4.0
    kan_grid_max: float = 4.0

    tcn_hidden_dim: int = 128
    tcn_num_layers: int = 4
    tcn_dropout: float = 0.1

    nbeats_hidden_dim: int = 256
    nbeats_num_blocks: int = 4
    nbeats_num_layers: int = 4
    nbeats_context_dim: int = 128
    nbeats_dropout: float = 0.1

    deepar_hidden_dim: int = 128
    deepar_dropout: float = 0.1
    deepar_horizon_embed_dim: int = 32

    multiscale_patch_lens: Tuple[int, ...] = (10, 30)
    conv_kernels: Tuple[int, ...] = (5, 9, 21)
    conv_stem_dropout: float = 0.05

    tcn_front_hidden: int = 64
    tcn_front_kernel: int = 7
    tcn_front_dilations: Tuple[int, ...] = (1, 2, 4)
    tcn_front_dropout: float = 0.03
    conv_deep_dilations: Tuple[int, ...] = (1, 2, 4)
    conv_deep_kernel: int = 5
    cnn_local_hidden: int = 16
    cnn_local_blocks: int = 4
    cnn_local_kernels: Tuple[int, ...] = (3, 7, 15)
    cnn_local_dropout: float = 0.08


class Transpose(nn.Module):
    def __init__(self, *dims, contiguous: bool = False):
        super().__init__()
        self.dims = dims
        self.contiguous = contiguous

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.contiguous:
            return x.transpose(*self.dims).contiguous()
        return x.transpose(*self.dims)


class FlattenHead(nn.Module):
    def __init__(self, n_vars: int, nf: int, target_window: int, head_dropout: float = 0.0):
        super().__init__()
        self.flatten = nn.Flatten(start_dim=-2)
        self.linear = nn.Linear(nf, target_window)
        self.dropout = nn.Dropout(head_dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.flatten(x)
        x = self.linear(x)
        return self.dropout(x)


class PatchTSTExtremeModel(nn.Module):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.horizon_indices = horizon_indices
        padding = stride

        self.patch_embedding = PatchEmbedding(
            configs.d_model, patch_len, stride, padding, configs.dropout
        )
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=False,
                        ),
                        configs.d_model,
                        configs.n_heads,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.Sequential(
                Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
            ),
        )

        self.head_nf = configs.d_model * int((configs.seq_len - patch_len) / stride + 2)
        self.base_head = FlattenHead(
            configs.enc_in, self.head_nf, configs.pred_len, head_dropout=configs.dropout
        )
        self.horizon_head = FlattenHead(
            configs.enc_in,
            self.head_nf,
            len(horizon_indices),
            head_dropout=configs.dropout,
        )
        self.horizon_gate = nn.Parameter(torch.zeros(len(horizon_indices)))

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]
        raise NotImplementedError("PatchTSTExtremeModel only supports forecasting tasks")


class LocalConvStem(nn.Module):
    def __init__(self, channels: int, kernels: Tuple[int, ...], dropout: float):
        super().__init__()
        self.branches = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv1d(
                        channels,
                        channels,
                        kernel_size=int(k),
                        padding=int(k) // 2,
                        groups=channels,
                        bias=False,
                    ),
                    nn.GELU(),
                )
                for k in kernels
            ]
        )
        self.fuse = nn.Sequential(
            nn.Conv1d(channels * len(kernels), channels, kernel_size=1, bias=False),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        # Channel-wise residual gating lets the stem amplify only the variables
        # whose local dynamics are actually helpful, instead of perturbing every
        # channel with the same global strength.
        self.gate = nn.Parameter(torch.zeros(1, channels, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        branch_outs = [branch(x) for branch in self.branches]
        fused = self.fuse(torch.cat(branch_outs, dim=1))
        gate = torch.sigmoid(self.gate)
        return residual + gate * fused


class LocalConvResidualBlock(nn.Module):
    def __init__(self, channels: int, kernel_size: int, dilation: int, dropout: float):
        super().__init__()
        padding = dilation * (kernel_size // 2)
        self.block = nn.Sequential(
            nn.Conv1d(
                channels,
                channels,
                kernel_size=kernel_size,
                padding=padding,
                dilation=dilation,
                groups=channels,
                bias=False,
            ),
            nn.Conv1d(channels, channels, kernel_size=1, bias=False),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(
                channels,
                channels,
                kernel_size=kernel_size,
                padding=padding,
                dilation=dilation,
                groups=channels,
                bias=False,
            ),
            nn.Conv1d(channels, channels, kernel_size=1, bias=False),
        )
        self.norm = nn.BatchNorm1d(channels)
        self.gate = nn.Parameter(torch.tensor(0.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        update = self.block(x)
        gate = torch.sigmoid(self.gate)
        out = residual + gate * update
        return self.norm(out)


class PatchTSTExtremeConvModel(PatchTSTExtremeModel):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__(configs=configs, patch_len=patch_len, stride=stride, horizon_indices=horizon_indices)
        self.local_stem = LocalConvStem(
            channels=configs.enc_in,
            kernels=tuple(int(v) for v in configs.conv_kernels),
            dropout=configs.conv_stem_dropout,
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        x_enc = self.local_stem(x_enc)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out


class PatchTSTExtremeConvTargetBranchModel(PatchTSTExtremeModel):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__(configs=configs, patch_len=patch_len, stride=stride, horizon_indices=horizon_indices)
        self.local_stem = LocalConvStem(
            channels=configs.enc_in,
            kernels=tuple(int(v) for v in configs.conv_kernels),
            dropout=configs.conv_stem_dropout,
        )
        self.target_feature_indices = [
            idx for idx, name in enumerate(BASE_FEATURE_COLS)
            if name in {"In_Water", "In_COD", "In_AN", "N_On_DO", "S_On_DO", "Main_AirV"}
        ]
        target_channels = max(1, len(self.target_feature_indices))
        self.target_local_stem = LocalConvStem(
            channels=target_channels,
            kernels=tuple(int(v) for v in configs.conv_kernels),
            dropout=configs.conv_stem_dropout,
        )
        self.target_mix_gate = nn.Parameter(torch.tensor(0.0))

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        full_feat = self.local_stem(x_enc)

        if self.target_feature_indices:
            target_x = x_enc[:, self.target_feature_indices, :]
            target_feat = self.target_local_stem(target_x)
            mixed = full_feat.clone()
            mix_gate = torch.sigmoid(self.target_mix_gate)
            mixed[:, self.target_feature_indices, :] = (
                full_feat[:, self.target_feature_indices, :]
                + mix_gate * (target_feat - target_x)
            )
            x_enc = mixed
        else:
            x_enc = full_feat

        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out


class CNNInceptionResidualBlock(nn.Module):
    def __init__(self, channels: int, kernels: Tuple[int, ...], dropout: float):
        super().__init__()
        branch_channels = max(channels // len(kernels), 8)
        self.pre = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=channels),
            nn.GELU(),
        )
        self.branches = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv1d(
                        channels,
                        branch_channels,
                        kernel_size=int(k),
                        padding=int(k) // 2,
                        bias=False,
                    ),
                    nn.GroupNorm(num_groups=1, num_channels=branch_channels),
                    nn.GELU(),
                )
                for k in kernels
            ]
        )
        fused_channels = branch_channels * len(kernels)
        self.post = nn.Sequential(
            nn.Conv1d(fused_channels, channels, kernel_size=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=channels),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=channels),
        )
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Conv1d(channels, max(channels // 4, 8), kernel_size=1),
            nn.GELU(),
            nn.Conv1d(max(channels // 4, 8), channels, kernel_size=1),
            nn.Sigmoid(),
        )
        self.gate = nn.Parameter(torch.tensor(0.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.pre(x)
        x = torch.cat([branch(x) for branch in self.branches], dim=1)
        x = self.post(x)
        x = x * self.se(x)
        gate = torch.sigmoid(self.gate)
        return F.gelu(residual + gate * x)


class LocalCNNEncoder(nn.Module):
    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        num_blocks: int,
        kernels: Tuple[int, ...],
        dropout: float,
    ):
        super().__init__()
        self.input_proj = nn.Sequential(
            nn.Conv1d(in_channels, hidden_channels, kernel_size=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=hidden_channels),
            nn.GELU(),
        )
        self.blocks = nn.ModuleList(
            [
                CNNInceptionResidualBlock(
                    channels=hidden_channels,
                    kernels=kernels,
                    dropout=dropout,
                )
                for _ in range(num_blocks)
            ]
        )
        self.output_proj = nn.Sequential(
            nn.Conv1d(hidden_channels, hidden_channels, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=hidden_channels),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(hidden_channels, in_channels, kernel_size=1, bias=False),
        )
        self.gate = nn.Parameter(torch.tensor(0.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.input_proj(x)
        for block in self.blocks:
            x = block(x)
        x = self.output_proj(x)
        gate = torch.sigmoid(self.gate)
        return residual + gate * x


class PatchTSTExtremeCNNModel(PatchTSTExtremeModel):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__(configs=configs, patch_len=patch_len, stride=stride, horizon_indices=horizon_indices)
        self.local_encoder = LocalCNNEncoder(
            in_channels=configs.enc_in,
            hidden_channels=configs.cnn_local_hidden,
            num_blocks=configs.cnn_local_blocks,
            kernels=tuple(int(v) for v in configs.cnn_local_kernels),
            dropout=configs.cnn_local_dropout,
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        x_enc = self.local_encoder(x_enc)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out


class PatchTSTExtremeMultiScaleModel(nn.Module):
    def __init__(self, configs: Config, horizon_indices: List[int], target_feature_idx: int):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.horizon_indices = horizon_indices
        self.target_feature_idx = int(target_feature_idx)
        self.patch_lens = tuple(int(v) for v in configs.multiscale_patch_lens)

        self.patch_embeddings = nn.ModuleList()
        self.encoders = nn.ModuleList()
        self.scale_projectors = nn.ModuleList()
        self.scale_logits = nn.Parameter(torch.zeros(len(self.patch_lens)))

        total_patch_tokens = 0
        for patch_len in self.patch_lens:
            stride = patch_len
            padding = stride
            self.patch_embeddings.append(
                PatchEmbedding(configs.d_model, patch_len, stride, padding, configs.dropout)
            )
            self.encoders.append(
                Encoder(
                    [
                        EncoderLayer(
                            AttentionLayer(
                                FullAttention(
                                    False,
                                    configs.factor,
                                    attention_dropout=configs.dropout,
                                    output_attention=False,
                                ),
                                configs.d_model,
                                configs.n_heads,
                            ),
                            configs.d_model,
                            configs.d_ff,
                            dropout=configs.dropout,
                            activation=configs.activation,
                        )
                        for _ in range(configs.e_layers)
                    ],
                    norm_layer=nn.Sequential(
                        Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
                    ),
                )
            )
            patch_tokens = int((configs.seq_len - patch_len) / stride + 2)
            total_patch_tokens += patch_tokens
            self.scale_projectors.append(
                nn.Sequential(
                    nn.Conv1d(configs.d_model, configs.d_model, kernel_size=1),
                    nn.GELU(),
                    nn.Dropout(configs.dropout),
                )
            )

        self.head_nf = configs.d_model * total_patch_tokens
        self.base_head = FlattenHead(
            configs.enc_in, self.head_nf, configs.pred_len, head_dropout=configs.dropout
        )
        self.horizon_head = FlattenHead(
            configs.enc_in,
            self.head_nf,
            len(horizon_indices),
            head_dropout=configs.dropout,
        )
        self.horizon_gate = nn.Parameter(torch.zeros(len(horizon_indices)))

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_norm = x_enc - means
        stdev = torch.sqrt(torch.var(x_norm, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_norm = x_norm / stdev

        x_patch_in = x_norm.permute(0, 2, 1)
        scale_weights = torch.softmax(self.scale_logits, dim=0)
        scale_features = []
        for scale_idx, (patch_embed, encoder, projector) in enumerate(
            zip(self.patch_embeddings, self.encoders, self.scale_projectors)
        ):
            enc_tokens, n_vars = patch_embed(x_patch_in)
            enc_tokens, _ = encoder(enc_tokens)
            enc_tokens = torch.reshape(
                enc_tokens,
                (-1, n_vars, enc_tokens.shape[-2], enc_tokens.shape[-1]),
            )
            enc_tokens = enc_tokens.permute(0, 1, 3, 2)
            bsz, nvars, d_model, patch_num = enc_tokens.shape
            proj_in = enc_tokens.reshape(bsz * nvars, d_model, patch_num)
            proj_out = projector(proj_in).reshape(bsz, nvars, d_model, patch_num)
            scale_features.append(proj_out * scale_weights[scale_idx])

        fused = torch.cat(scale_features, dim=-1)
        dec_out = self.base_head(fused).permute(0, 2, 1)
        horizon_residual = self.horizon_head(fused).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]
        raise NotImplementedError("PatchTSTExtremeMultiScaleModel only supports forecasting tasks")


class TimeMixerDFTSeriesDecomp(nn.Module):
    def __init__(self, top_k: int = 5):
        super().__init__()
        self.top_k = top_k

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        xf = torch.fft.rfft(x, dim=1)
        freq = abs(xf)
        freq[0] = 0
        top_k_freq, _ = torch.topk(freq, k=self.top_k)
        xf[freq <= top_k_freq.min()] = 0
        x_season = torch.fft.irfft(xf, dim=1)
        x_trend = x - x_season
        return x_season, x_trend


class TimeMixerMultiScaleSeasonMixing(nn.Module):
    def __init__(self, configs: Config):
        super().__init__()
        self.down_sampling_layers = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(
                        configs.seq_len // (configs.down_sampling_window ** i),
                        configs.seq_len // (configs.down_sampling_window ** (i + 1)),
                    ),
                    nn.GELU(),
                    nn.Linear(
                        configs.seq_len // (configs.down_sampling_window ** (i + 1)),
                        configs.seq_len // (configs.down_sampling_window ** (i + 1)),
                    ),
                )
                for i in range(configs.down_sampling_layers)
            ]
        )

    def forward(self, season_list: List[torch.Tensor]) -> List[torch.Tensor]:
        if len(season_list) == 1:
            return [season_list[0].permute(0, 2, 1)]

        out_high = season_list[0]
        out_low = season_list[1]
        out_season_list = [out_high.permute(0, 2, 1)]

        for i in range(len(season_list) - 1):
            out_low_res = self.down_sampling_layers[i](out_high)
            out_low = out_low + out_low_res
            out_high = out_low
            if i + 2 <= len(season_list) - 1:
                out_low = season_list[i + 2]
            out_season_list.append(out_high.permute(0, 2, 1))

        return out_season_list


class TimeMixerMultiScaleTrendMixing(nn.Module):
    def __init__(self, configs: Config):
        super().__init__()
        self.up_sampling_layers = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(
                        configs.seq_len // (configs.down_sampling_window ** (i + 1)),
                        configs.seq_len // (configs.down_sampling_window ** i),
                    ),
                    nn.GELU(),
                    nn.Linear(
                        configs.seq_len // (configs.down_sampling_window ** i),
                        configs.seq_len // (configs.down_sampling_window ** i),
                    ),
                )
                for i in reversed(range(configs.down_sampling_layers))
            ]
        )

    def forward(self, trend_list: List[torch.Tensor]) -> List[torch.Tensor]:
        if len(trend_list) == 1:
            return [trend_list[0].permute(0, 2, 1)]

        trend_list_reverse = trend_list.copy()
        trend_list_reverse.reverse()
        out_low = trend_list_reverse[0]
        out_high = trend_list_reverse[1]
        out_trend_list = [out_low.permute(0, 2, 1)]

        for i in range(len(trend_list_reverse) - 1):
            out_high_res = self.up_sampling_layers[i](out_low)
            out_high = out_high + out_high_res
            out_low = out_high
            if i + 2 <= len(trend_list_reverse) - 1:
                out_high = trend_list_reverse[i + 2]
            out_trend_list.append(out_low.permute(0, 2, 1))

        out_trend_list.reverse()
        return out_trend_list


class TimeMixerPastDecomposableMixing(nn.Module):
    def __init__(self, configs: Config):
        super().__init__()
        series_decomp = load_tslib_symbol("layers.Autoformer_EncDec", "series_decomp")

        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.down_sampling_window = configs.down_sampling_window
        self.layer_norm = nn.LayerNorm(configs.d_model)
        self.dropout = nn.Dropout(configs.dropout)
        self.channel_independence = configs.channel_independence

        if configs.decomp_method == "moving_avg":
            self.decompsition = series_decomp(configs.moving_avg)
        elif configs.decomp_method == "dft_decomp":
            self.decompsition = TimeMixerDFTSeriesDecomp(configs.top_k)
        else:
            raise ValueError("decompsition is error")

        if not configs.channel_independence:
            self.cross_layer = nn.Sequential(
                nn.Linear(in_features=configs.d_model, out_features=configs.d_ff),
                nn.GELU(),
                nn.Linear(in_features=configs.d_ff, out_features=configs.d_model),
            )

        self.mixing_multi_scale_season = TimeMixerMultiScaleSeasonMixing(configs)
        self.mixing_multi_scale_trend = TimeMixerMultiScaleTrendMixing(configs)

        self.out_cross_layer = nn.Sequential(
            nn.Linear(in_features=configs.d_model, out_features=configs.d_ff),
            nn.GELU(),
            nn.Linear(in_features=configs.d_ff, out_features=configs.d_model),
        )

    def forward(self, x_list: List[torch.Tensor]) -> List[torch.Tensor]:
        length_list = []
        for x in x_list:
            _, length, _ = x.size()
            length_list.append(length)

        season_list = []
        trend_list = []
        for x in x_list:
            season, trend = self.decompsition(x)
            if not self.channel_independence:
                season = self.cross_layer(season)
                trend = self.cross_layer(trend)
            season_list.append(season.permute(0, 2, 1))
            trend_list.append(trend.permute(0, 2, 1))

        out_season_list = self.mixing_multi_scale_season(season_list)
        out_trend_list = self.mixing_multi_scale_trend(trend_list)

        out_list = []
        for ori, out_season, out_trend, length in zip(
            x_list, out_season_list, out_trend_list, length_list
        ):
            out = out_season + out_trend
            if self.channel_independence:
                out = ori + self.out_cross_layer(out)
            out_list.append(out[:, :length, :])
        return out_list


class TimeMixerOriginalModel(nn.Module):
    def __init__(self, configs: Config):
        super().__init__()
        series_decomp = load_tslib_symbol("layers.Autoformer_EncDec", "series_decomp")
        DataEmbeddingWoPos = load_tslib_symbol("layers.Embed", "DataEmbedding_wo_pos")
        Normalize = load_tslib_symbol("layers.StandardNorm", "Normalize")

        self.configs = configs
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.label_len = configs.label_len
        self.pred_len = configs.pred_len
        self.down_sampling_window = configs.down_sampling_window
        self.channel_independence = configs.channel_independence
        self.pdm_blocks = nn.ModuleList(
            [TimeMixerPastDecomposableMixing(configs) for _ in range(configs.e_layers)]
        )

        self.preprocess = series_decomp(configs.moving_avg)
        self.enc_in = configs.enc_in

        if self.channel_independence:
            self.enc_embedding = DataEmbeddingWoPos(
                1, configs.d_model, configs.embed, configs.freq, configs.dropout
            )
        else:
            self.enc_embedding = DataEmbeddingWoPos(
                configs.enc_in, configs.d_model, configs.embed, configs.freq, configs.dropout
            )

        self.layer = configs.e_layers

        self.normalize_layers = nn.ModuleList(
            [
                Normalize(
                    self.configs.enc_in,
                    affine=True,
                    non_norm=True if configs.use_norm == 0 else False,
                )
                for _ in range(configs.down_sampling_layers + 1)
            ]
        )

        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            self.predict_layers = nn.ModuleList(
                [
                    nn.Linear(
                        configs.seq_len // (configs.down_sampling_window ** i),
                        configs.pred_len,
                    )
                    for i in range(configs.down_sampling_layers + 1)
                ]
            )

            if self.channel_independence:
                self.projection_layer = nn.Linear(configs.d_model, 1, bias=True)
            else:
                self.projection_layer = nn.Linear(configs.d_model, configs.c_out, bias=True)
                self.out_res_layers = nn.ModuleList(
                    [
                        nn.Linear(
                            configs.seq_len // (configs.down_sampling_window ** i),
                            configs.seq_len // (configs.down_sampling_window ** i),
                        )
                        for i in range(configs.down_sampling_layers + 1)
                    ]
                )
                self.regression_layers = nn.ModuleList(
                    [
                        nn.Linear(
                            configs.seq_len // (configs.down_sampling_window ** i),
                            configs.pred_len,
                        )
                        for i in range(configs.down_sampling_layers + 1)
                    ]
                )

        if self.task_name in {"imputation", "anomaly_detection"}:
            if self.channel_independence:
                self.projection_layer = nn.Linear(configs.d_model, 1, bias=True)
            else:
                self.projection_layer = nn.Linear(configs.d_model, configs.c_out, bias=True)

        if self.task_name == "classification":
            self.act = F.gelu
            self.dropout = nn.Dropout(configs.dropout)
            self.projection = nn.Linear(configs.d_model * configs.seq_len, configs.num_class)

    def out_projection(self, dec_out: torch.Tensor, i: int, out_res: torch.Tensor) -> torch.Tensor:
        dec_out = self.projection_layer(dec_out)
        out_res = out_res.permute(0, 2, 1)
        out_res = self.out_res_layers[i](out_res)
        out_res = self.regression_layers[i](out_res).permute(0, 2, 1)
        dec_out = dec_out + out_res
        return dec_out

    def pre_enc(
        self, x_list: List[torch.Tensor]
    ) -> Tuple[List[torch.Tensor], Optional[List[torch.Tensor]]]:
        if self.channel_independence:
            return x_list, None

        out1_list = []
        out2_list = []
        for x in x_list:
            x_1, x_2 = self.preprocess(x)
            out1_list.append(x_1)
            out2_list.append(x_2)
        return out1_list, out2_list

    def __multi_scale_process_inputs(
        self, x_enc: torch.Tensor, x_mark_enc: Optional[torch.Tensor]
    ) -> Tuple[List[torch.Tensor], Optional[List[torch.Tensor]]]:
        if self.configs.down_sampling_method == "max":
            down_pool = nn.MaxPool1d(self.configs.down_sampling_window, return_indices=False)
        elif self.configs.down_sampling_method == "avg":
            down_pool = nn.AvgPool1d(self.configs.down_sampling_window)
        elif self.configs.down_sampling_method == "conv":
            padding = 1 if torch.__version__ >= "1.5.0" else 2
            down_pool = nn.Conv1d(
                in_channels=self.configs.enc_in,
                out_channels=self.configs.enc_in,
                kernel_size=3,
                padding=padding,
                stride=self.configs.down_sampling_window,
                padding_mode="circular",
                bias=False,
            ).to(x_enc.device)
        else:
            return [x_enc], [x_mark_enc] if x_mark_enc is not None else None

        x_enc = x_enc.permute(0, 2, 1)
        x_enc_ori = x_enc
        x_mark_enc_mark_ori = x_mark_enc

        x_enc_sampling_list = [x_enc.permute(0, 2, 1)]
        x_mark_sampling_list = [x_mark_enc]

        for _ in range(self.configs.down_sampling_layers):
            x_enc_sampling = down_pool(x_enc_ori)
            x_enc_sampling_list.append(x_enc_sampling.permute(0, 2, 1))
            x_enc_ori = x_enc_sampling

            if x_mark_enc is not None:
                x_mark_sampling = x_mark_enc_mark_ori[:, :: self.configs.down_sampling_window, :]
                x_mark_sampling = x_mark_sampling[:, : x_enc_sampling.size(-1), :]
                x_mark_sampling_list.append(x_mark_sampling)
                x_mark_enc_mark_ori = x_mark_enc_mark_ori[:, :: self.configs.down_sampling_window, :]

        x_mark_out = x_mark_sampling_list if x_mark_enc is not None else None
        return x_enc_sampling_list, x_mark_out

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: Optional[torch.Tensor],
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        x_enc, x_mark_enc = self.__multi_scale_process_inputs(x_enc, x_mark_enc)

        x_list = []
        x_mark_list = []
        if x_mark_enc is not None:
            for i, x, x_mark in zip(range(len(x_enc)), x_enc, x_mark_enc):
                batch_size, length, n_vars = x.size()
                x = self.normalize_layers[i](x, "norm")
                if self.channel_independence:
                    x = x.permute(0, 2, 1).contiguous().reshape(batch_size * n_vars, length, 1)
                    x_list.append(x)
                    x_mark = x_mark.repeat(n_vars, 1, 1)
                    x_mark_list.append(x_mark)
                else:
                    x_list.append(x)
                    x_mark_list.append(x_mark)
        else:
            for i, x in zip(range(len(x_enc)), x_enc):
                batch_size, length, n_vars = x.size()
                x = self.normalize_layers[i](x, "norm")
                if self.channel_independence:
                    x = x.permute(0, 2, 1).contiguous().reshape(batch_size * n_vars, length, 1)
                x_list.append(x)

        enc_out_list = []
        x_list = self.pre_enc(x_list)
        if x_mark_enc is not None:
            for _, x, x_mark in zip(range(len(x_list[0])), x_list[0], x_mark_list):
                enc_out = self.enc_embedding(x, x_mark)
                enc_out_list.append(enc_out)
        else:
            for _, x in zip(range(len(x_list[0])), x_list[0]):
                enc_out = self.enc_embedding(x, None)
                enc_out_list.append(enc_out)

        for i in range(self.layer):
            enc_out_list = self.pdm_blocks[i](enc_out_list)

        dec_out_list = self.future_multi_mixing(batch_size, enc_out_list, x_list)
        dec_out = torch.stack(dec_out_list, dim=-1).sum(-1)
        dec_out = self.normalize_layers[0](dec_out, "denorm")
        return dec_out

    def future_multi_mixing(
        self,
        batch_size: int,
        enc_out_list: List[torch.Tensor],
        x_list: Tuple[List[torch.Tensor], Optional[List[torch.Tensor]]],
    ) -> List[torch.Tensor]:
        dec_out_list = []
        if self.channel_independence:
            series_list = x_list[0]
            for i, enc_out in zip(range(len(series_list)), enc_out_list):
                dec_out = self.predict_layers[i](enc_out.permute(0, 2, 1)).permute(0, 2, 1)
                dec_out = self.projection_layer(dec_out)
                dec_out = dec_out.reshape(
                    batch_size, self.configs.c_out, self.pred_len
                ).permute(0, 2, 1).contiguous()
                dec_out_list.append(dec_out)
        else:
            residual_list = x_list[1] if x_list[1] is not None else []
            for i, enc_out, out_res in zip(range(len(x_list[0])), enc_out_list, residual_list):
                dec_out = self.predict_layers[i](enc_out.permute(0, 2, 1)).permute(0, 2, 1)
                dec_out = self.out_projection(dec_out, i, out_res)
                dec_out_list.append(dec_out)

        return dec_out_list

    def classification(self, x_enc: torch.Tensor, x_mark_enc: torch.Tensor) -> torch.Tensor:
        x_enc, _ = self.__multi_scale_process_inputs(x_enc, None)
        enc_out_list = [self.enc_embedding(x, None) for x in x_enc]

        for i in range(self.layer):
            enc_out_list = self.pdm_blocks[i](enc_out_list)

        output = self.act(enc_out_list[0])
        output = self.dropout(output)
        output = output * x_mark_enc.unsqueeze(-1)
        output = output.reshape(output.shape[0], -1)
        return self.projection(output)

    def anomaly_detection(self, x_enc: torch.Tensor) -> torch.Tensor:
        x_enc, _ = self.__multi_scale_process_inputs(x_enc, None)

        x_list = []
        for i, x in zip(range(len(x_enc)), x_enc):
            batch_size, length, n_vars = x.size()
            x = self.normalize_layers[i](x, "norm")
            if self.channel_independence:
                x = x.permute(0, 2, 1).contiguous().reshape(batch_size * n_vars, length, 1)
            x_list.append(x)

        enc_out_list = [self.enc_embedding(x, None) for x in x_list]
        for i in range(self.layer):
            enc_out_list = self.pdm_blocks[i](enc_out_list)

        dec_out = self.projection_layer(enc_out_list[0])
        dec_out = dec_out.reshape(batch_size, self.configs.c_out, -1).permute(0, 2, 1).contiguous()
        dec_out = self.normalize_layers[0](dec_out, "denorm")
        return dec_out

    def imputation(
        self, x_enc: torch.Tensor, x_mark_enc: Optional[torch.Tensor], mask: torch.Tensor
    ) -> torch.Tensor:
        means = torch.sum(x_enc, dim=1) / torch.sum(mask == 1, dim=1)
        means = means.unsqueeze(1).detach()
        x_enc = x_enc - means
        x_enc = x_enc.masked_fill(mask == 0, 0)
        stdev = torch.sqrt(torch.sum(x_enc * x_enc, dim=1) / torch.sum(mask == 1, dim=1) + 1e-5)
        stdev = stdev.unsqueeze(1).detach()
        x_enc /= stdev

        x_enc, x_mark_enc = self.__multi_scale_process_inputs(x_enc, x_mark_enc)

        x_list = []
        for x in x_enc:
            batch_size, length, n_vars = x.size()
            if self.channel_independence:
                x = x.permute(0, 2, 1).contiguous().reshape(batch_size * n_vars, length, 1)
            x_list.append(x)

        enc_out_list = [self.enc_embedding(x, None) for x in x_list]
        for i in range(self.layer):
            enc_out_list = self.pdm_blocks[i](enc_out_list)

        dec_out = self.projection_layer(enc_out_list[0])
        dec_out = dec_out.reshape(batch_size, self.configs.c_out, -1).permute(0, 2, 1).contiguous()
        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.seq_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.seq_len, 1))
        return dec_out

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            return self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        if self.task_name == "imputation":
            return self.imputation(x_enc, x_mark_enc, mask)
        if self.task_name == "anomaly_detection":
            return self.anomaly_detection(x_enc)
        if self.task_name == "classification":
            return self.classification(x_enc, x_mark_enc)
        raise ValueError("Other tasks implemented yet")


class DensityAwareExtremeLoss(nn.Module):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
    ):
        super().__init__()
        self.horizon_indices = horizon_indices
        self.low_thresholds = [float(v) for v in low_thresholds]
        self.high_thresholds = [float(v) for v in high_thresholds]
        self.horizon_weights = [float(v) for v in horizon_weights]
        self.low_weights = [float(v) for v in low_weights]
        self.high_weights = [float(v) for v in high_weights]
        self.density_weight_blend = float(density_weight_blend)
        self.register_buffer(
            "density_bin_edges",
            torch.tensor(density_bin_edges, dtype=torch.float32),
        )
        self.register_buffer(
            "density_bin_weights",
            torch.tensor(density_bin_weights, dtype=torch.float32),
        )

    def _density_multiplier(self, horizon_pos: int, horizon_values: torch.Tensor) -> torch.Tensor:
        edges = self.density_bin_edges[horizon_pos]
        rarity = self.density_bin_weights[horizon_pos]
        bin_idx = torch.bucketize(horizon_values, edges[1:-1])
        density_mult = rarity[bin_idx]
        return 1.0 + self.density_weight_blend * (density_mult - 1.0)

    def _build_point_weights(self, true: torch.Tensor) -> torch.Tensor:
        weights = torch.ones_like(true)
        for horizon_pos, (idx, low_thr, high_thr, horizon_w, low_w, high_w) in enumerate(
            zip(
                self.horizon_indices,
                self.low_thresholds,
                self.high_thresholds,
                self.horizon_weights,
                self.low_weights,
                self.high_weights,
            )
        ):
            horizon_true = true[:, idx:idx + 1, :]
            horizon_weights = weights[:, idx:idx + 1, :] * horizon_w
            horizon_weights = torch.where(horizon_true <= low_thr, horizon_weights * low_w, horizon_weights)
            horizon_weights = torch.where(horizon_true >= high_thr, horizon_weights * high_w, horizon_weights)
            density_mult = self._density_multiplier(horizon_pos, horizon_true[:, 0, 0]).view(-1, 1, 1)
            horizon_weights = horizon_weights * density_mult
            weights[:, idx:idx + 1, :] = horizon_weights
        return weights

    def forward(self, pred: torch.Tensor, true: torch.Tensor) -> torch.Tensor:
        sq_err = (pred - true) ** 2
        weights = self._build_point_weights(true)
        weights = weights / weights.mean().clamp_min(1e-6)
        return (sq_err * weights).mean()

class AdaptiveDensityAwareExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        adaptive_extreme_strength: float,
        adaptive_direction_strength: float,
        adaptive_direction_error_power: float,
        adaptive_high_tail_scale: float,
        adaptive_low_tail_scale: float,
        adaptive_max_point_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.adaptive_extreme_strength = float(adaptive_extreme_strength)
        self.adaptive_direction_strength = float(adaptive_direction_strength)
        self.adaptive_direction_error_power = float(adaptive_direction_error_power)
        self.adaptive_high_tail_scale = float(adaptive_high_tail_scale)
        self.adaptive_low_tail_scale = float(adaptive_low_tail_scale)
        self.adaptive_max_point_weight = float(adaptive_max_point_weight)

    def _tail_scales(
        self,
        low_thr: float,
        high_thr: float,
        horizon_true: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        center = 0.5 * (low_thr + high_thr)
        low_scale = max(center - low_thr, 1.0) * self.adaptive_low_tail_scale
        high_scale = max(high_thr - center, 1.0) * self.adaptive_high_tail_scale
        return torch.full_like(horizon_true, low_scale), torch.full_like(horizon_true, high_scale)

    def _build_point_weights_adaptive(self, pred: torch.Tensor, true: torch.Tensor) -> torch.Tensor:
        weights = torch.ones_like(true)
        for horizon_pos, (idx, low_thr, high_thr, horizon_w, low_w, high_w) in enumerate(
            zip(
                self.horizon_indices,
                self.low_thresholds,
                self.high_thresholds,
                self.horizon_weights,
                self.low_weights,
                self.high_weights,
            )
        ):
            horizon_true = true[:, idx:idx + 1, :]
            horizon_pred = pred[:, idx:idx + 1, :]
            horizon_weights_t = weights[:, idx:idx + 1, :] * horizon_w

            low_scale, high_scale = self._tail_scales(low_thr, high_thr, horizon_true)
            low_degree = torch.relu((low_thr - horizon_true) / low_scale)
            high_degree = torch.relu((horizon_true - high_thr) / high_scale)

            low_amp = max(low_w - 1.0, 0.0)
            high_amp = max(1.0 - high_w, 0.0)
            low_tail_weight = 1.0 + low_amp * (1.0 + self.adaptive_extreme_strength * low_degree)
            high_tail_weight = 1.0 + high_amp * (1.0 + self.adaptive_extreme_strength * high_degree)

            over_low = torch.relu((horizon_pred - horizon_true) / low_scale)
            under_high = torch.relu((horizon_true - horizon_pred) / high_scale)
            over_low = torch.pow(over_low, self.adaptive_direction_error_power)
            under_high = torch.pow(under_high, self.adaptive_direction_error_power)

            low_dir_weight = 1.0 + self.adaptive_direction_strength * over_low * (1.0 + low_degree)
            high_dir_weight = 1.0 + self.adaptive_direction_strength * under_high * (1.0 + high_degree)

            low_mask = (horizon_true <= low_thr).to(horizon_true.dtype)
            high_mask = (horizon_true >= high_thr).to(horizon_true.dtype)
            neutral_mask = (1.0 - low_mask - high_mask).clamp_min(0.0)

            adaptive_tail_weight = (
                neutral_mask
                + low_mask * low_tail_weight * low_dir_weight
                + high_mask * high_tail_weight * high_dir_weight
            )

            density_mult = self._density_multiplier(horizon_pos, horizon_true[:, 0, 0]).view(-1, 1, 1)
            horizon_weights_t = horizon_weights_t * adaptive_tail_weight * density_mult
            horizon_weights_t = horizon_weights_t.clamp(max=self.adaptive_max_point_weight)
            weights[:, idx:idx + 1, :] = horizon_weights_t
        return weights

    def forward(self, pred: torch.Tensor, true: torch.Tensor) -> torch.Tensor:
        sq_err = (pred - true) ** 2
        weights = self._build_point_weights_adaptive(pred, true)
        weights = weights / weights.mean().clamp_min(1e-6)
        return (sq_err * weights).mean()


class AsymmetricDirectionalExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        transition_thresholds: List[float],
        extreme_strength: float,
        low_over_strength: float,
        high_under_strength: float,
        direction_error_power: float,
        high_tail_scale: float,
        low_tail_scale: float,
        transition_strength: float,
        max_point_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.requires_current_target = True
        self.extreme_strength = float(extreme_strength)
        self.low_over_strength = float(low_over_strength)
        self.high_under_strength = float(high_under_strength)
        self.direction_error_power = float(direction_error_power)
        self.high_tail_scale = float(high_tail_scale)
        self.low_tail_scale = float(low_tail_scale)
        self.transition_strength = float(transition_strength)
        self.max_point_weight = float(max_point_weight)
        self.register_buffer(
            "transition_thresholds",
            torch.tensor(transition_thresholds, dtype=torch.float32),
        )

    def _tail_scales(
        self,
        low_thr: float,
        high_thr: float,
        horizon_true: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        center = 0.5 * (low_thr + high_thr)
        low_scale = max(center - low_thr, 1.0) * self.low_tail_scale
        high_scale = max(high_thr - center, 1.0) * self.high_tail_scale
        return torch.full_like(horizon_true, low_scale), torch.full_like(horizon_true, high_scale)

    def _build_point_weights(
        self,
        pred: torch.Tensor,
        true: torch.Tensor,
        current_target: torch.Tensor,
    ) -> torch.Tensor:
        weights = torch.ones_like(true)
        current_target = current_target.to(true.dtype)
        if current_target.ndim == 2:
            current_target = current_target.unsqueeze(-1)
        if current_target.ndim == 1:
            current_target = current_target.view(-1, 1, 1)

        for horizon_pos, (idx, low_thr, high_thr, horizon_w, low_w, high_w) in enumerate(
            zip(
                self.horizon_indices,
                self.low_thresholds,
                self.high_thresholds,
                self.horizon_weights,
                self.low_weights,
                self.high_weights,
            )
        ):
            horizon_true = true[:, idx:idx + 1, :]
            horizon_pred = pred[:, idx:idx + 1, :]
            horizon_weights_t = weights[:, idx:idx + 1, :] * horizon_w

            low_scale, high_scale = self._tail_scales(low_thr, high_thr, horizon_true)
            low_degree = torch.relu((low_thr - horizon_true) / low_scale)
            high_degree = torch.relu((horizon_true - high_thr) / high_scale)

            low_amp = max(low_w - 1.0, 0.0)
            high_amp = max(1.0 - high_w, 0.0)
            low_tail_weight = 1.0 + low_amp * (1.0 + self.extreme_strength * low_degree)
            high_tail_weight = 1.0 + high_amp * (1.0 + self.extreme_strength * high_degree)

            over_low = torch.relu((horizon_pred - horizon_true) / low_scale)
            under_high = torch.relu((horizon_true - horizon_pred) / high_scale)
            over_low = torch.pow(over_low, self.direction_error_power)
            under_high = torch.pow(under_high, self.direction_error_power)

            low_dir_weight = 1.0 + self.low_over_strength * over_low * (1.0 + low_degree)
            high_dir_weight = 1.0 + self.high_under_strength * under_high * (1.0 + high_degree)

            low_mask = (horizon_true <= low_thr).to(horizon_true.dtype)
            high_mask = (horizon_true >= high_thr).to(horizon_true.dtype)
            neutral_mask = (1.0 - low_mask - high_mask).clamp_min(0.0)

            tail_weight = (
                neutral_mask
                + low_mask * low_tail_weight * low_dir_weight
                + high_mask * high_tail_weight * high_dir_weight
            )

            transition_thr = float(self.transition_thresholds[horizon_pos].item())
            transition_scale = max(transition_thr, 1.0)
            delta_true = torch.abs(horizon_true - current_target)
            transition_degree = torch.relu((delta_true - transition_thr) / transition_scale)
            transition_weight = 1.0 + self.transition_strength * transition_degree

            density_mult = self._density_multiplier(horizon_pos, horizon_true[:, 0, 0]).view(-1, 1, 1)
            horizon_weights_t = horizon_weights_t * tail_weight * transition_weight * density_mult
            horizon_weights_t = horizon_weights_t.clamp(max=self.max_point_weight)
            weights[:, idx:idx + 1, :] = horizon_weights_t

        return weights

    def forward(
        self,
        pred: torch.Tensor,
        true: torch.Tensor,
        current_target: torch.Tensor,
    ) -> torch.Tensor:
        sq_err = (pred - true) ** 2
        weights = self._build_point_weights(pred, true, current_target)
        weights = weights / weights.mean().clamp_min(1e-6)
        return (sq_err * weights).mean()


class EventAwareExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        transition_thresholds: List[float],
        event_pos_weights: np.ndarray,
        delta_loss_weight: float,
        event_loss_weight: float,
        transition_weight: float,
        tail_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.delta_loss_weight = float(delta_loss_weight)
        self.event_loss_weight = float(event_loss_weight)
        self.transition_weight = float(transition_weight)
        self.tail_weight = float(tail_weight)
        self.register_buffer(
            "transition_thresholds",
            torch.tensor(transition_thresholds, dtype=torch.float32),
        )
        self.register_buffer(
            "event_pos_weights",
            torch.tensor(event_pos_weights, dtype=torch.float32),
        )

    def forward(self, pred_bundle: Dict[str, torch.Tensor], true: torch.Tensor) -> torch.Tensor:
        forecast = pred_bundle["forecast"]
        current_target = pred_bundle["current_target"]
        delta_pred = pred_bundle["delta_pred"]
        event_logits = pred_bundle["event_logits"]

        base_loss = super().forward(forecast, true)

        delta_targets = []
        event_targets = []
        sample_weights = []
        for horizon_pos, idx in enumerate(self.horizon_indices):
            horizon_true = true[:, idx, 0]
            delta_true = horizon_true - current_target
            low_target = (horizon_true <= self.low_thresholds[horizon_pos]).float()
            high_target = (horizon_true >= self.high_thresholds[horizon_pos]).float()
            transition_target = (delta_true.abs() >= self.transition_thresholds[horizon_pos]).float()

            delta_targets.append(delta_true)
            event_targets.append(torch.stack([low_target, high_target, transition_target], dim=-1))

            tail_target = torch.maximum(low_target, high_target)
            weights = torch.ones_like(delta_true) * self.horizon_weights[horizon_pos]
            weights = weights * (1.0 + self.transition_weight * transition_target + self.tail_weight * tail_target)
            sample_weights.append(weights)

        delta_true = torch.stack(delta_targets, dim=1)
        event_target = torch.stack(event_targets, dim=1)
        sample_weight = torch.stack(sample_weights, dim=1)
        sample_weight = sample_weight / sample_weight.mean().clamp_min(1e-6)

        delta_loss = F.smooth_l1_loss(delta_pred, delta_true, reduction="none")
        delta_loss = (delta_loss * sample_weight).mean()

        pos_weight = self.event_pos_weights.view(1, len(self.horizon_indices), 3)
        event_loss = F.binary_cross_entropy_with_logits(
            event_logits,
            event_target,
            pos_weight=pos_weight,
            reduction="none",
        )
        event_loss = (event_loss * sample_weight.unsqueeze(-1)).mean()

        return base_loss + self.delta_loss_weight * delta_loss + self.event_loss_weight * event_loss


class RefineAwareExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        transition_thresholds: List[float],
        full_delta_threshold: float,
        event_pos_weights: np.ndarray,
        delta_loss_weight: float,
        event_loss_weight: float,
        transition_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.delta_loss_weight = float(delta_loss_weight)
        self.event_loss_weight = float(event_loss_weight)
        self.transition_weight = float(transition_weight)
        self.register_buffer(
            "transition_thresholds",
            torch.tensor(transition_thresholds, dtype=torch.float32),
        )
        self.register_buffer(
            "event_pos_weights",
            torch.tensor(event_pos_weights, dtype=torch.float32),
        )
        self.full_delta_threshold = float(full_delta_threshold)

    def forward(self, pred_bundle: Dict[str, torch.Tensor], true: torch.Tensor) -> torch.Tensor:
        forecast = pred_bundle["forecast"]
        current_target = pred_bundle["current_target"]
        delta_pred_full = pred_bundle["delta_pred_full"]
        event_logits = pred_bundle["event_logits"]

        base_loss = super().forward(forecast, true)

        delta_true_full = true[:, :, 0] - current_target.unsqueeze(1)
        delta_weights = torch.ones_like(delta_true_full)
        delta_weights = torch.where(
            delta_true_full.abs() >= self.full_delta_threshold,
            delta_weights * (1.0 + self.transition_weight),
            delta_weights,
        )
        for horizon_pos, idx in enumerate(self.horizon_indices):
            delta_weights[:, idx] = delta_weights[:, idx] * self.horizon_weights[horizon_pos]
        delta_weights = delta_weights / delta_weights.mean().clamp_min(1e-6)

        delta_loss = F.smooth_l1_loss(delta_pred_full, delta_true_full, reduction="none")
        delta_loss = (delta_loss * delta_weights).mean()

        event_targets = []
        for horizon_pos, idx in enumerate(self.horizon_indices):
            horizon_true = true[:, idx, 0]
            delta_true = delta_true_full[:, idx]
            low_target = (horizon_true <= self.low_thresholds[horizon_pos]).float()
            high_target = (horizon_true >= self.high_thresholds[horizon_pos]).float()
            transition_target = (delta_true.abs() >= self.transition_thresholds[horizon_pos]).float()
            event_targets.append(torch.stack([low_target, high_target, transition_target], dim=-1))
        event_target = torch.stack(event_targets, dim=1)

        pos_weight = self.event_pos_weights.view(1, len(self.horizon_indices), 3)
        event_loss = F.binary_cross_entropy_with_logits(
            event_logits,
            event_target,
            pos_weight=pos_weight,
            reduction="none",
        )
        sample_weight = torch.ones_like(event_target[..., 0])
        for horizon_pos in range(len(self.horizon_indices)):
            sample_weight[:, horizon_pos] = sample_weight[:, horizon_pos] * self.horizon_weights[horizon_pos]
        sample_weight = sample_weight / sample_weight.mean().clamp_min(1e-6)
        event_loss = (event_loss * sample_weight.unsqueeze(-1)).mean()

        return base_loss + self.delta_loss_weight * delta_loss + self.event_loss_weight * event_loss


def load_tslib_time_features(tslib_root: str):
    module_path = os.path.join(tslib_root, "utils", "timefeatures.py")
    if not os.path.isfile(module_path):
        raise FileNotFoundError(f"Official TSLib timefeatures.py not found: {module_path}")

    spec = importlib.util.spec_from_file_location("tslib_timefeatures", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load TSLib timefeatures module from: {module_path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.time_features


TSLIB_TIME_FEATURES = load_tslib_time_features(TSLIB_ROOT)


def load_tslib_symbol(module_rel_path: str, symbol_name: str):
    module_path = os.path.join(TSLIB_ROOT, *module_rel_path.split(".")) + ".py"
    if not os.path.isfile(module_path):
        raise FileNotFoundError(f"Official TSLib module not found: {module_path}")

    cache_key = f"tslib_dynamic_{module_rel_path.replace('.', '_')}"
    if cache_key in sys.modules:
        module = sys.modules[cache_key]
    else:
        spec = importlib.util.spec_from_file_location(cache_key, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Unable to load TSLib module from: {module_path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        sys.modules[cache_key] = module

    if not hasattr(module, symbol_name):
        raise AttributeError(f"Symbol '{symbol_name}' not found in {module_path}")
    return getattr(module, symbol_name)


# =========================
# 3. Utilities
# =========================
def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def safe_cols(df: pd.DataFrame, cols: List[str]) -> List[str]:
    return [c for c in cols if c in df.columns]


def get_decomp_source_seed(method: str, for_proxy: bool = False) -> List[str]:
    method_key = method.lower()
    if method_key == "ceemdan":
        # CEEMDAN is much heavier than the other decompositions, so we keep the
        # most process-relevant variables instead of decomposing all 8 channels.
        return ["In_Water", "In_AN", "S_On_DO", "Main_AirV"] if not for_proxy else ["In_AN", "S_On_DO", "Main_AirV"]
    return list(VMD_FEATURE_SOURCE_COLS)


def get_proxy_max_rows(method: str) -> int:
    method_key = method.lower()
    if method_key == "ceemdan":
        return 720
    if method_key in {"stl", "mstl"}:
        return 2880
    if method_key in {"ewt", "wpd", "ssa"}:
        return 4000
    return WOA_PROXY_MAX_ROWS


def release_memory() -> None:
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def vmd_decompose_1d(
    signal: np.ndarray,
    alpha: float = VMD_ALPHA,
    tau: float = VMD_TAU,
    K: int = VMD_NUM_MODES,
    DC: bool = VMD_DC,
    init: int = VMD_INIT,
    tol: float = VMD_TOL,
    max_iters: int = VMD_MAX_ITERS,
) -> np.ndarray:
    """
    Compact NumPy VMD implementation for exploratory feature engineering.
    Returns modes shaped [K, N].
    """
    f = np.asarray(signal, dtype=np.float64).reshape(-1)
    if len(f) < 8:
        return np.tile(f[None, :], (K, 1))

    if len(f) % 2 == 1:
        f = f[:-1]
    N = len(f)
    half = N // 2

    f_mirror = np.concatenate([f[:half][::-1], f, f[-half:][::-1]])
    T = len(f_mirror)

    freqs = np.arange(1, T + 1, dtype=np.float64) / T - 0.5 - (1.0 / T)
    f_hat = np.fft.fftshift(np.fft.fft(f_mirror))
    f_hat_plus = np.copy(f_hat)
    f_hat_plus[: T // 2] = 0

    u_hat_plus = np.zeros((max_iters, T, K), dtype=np.complex128)
    omega_plus = np.zeros((max_iters, K), dtype=np.float64)
    lambda_hat = np.zeros((max_iters, T), dtype=np.complex128)

    if init == 1:
        omega_plus[0, :] = 0.5 / K * np.arange(K, dtype=np.float64)
    elif init == 2:
        omega_plus[0, :] = np.sort(np.exp(np.log(1 / T) + (np.log(0.5) - np.log(1 / T)) * np.random.rand(K)))
    else:
        omega_plus[0, :] = 0.0
    if DC:
        omega_plus[0, 0] = 0.0

    u_diff = tol + np.finfo(float).eps
    n = 0
    sum_uk = np.zeros(T, dtype=np.complex128)

    while u_diff > tol and n < max_iters - 1:
        k = 0
        sum_uk = u_hat_plus[n, :, K - 1] + sum_uk - u_hat_plus[n, :, 0]
        denom = 1.0 + alpha * (freqs - omega_plus[n, k]) ** 2
        u_hat_plus[n + 1, :, k] = (f_hat_plus - sum_uk - lambda_hat[n, :] / 2.0) / denom
        if not DC:
            power = np.abs(u_hat_plus[n + 1, T // 2 :, k]) ** 2
            omega_plus[n + 1, k] = np.sum(freqs[T // 2 :] * power) / max(np.sum(power), 1e-12)

        for k in range(1, K):
            sum_uk = u_hat_plus[n + 1, :, k - 1] + sum_uk - u_hat_plus[n, :, k]
            denom = 1.0 + alpha * (freqs - omega_plus[n, k]) ** 2
            u_hat_plus[n + 1, :, k] = (f_hat_plus - sum_uk - lambda_hat[n, :] / 2.0) / denom
            power = np.abs(u_hat_plus[n + 1, T // 2 :, k]) ** 2
            omega_plus[n + 1, k] = np.sum(freqs[T // 2 :] * power) / max(np.sum(power), 1e-12)

        lambda_hat[n + 1, :] = lambda_hat[n, :] + tau * (np.sum(u_hat_plus[n + 1, :, :], axis=1) - f_hat_plus)

        u_diff = 0.0
        for k in range(K):
            diff = u_hat_plus[n + 1, :, k] - u_hat_plus[n, :, k]
            u_diff += (1.0 / T) * np.vdot(diff, diff).real
        n += 1

    n_final = min(n, max_iters - 1)
    u_hat = np.zeros((T, K), dtype=np.complex128)
    u_hat[T // 2 :, :] = u_hat_plus[n_final, T // 2 :, :]
    u_hat[: T // 2, :] = np.conj(u_hat_plus[n_final, T // 2 : 0 : -1, :])
    u_hat[0, :] = np.conj(u_hat[-1, :])

    u = np.zeros((K, T), dtype=np.float64)
    for k in range(K):
        u[k, :] = np.real(np.fft.ifft(np.fft.ifftshift(u_hat[:, k])))

    u = u[:, half : half + N]
    return u


def resize_component_bank(components: List[np.ndarray], target_count: int) -> np.ndarray:
    if not components:
        return np.zeros((target_count, 0), dtype=np.float64)
    arrs = [np.asarray(comp, dtype=np.float64).reshape(-1) for comp in components]
    signal_len = len(arrs[0])
    arrs = [comp[:signal_len] for comp in arrs]
    if target_count <= 0:
        return np.zeros((0, signal_len), dtype=np.float64)
    if len(arrs) == target_count:
        return np.stack(arrs, axis=0)
    if len(arrs) > target_count:
        if target_count == 1:
            return np.sum(np.stack(arrs, axis=0), axis=0, keepdims=True)
        kept = arrs[: target_count - 1]
        remainder = np.sum(np.stack(arrs[target_count - 1 :], axis=0), axis=0)
        return np.stack(kept + [remainder], axis=0)
    pad = [np.zeros(signal_len, dtype=np.float64) for _ in range(target_count - len(arrs))]
    return np.stack(arrs + pad, axis=0)


def ceemdan_decompose_1d(
    signal: np.ndarray,
    num_components: int,
    trials: int = CEEMDAN_TRIALS,
    noise_width: float = CEEMDAN_NOISE_WIDTH,
) -> np.ndarray:
    try:
        from PyEMD import CEEMDAN
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "CEEMDAN requires the optional package 'EMD-signal'. Install it with:\n"
            r"D:\pc\pythonProject\.venv\Scripts\python.exe -m pip install EMD-signal"
        ) from exc

    f = np.asarray(signal, dtype=np.float64).reshape(-1)
    if len(f) < 8:
        return np.tile(f[None, :], (num_components, 1))

    ceemdan = CEEMDAN(trials=trials, epsilon=noise_width)
    try:
        imfs = ceemdan.ceemdan(f, max_imf=max(1, num_components))
    except TypeError:
        imfs = ceemdan.ceemdan(f)
    imfs = np.asarray(imfs, dtype=np.float64)
    if imfs.ndim == 1:
        imfs = imfs[None, :]
    components = [imfs[i] for i in range(imfs.shape[0])]
    if components:
        residual = f - np.sum(np.stack(components, axis=0), axis=0)
        components.append(residual)
    return resize_component_bank(components, num_components)


def ewt_decompose_1d(signal: np.ndarray, num_components: int) -> np.ndarray:
    f = np.asarray(signal, dtype=np.float64).reshape(-1)
    if len(f) < 8:
        return np.tile(f[None, :], (num_components, 1))

    spectrum = np.fft.rfft(f)
    amplitude = np.abs(spectrum)
    if len(amplitude) <= 2:
        return np.tile(f[None, :], (num_components, 1))
    amplitude[0] = 0.0

    candidate_count = max(1, num_components - 1)
    peak_idx = np.argsort(amplitude[1:])[-candidate_count:] + 1
    peak_idx = np.unique(np.sort(peak_idx))

    if len(peak_idx) < candidate_count:
        boundaries = np.linspace(0, len(spectrum) - 1, num_components + 1)
    else:
        boundaries = [0.0]
        for left, right in zip(peak_idx[:-1], peak_idx[1:]):
            boundaries.append(0.5 * (left + right))
        boundaries.append(len(spectrum) - 1.0)
        boundaries = np.array(boundaries, dtype=np.float64)
        boundaries = np.interp(
            np.linspace(0, len(boundaries) - 1, num_components + 1),
            np.arange(len(boundaries)),
            boundaries,
        )

    components: List[np.ndarray] = []
    for idx in range(num_components):
        left = int(round(boundaries[idx]))
        right = int(round(boundaries[idx + 1]))
        if idx == num_components - 1:
            right = len(spectrum) - 1
        left = max(0, min(left, len(spectrum) - 1))
        right = max(left, min(right, len(spectrum) - 1))
        band = np.zeros_like(spectrum)
        band[left : right + 1] = spectrum[left : right + 1]
        components.append(np.fft.irfft(band, n=len(f)).real)
    return resize_component_bank(components, num_components)


def wpd_decompose_1d(
    signal: np.ndarray,
    num_components: int,
    wavelet: str = WPD_WAVELET,
    max_level: int = WPD_MAX_LEVEL,
) -> np.ndarray:
    import pywt

    f = np.asarray(signal, dtype=np.float64).reshape(-1)
    if len(f) < 8:
        return np.tile(f[None, :], (num_components, 1))

    wavelet_obj = pywt.Wavelet(wavelet)
    level = max(1, min(max_level, pywt.dwt_max_level(len(f), wavelet_obj.dec_len)))
    wp = pywt.WaveletPacket(data=f, wavelet=wavelet_obj, maxlevel=level, mode="symmetric")
    nodes = wp.get_level(level, order="freq")
    ranked_nodes = sorted(nodes, key=lambda node: float(np.sum(np.square(node.data))), reverse=True)

    selected_components: List[np.ndarray] = []
    keep_count = max(0, num_components - 1)
    for node in ranked_nodes[:keep_count]:
        new_wp = pywt.WaveletPacket(data=None, wavelet=wavelet_obj, maxlevel=level, mode="symmetric")
        new_wp[node.path] = node.data
        comp = new_wp.reconstruct(update=False)
        selected_components.append(np.asarray(comp, dtype=np.float64)[: len(f)])

    if selected_components:
        residual = f - np.sum(np.stack(selected_components, axis=0), axis=0)
        selected_components.append(residual)
    else:
        selected_components = [f]
    return resize_component_bank(selected_components, num_components)


def diagonal_averaging(matrix: np.ndarray) -> np.ndarray:
    L, K = matrix.shape
    N = L + K - 1
    result = np.zeros(N, dtype=np.float64)
    counts = np.zeros(N, dtype=np.float64)
    for i in range(L):
        for j in range(K):
            result[i + j] += matrix[i, j]
            counts[i + j] += 1.0
    return result / np.clip(counts, 1.0, None)


def ssa_decompose_1d(signal: np.ndarray, num_components: int, window: int = SSA_WINDOW) -> np.ndarray:
    f = np.asarray(signal, dtype=np.float64).reshape(-1)
    N = len(f)
    if N < 8:
        return np.tile(f[None, :], (num_components, 1))

    L = max(2, min(int(window), N // 2))
    K = N - L + 1
    trajectory = np.column_stack([f[i : i + L] for i in range(K)])
    U, s, Vt = np.linalg.svd(trajectory, full_matrices=False)

    components: List[np.ndarray] = []
    keep_count = max(0, num_components - 1)
    for idx in range(min(keep_count, len(s))):
        elem = s[idx] * np.outer(U[:, idx], Vt[idx, :])
        components.append(diagonal_averaging(elem))
    if components:
        residual = f - np.sum(np.stack(components, axis=0), axis=0)
        components.append(residual)
    else:
        components = [f]
    return resize_component_bank(components, num_components)


def stl_decompose_1d(signal: np.ndarray, num_components: int, period: int = STL_PERIOD) -> np.ndarray:
    from statsmodels.tsa.seasonal import STL

    f = np.asarray(signal, dtype=np.float64).reshape(-1)
    if len(f) < max(8, 2 * period):
        return resize_component_bank([f], num_components)
    series = pd.Series(f).ffill().bfill()
    result = STL(series, period=int(period), robust=True).fit()
    components = [
        np.asarray(result.trend, dtype=np.float64),
        np.asarray(result.seasonal, dtype=np.float64),
        np.asarray(result.resid, dtype=np.float64),
    ]
    return resize_component_bank(components, num_components)


def mstl_decompose_1d(signal: np.ndarray, num_components: int, periods: Tuple[int, ...] = MSTL_PERIODS) -> np.ndarray:
    from statsmodels.tsa.seasonal import MSTL

    f = np.asarray(signal, dtype=np.float64).reshape(-1)
    if len(f) < 8:
        return resize_component_bank([f], num_components)
    valid_periods = tuple(int(p) for p in periods if 2 <= int(p) < len(f) // 2)
    if not valid_periods:
        return resize_component_bank([f], num_components)

    series = pd.Series(f).ffill().bfill()
    result = MSTL(series, periods=list(valid_periods)).fit()
    seasonals = result.seasonal
    if isinstance(seasonals, pd.DataFrame):
        seasonal_components = [seasonals.iloc[:, idx].to_numpy(dtype=np.float64) for idx in range(seasonals.shape[1])]
    else:
        seasonal_arr = np.asarray(seasonals, dtype=np.float64)
        if seasonal_arr.ndim == 1:
            seasonal_components = [seasonal_arr]
        else:
            seasonal_components = [seasonal_arr[:, idx] for idx in range(seasonal_arr.shape[1])]
    components = [np.asarray(result.trend, dtype=np.float64)] + seasonal_components + [np.asarray(result.resid, dtype=np.float64)]
    return resize_component_bank(components, num_components)


def get_decomposition_labels(method: str, count: int) -> List[str]:
    method = method.lower()
    if method == "none":
        return []
    if method == "stl":
        base = ["trend", "seasonal", "resid"]
        return (base[:count] + [f"c{i + 1}" for i in range(max(0, count - len(base)))])[:count]
    if method == "mstl":
        if count <= 1:
            return ["trend"]
        labels = ["trend"] + [f"seasonal{i}" for i in range(1, max(1, count - 1))] + ["resid"]
        return labels[:count]
    return [f"m{i + 1}" for i in range(count)]


def decompose_signal_1d(
    signal: np.ndarray,
    method: str,
    num_components: int,
    vmd_alpha: float = VMD_ALPHA,
    decomp_kwargs: Optional[Dict[str, object]] = None,
) -> np.ndarray:
    method_key = method.lower()
    kwargs = dict(decomp_kwargs or {})
    if method_key == "vmd":
        return vmd_decompose_1d(signal=signal, alpha=vmd_alpha, K=num_components)
    if method_key == "ceemdan":
        return ceemdan_decompose_1d(
            signal=signal,
            num_components=num_components,
            trials=int(kwargs.get("trials", CEEMDAN_TRIALS)),
            noise_width=float(kwargs.get("noise_width", CEEMDAN_NOISE_WIDTH)),
        )
    if method_key == "ewt":
        return ewt_decompose_1d(signal=signal, num_components=num_components)
    if method_key == "wpd":
        return wpd_decompose_1d(
            signal=signal,
            num_components=num_components,
            wavelet=str(kwargs.get("wavelet", WPD_WAVELET)),
            max_level=int(kwargs.get("max_level", WPD_MAX_LEVEL)),
        )
    if method_key == "ssa":
        return ssa_decompose_1d(
            signal=signal,
            num_components=num_components,
            window=int(kwargs.get("window", SSA_WINDOW)),
        )
    if method_key == "stl":
        return stl_decompose_1d(
            signal=signal,
            num_components=num_components,
            period=int(kwargs.get("period", STL_PERIOD)),
        )
    if method_key == "mstl":
        periods = kwargs.get("periods", MSTL_PERIODS)
        periods_tuple = tuple(int(v) for v in periods)
        return mstl_decompose_1d(
            signal=signal,
            num_components=num_components,
            periods=periods_tuple,
        )
    raise ValueError(f"Unsupported decomposition method: {method}")


def add_decomposition_features(
    df_in: pd.DataFrame,
    base_feature_cols: List[str],
    method: str,
    source_cols_override: List[str] = None,
    num_components: int = DECOMP_NUM_COMPONENTS,
    alpha: float = VMD_ALPHA,
    decomp_kwargs: Optional[Dict[str, object]] = None,
) -> Tuple[pd.DataFrame, List[str], List[str]]:
    df = df_in.copy()
    if method.lower() == "none":
        base_safe = safe_cols(df, base_feature_cols)
        non_target_cols = [c for c in base_safe if c != TARGET_COL]
        feature_cols = non_target_cols + [TARGET_COL]
        return df, feature_cols, []
    source_seed = source_cols_override if source_cols_override is not None else VMD_FEATURE_SOURCE_COLS
    source_cols = [c for c in source_seed if c in df.columns]
    generated_cols: List[str] = []
    component_labels = get_decomposition_labels(method, num_components)

    for col in source_cols:
        series = pd.to_numeric(df[col], errors="coerce").ffill().bfill().to_numpy(dtype=np.float64)
        modes = decompose_signal_1d(
            signal=series,
            method=method,
            num_components=num_components,
            vmd_alpha=alpha,
            decomp_kwargs=decomp_kwargs,
        )
        for mode_idx in range(modes.shape[0]):
            label = component_labels[mode_idx] if mode_idx < len(component_labels) else f"m{mode_idx + 1}"
            new_col = f"{col}__{method.lower()}_{label}"
            df[new_col] = modes[mode_idx].astype(np.float32)
            generated_cols.append(new_col)

    base_safe = safe_cols(df, base_feature_cols)
    non_target_cols = [c for c in base_safe if c != TARGET_COL]
    feature_cols = non_target_cols + generated_cols + [TARGET_COL]
    return df, feature_cols, generated_cols


def run_decomposition_experiment(
    df_in: pd.DataFrame,
    base_feature_cols: List[str],
    method: str,
    source_cols: List[str],
    num_components: int,
    alpha: float,
    decomp_kwargs: Optional[Dict[str, object]] = None,
    include_predictions: bool = True,
    train_epochs: Optional[int] = None,
    train_patience: Optional[int] = None,
    log_training: bool = True,
) -> Dict[str, object]:
    set_seed(RANDOM_STATE)

    df_feat, feature_cols, generated_cols = add_decomposition_features(
        df_in.copy(),
        base_feature_cols=base_feature_cols,
        method=method,
        source_cols_override=source_cols,
        num_components=num_components,
        alpha=alpha,
        decomp_kwargs=decomp_kwargs,
    )
    if not feature_cols:
        raise ValueError("No valid feature columns found.")
    if feature_cols[-1] != TARGET_COL:
        raise ValueError("TARGET_COL must be the last feature in BASE_FEATURE_COLS.")

    X_seq, Y_seq, X_mark, Y_mark, y_true_seq, t_seq = build_official_seq_dataset(
        df_in=df_feat,
        feature_cols=feature_cols,
        seq_len=SEQ_LEN,
        label_len=LABEL_LEN,
        pred_len=PRED_LEN,
        freq="t",
    )

    n = len(X_seq)
    split_idx = int(n * TRAIN_RATIO)

    X_train, X_test = X_seq[:split_idx], X_seq[split_idx:]
    Y_train, Y_test = Y_seq[:split_idx], Y_seq[split_idx:]
    X_mark_train, X_mark_test = X_mark[:split_idx], X_mark[split_idx:]
    Y_mark_train, Y_mark_test = Y_mark[:split_idx], Y_mark[split_idx:]
    y_true_train, y_true_test = y_true_seq[:split_idx], y_true_seq[split_idx:]
    t_test = t_seq[split_idx:]

    n_features = X_train.shape[2]
    x_scaler = MinMaxScaler()
    x_scaler.fit(X_train.reshape(-1, n_features))

    X_train_scaled = x_scaler.transform(X_train.reshape(-1, n_features)).reshape(X_train.shape).astype(np.float32)
    X_test_scaled = x_scaler.transform(X_test.reshape(-1, n_features)).reshape(X_test.shape).astype(np.float32)
    Y_train_scaled = x_scaler.transform(Y_train.reshape(-1, n_features)).reshape(Y_train.shape).astype(np.float32)
    Y_test_scaled = x_scaler.transform(Y_test.reshape(-1, n_features)).reshape(Y_test.shape).astype(np.float32)

    target_idx = feature_cols.index(TARGET_COL)
    selected_horizon_indices = [h - 1 for h in HORIZON_MINS]

    y_true_train_selected = y_true_train[:, selected_horizon_indices]
    y_true_test_selected = y_true_test[:, selected_horizon_indices]
    y_pred_persistence_selected = np.repeat(
        X_test[:, -1, target_idx][:, None],
        len(HORIZON_MINS),
        axis=1,
    )
    train_low_thresholds = np.quantile(y_true_train_selected, EXTREME_TAIL_QUANTILE, axis=0)
    train_high_thresholds = np.quantile(y_true_train_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0)
    test_low_thresholds = np.quantile(y_true_test_selected, EXTREME_TAIL_QUANTILE, axis=0)
    test_high_thresholds = np.quantile(y_true_test_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0)

    split_val = int(len(X_train_scaled) * 0.9)
    X_tr, X_val = X_train_scaled[:split_val], X_train_scaled[split_val:]
    Y_tr, Y_val = Y_train_scaled[:split_val], Y_train_scaled[split_val:]
    X_mark_tr, X_mark_val = X_mark_train[:split_val], X_mark_train[split_val:]
    Y_mark_tr, Y_mark_val = Y_mark_train[:split_val], Y_mark_train[split_val:]

    train_ds = TensorDataset(
        torch.tensor(X_tr, dtype=torch.float32),
        torch.tensor(Y_tr, dtype=torch.float32),
        torch.tensor(X_mark_tr, dtype=torch.float32),
        torch.tensor(Y_mark_tr, dtype=torch.float32),
    )
    val_ds = TensorDataset(
        torch.tensor(X_val, dtype=torch.float32),
        torch.tensor(Y_val, dtype=torch.float32),
        torch.tensor(X_mark_val, dtype=torch.float32),
        torch.tensor(Y_mark_val, dtype=torch.float32),
    )

    loader_kwargs = {
        "batch_size": BATCH_SIZE,
        "shuffle": False,
        "num_workers": NUM_WORKERS,
        "pin_memory": PIN_MEMORY,
    }
    if NUM_WORKERS > 0:
        loader_kwargs["persistent_workers"] = True

    train_loader = DataLoader(train_ds, **loader_kwargs)
    val_loader = DataLoader(val_ds, **loader_kwargs)

    cfg = Config(
        enc_in=len(feature_cols),
        dec_in=len(feature_cols),
        c_out=len(feature_cols),
    )

    model = None
    try:
        model = build_model(MODEL_NAME, cfg)
        model = model.to(DEVICE)
        criterion = build_training_criterion(
            MODEL_NAME,
            y_true_train_selected,
            X_train[:, -1, target_idx],
            y_true_train,
        )
        effective_epochs = EPOCHS if train_epochs is None else max(1, int(train_epochs))
        effective_patience = PATIENCE if train_patience is None else max(1, int(train_patience))
        model = train_model(
            model,
            train_loader,
            val_loader,
            cfg,
            MODEL_NAME,
            criterion,
            effective_epochs,
            LR,
            effective_patience,
            DEVICE,
            verbose=log_training,
        )

        y_pred_test_scaled = predict_in_batches(
            model=model,
            X_np=X_test_scaled,
            Y_np=Y_test_scaled,
            X_mark_np=X_mark_test,
            Y_mark_np=Y_mark_test,
            cfg=cfg,
            model_name=MODEL_NAME,
            batch_size=256,
            device=DEVICE,
        )
        y_pred_test_scaled_full = np.asarray(y_pred_test_scaled, dtype=np.float32)
        y_pred_test_full = inverse_target_scale(
            y_pred_test_scaled_full.reshape(-1),
            x_scaler,
            target_idx,
        ).reshape(-1, PRED_LEN)
        y_pred_test_selected = y_pred_test_full[:, selected_horizon_indices]

        summary_rows = []
        diagnostic_rows = []
        model_rmses: List[float] = []
        for idx, horizon in enumerate(HORIZON_MINS):
            p_mae, p_rmse, p_r2 = evaluate_regression(
                y_true_test_selected[:, idx],
                y_pred_persistence_selected[:, idx],
            )
            m_mae, m_rmse, m_r2 = evaluate_regression(
                y_true_test_selected[:, idx],
                y_pred_test_selected[:, idx],
            )
            model_rmses.append(m_rmse)
            summary_rows.append(
                {
                    "horizon_min": horizon,
                    "model_type": "persistence",
                    "mae": p_mae,
                    "rmse": p_rmse,
                    "r2": p_r2,
                }
            )
            summary_rows.append(
                {
                    "horizon_min": horizon,
                    "model_type": MODEL_NAME,
                    "mae": m_mae,
                    "rmse": m_rmse,
                    "r2": m_r2,
                }
            )

            train_threshold_metrics = compute_horizon_diagnostics(
                y_true=y_true_test_selected[:, idx],
                y_pred=y_pred_test_selected[:, idx],
                persistence_pred=y_pred_persistence_selected[:, idx],
                baseline_now=X_test[:, -1, target_idx],
                low_threshold=float(train_low_thresholds[idx]),
                high_threshold=float(train_high_thresholds[idx]),
            )
            test_relative_metrics = compute_horizon_diagnostics(
                y_true=y_true_test_selected[:, idx],
                y_pred=y_pred_test_selected[:, idx],
                persistence_pred=y_pred_persistence_selected[:, idx],
                baseline_now=X_test[:, -1, target_idx],
                low_threshold=float(test_low_thresholds[idx]),
                high_threshold=float(test_high_thresholds[idx]),
            )
            eng_low_threshold = get_engineering_threshold(horizon, ENGINEERING_LOW_THRESHOLDS)
            eng_high_threshold = get_engineering_threshold(horizon, ENGINEERING_HIGH_THRESHOLDS)
            if not np.isnan(eng_low_threshold) and not np.isnan(eng_high_threshold):
                engineering_metrics = compute_horizon_diagnostics(
                    y_true=y_true_test_selected[:, idx],
                    y_pred=y_pred_test_selected[:, idx],
                    persistence_pred=y_pred_persistence_selected[:, idx],
                    baseline_now=X_test[:, -1, target_idx],
                    low_threshold=eng_low_threshold,
                    high_threshold=eng_high_threshold,
                )
            else:
                engineering_metrics = empty_horizon_diagnostics()
            diagnostic_rows.append(
                {
                    "horizon_min": horizon,
                    "model_type": MODEL_NAME,
                    "train_low_threshold": float(train_low_thresholds[idx]),
                    "train_high_threshold": float(train_high_thresholds[idx]),
                    "test_low_threshold": float(test_low_thresholds[idx]),
                    "test_high_threshold": float(test_high_thresholds[idx]),
                    "eng_low_threshold": eng_low_threshold,
                    "eng_high_threshold": eng_high_threshold,
                    **prefix_metric_keys(train_threshold_metrics, "trainthr"),
                    **prefix_metric_keys(test_relative_metrics, "testrel"),
                    **prefix_metric_keys(engineering_metrics, "eng"),
                }
            )

        summary_df = pd.DataFrame(summary_rows)
        diagnostic_df = pd.DataFrame(diagnostic_rows)
        method_table_df, _ = build_factory_method_table(df_feat)
        eval_context_df = pd.DataFrame({TIME_COL: pd.to_datetime(t_test)}).merge(
            df_feat[
                [
                    col
                    for col in [
                        TIME_COL,
                        "In_Water",
                        "In_COD",
                        "In_AN",
                        "N_On_DO",
                        "S_On_DO",
                        "S_On_AN",
                        "Out_AN",
                        "Out_TN",
                        "Out_COD",
                        "Out_PH",
                        TARGET_COL,
                    ]
                    if col in df_feat.columns
                ]
            ].drop_duplicates(subset=[TIME_COL]),
            on=TIME_COL,
            how="left",
        )
        scene_diagnostic_df = build_factory_scene_diagnostics(
            eval_context_df=eval_context_df,
            y_true_selected=y_true_test_selected,
            y_pred_selected=y_pred_test_selected,
            y_pred_persistence_selected=y_pred_persistence_selected,
            baseline_now=X_test[:, -1, target_idx],
            model_name=MODEL_NAME,
        )

        pred_df = None
        if include_predictions:
            pred_dict = {TIME_COL: pd.to_datetime(t_test)}
            for idx, horizon in enumerate(HORIZON_MINS):
                pred_dict[f"y_true_t{horizon}"] = y_true_test_selected[:, idx]
                pred_dict[f"y_pred_persistence_t{horizon}"] = y_pred_persistence_selected[:, idx]
                pred_dict[f"y_pred_{MODEL_NAME}_scaled_t{horizon}"] = y_pred_test_scaled_full[:, selected_horizon_indices[idx]]
                pred_dict[f"y_pred_{MODEL_NAME}_t{horizon}"] = y_pred_test_selected[:, idx]
            pred_df = pd.DataFrame(pred_dict)

        weighted_rmse = 0.25 * model_rmses[0] + 0.35 * model_rmses[1] + 0.40 * model_rmses[2]
        return {
            "feature_cols": feature_cols,
            "generated_cols": generated_cols,
            "summary_df": summary_df,
            "diagnostic_df": diagnostic_df,
            "scene_diagnostic_df": scene_diagnostic_df,
            "method_table_df": method_table_df,
            "pred_df": pred_df,
            "weighted_rmse": float(weighted_rmse),
        }
    finally:
        del train_loader, val_loader, train_ds, val_ds
        if model is not None:
            del model
        release_memory()


def build_decomp_proxy_score(
    df_in: pd.DataFrame,
    base_feature_cols: List[str],
    method: str,
    source_cols: List[str],
    num_components: int,
    alpha: float,
    decomp_kwargs: Optional[Dict[str, object]] = None,
) -> float:
    df_small = df_in.copy()
    proxy_max_rows = get_proxy_max_rows(method)
    if len(df_small) > proxy_max_rows:
        df_small = df_small.iloc[-proxy_max_rows:].reset_index(drop=True)

    proxy_source_cols = safe_cols(df_small, get_decomp_source_seed(method, for_proxy=True))
    if proxy_source_cols:
        source_cols = proxy_source_cols

    df_feat, feature_cols, _ = add_decomposition_features(
        df_small,
        base_feature_cols=base_feature_cols,
        method=method,
        source_cols_override=source_cols,
        num_components=num_components,
        alpha=alpha,
        decomp_kwargs=decomp_kwargs,
    )
    max_h = max(HORIZON_MINS)
    target_series = pd.to_numeric(df_feat[TARGET_COL], errors="coerce")
    X = df_feat[feature_cols].iloc[:-max_h].to_numpy(dtype=np.float32)
    Y = np.stack(
        [target_series.shift(-h).iloc[:-max_h].to_numpy(dtype=np.float32) for h in HORIZON_MINS],
        axis=1,
    )

    valid_mask = np.isfinite(X).all(axis=1) & np.isfinite(Y).all(axis=1)
    X = X[valid_mask]
    Y = Y[valid_mask]
    if len(X) < 500:
        return float("inf")

    split = int(len(X) * 0.8)
    X_tr, X_val = X[:split], X[split:]
    Y_tr, Y_val = Y[:split], Y[split:]
    if len(X_val) < 50:
        return float("inf")

    scaler = MinMaxScaler()
    X_tr = scaler.fit_transform(X_tr)
    X_val = scaler.transform(X_val)

    model = Ridge(alpha=1.0, random_state=RANDOM_STATE)
    model.fit(X_tr, Y_tr)
    pred = model.predict(X_val)
    rmses = [math.sqrt(mean_squared_error(Y_val[:, i], pred[:, i])) for i in range(pred.shape[1])]
    weighted = 0.25 * rmses[0] + 0.35 * rmses[1] + 0.40 * rmses[2]
    return float(weighted)


def whale_optimize_vmd(
    df_in: pd.DataFrame,
    base_feature_cols: List[str],
    source_cols: List[str],
    pop_size: int,
    iters: int,
    k_min: int,
    k_max: int,
    alpha_min: float,
    alpha_max: float,
) -> Tuple[int, float, float]:
    rng = np.random.default_rng(RANDOM_STATE)
    whales = np.column_stack(
        [
            rng.uniform(k_min, k_max + 1e-6, size=pop_size),
            rng.uniform(alpha_min, alpha_max, size=pop_size),
        ]
    ).astype(np.float64)

    def project(sol: np.ndarray) -> np.ndarray:
        sol = sol.copy()
        sol[0] = np.clip(sol[0], k_min, k_max)
        sol[1] = np.clip(sol[1], alpha_min, alpha_max)
        return sol

    def score(sol: np.ndarray) -> float:
        K = int(round(sol[0]))
        alpha = float(sol[1])
        return build_decomp_proxy_score(
            df_in=df_in,
            base_feature_cols=base_feature_cols,
            method="vmd",
            source_cols=source_cols,
            num_components=K,
            alpha=alpha,
        )

    fitness = np.array([score(w) for w in whales], dtype=np.float64)
    best_idx = int(np.argmin(fitness))
    best = whales[best_idx].copy()
    best_score = float(fitness[best_idx])

    for t in range(iters):
        a = 2.0 - 2.0 * (t / max(iters - 1, 1))
        for i in range(pop_size):
            r1, r2 = rng.random(), rng.random()
            A = 2.0 * a * r1 - a
            C = 2.0 * r2
            p = rng.random()
            whale = whales[i].copy()
            if p < 0.5:
                if abs(A) < 1.0:
                    D = np.abs(C * best - whale)
                    new_pos = best - A * D
                else:
                    rand_idx = int(rng.integers(0, pop_size))
                    ref = whales[rand_idx]
                    D = np.abs(C * ref - whale)
                    new_pos = ref - A * D
            else:
                D = np.abs(best - whale)
                l = rng.uniform(-1.0, 1.0)
                b = 1.0
                new_pos = D * np.exp(b * l) * np.cos(2.0 * np.pi * l) + best

            whales[i] = project(new_pos)
            fitness[i] = score(whales[i])
            if fitness[i] < best_score:
                best = whales[i].copy()
                best_score = float(fitness[i])
        print(
            "WOA_VMD_INFO: "
            f"iter={t + 1}/{iters}, "
            f"best_K={int(round(best[0]))}, "
            f"best_alpha={float(best[1]):.2f}, "
            f"proxy_score={best_score:.4f}"
        )

    return int(round(best[0])), float(best[1]), best_score


def sample_candidate_list(
    candidates: List[Tuple[int, Dict[str, object]]],
    max_candidates: int,
) -> List[Tuple[int, Dict[str, object]]]:
    if len(candidates) <= max_candidates:
        return candidates
    rng = np.random.default_rng(RANDOM_STATE)
    keep_indices = sorted(rng.choice(len(candidates), size=max_candidates, replace=False).tolist())
    return [candidates[idx] for idx in keep_indices]


def build_decomp_search_candidates(method: str) -> List[Tuple[int, Dict[str, object]]]:
    method_key = method.lower()
    component_options = list(range(DECOMP_COMPONENT_MIN, DECOMP_COMPONENT_MAX + 1))
    candidates: List[Tuple[int, Dict[str, object]]] = []

    if method_key == "ceemdan":
        for num_components in component_options:
            for trials in CEEMDAN_TRIAL_OPTIONS:
                for noise_width in CEEMDAN_NOISE_OPTIONS:
                    candidates.append(
                        (
                            num_components,
                            {"trials": int(trials), "noise_width": float(noise_width)},
                        )
                    )
        return candidates

    if method_key == "ewt":
        return [(num_components, {}) for num_components in component_options]

    if method_key == "wpd":
        for num_components in component_options:
            for wavelet in WPD_WAVELET_OPTIONS:
                for max_level in WPD_LEVEL_OPTIONS:
                    candidates.append(
                        (
                            num_components,
                            {"wavelet": str(wavelet), "max_level": int(max_level)},
                        )
                    )
        return candidates

    if method_key == "ssa":
        for num_components in component_options:
            for window in SSA_WINDOW_OPTIONS:
                candidates.append((num_components, {"window": int(window)}))
        return candidates

    if method_key == "stl":
        for period in STL_PERIOD_OPTIONS:
            candidates.append((3, {"period": int(period)}))
        return candidates

    if method_key == "mstl":
        for periods in MSTL_PERIOD_CANDIDATES:
            candidates.append((max(3, len(periods) + 1), {"periods": tuple(int(v) for v in periods)}))
        return candidates

    if method_key == "vmd":
        return [(num_components, {"alpha": float(VMD_ALPHA)}) for num_components in component_options]

    raise ValueError(f"Unsupported decomposition method for search: {method}")


def format_decomp_kwargs(method: str, params: Optional[Dict[str, object]]) -> str:
    params = dict(params or {})
    if not params:
        return "(default)"
    if method.lower() == "mstl" and "periods" in params:
        params["periods"] = tuple(int(v) for v in params["periods"])
    return ", ".join(f"{k}={params[k]}" for k in sorted(params.keys()))


def search_non_vmd_decomposition(
    df_in: pd.DataFrame,
    base_feature_cols: List[str],
    method: str,
    source_cols: List[str],
    max_candidates: int,
) -> Tuple[int, Dict[str, object], float, str]:
    if method.lower() == "ssa":
        raise RuntimeError("SSA search should be routed through search_ssa_decomposition().")
    candidates = build_decomp_search_candidates(method)
    effective_max = max(1, int(max_candidates))
    if method.lower() == "ceemdan":
        effective_max = min(effective_max, CEEMDAN_SEARCH_MAX_CANDIDATES)
    candidates = sample_candidate_list(candidates, max_candidates=effective_max)
    best_components = DECOMP_NUM_COMPONENTS
    best_params: Dict[str, object] = {}
    best_score = float("inf")

    for idx, (num_components, params) in enumerate(candidates, start=1):
        score = build_decomp_proxy_score(
            df_in=df_in,
            base_feature_cols=base_feature_cols,
            method=method,
            source_cols=source_cols,
            num_components=num_components,
            alpha=VMD_ALPHA,
            decomp_kwargs=params,
        )
        if score < best_score:
            best_components = int(num_components)
            best_params = dict(params)
            best_score = float(score)
        print(
            "DECOMP_SEARCH_INFO: "
            f"method={method}, "
            f"candidate={idx}/{len(candidates)}, "
            f"num_components={num_components}, "
            f"params={format_decomp_kwargs(method, params)}, "
            f"proxy_score={score:.4f}, "
            f"best_score={best_score:.4f}"
        )

    return best_components, best_params, best_score, "proxy_score"


def evaluate_search_candidate_with_model(
    df_in: pd.DataFrame,
    base_feature_cols: List[str],
    method: str,
    source_cols: List[str],
    num_components: int,
    alpha: float,
    decomp_kwargs: Optional[Dict[str, object]],
    train_epochs: int,
    train_patience: int,
) -> float:
    result = run_decomposition_experiment(
        df_in=df_in,
        base_feature_cols=base_feature_cols,
        method=method,
        source_cols=source_cols,
        num_components=num_components,
        alpha=alpha,
        decomp_kwargs=decomp_kwargs,
        include_predictions=False,
        train_epochs=train_epochs,
        train_patience=train_patience,
        log_training=False,
    )
    return float(result["weighted_rmse"])


def search_ssa_decomposition(
    df_in: pd.DataFrame,
    base_feature_cols: List[str],
    source_cols: List[str],
    mode: str,
    rerank_topk: int,
    audit_path: Optional[str] = None,
) -> Tuple[int, Dict[str, object], float, str]:
    candidates = build_decomp_search_candidates("ssa")
    proxy_rows: List[Dict[str, object]] = []

    for idx, (num_components, params) in enumerate(candidates, start=1):
        proxy_score = build_decomp_proxy_score(
            df_in=df_in,
            base_feature_cols=base_feature_cols,
            method="ssa",
            source_cols=source_cols,
            num_components=num_components,
            alpha=VMD_ALPHA,
            decomp_kwargs=params,
        )
        proxy_rows.append(
            {
                "candidate_index": idx,
                "num_components": int(num_components),
                "window": int(params["window"]),
                "proxy_score": float(proxy_score),
            }
        )
        print(
            "SSA_PROXY_INFO: "
            f"candidate={idx}/{len(candidates)}, "
            f"num_components={num_components}, "
            f"params={format_decomp_kwargs('ssa', params)}, "
            f"proxy_score={proxy_score:.4f}"
        )

    proxy_df = pd.DataFrame(proxy_rows).sort_values(
        by=["proxy_score", "num_components", "window"],
        ascending=[True, True, True],
    ).reset_index(drop=True)

    if mode == "exact":
        shortlist_df = proxy_df.copy()
        eval_epochs = EPOCHS
        eval_patience = PATIENCE
        score_label = "weighted_rmse"
    else:
        shortlist_df = proxy_df.head(max(1, int(rerank_topk))).copy()
        eval_epochs = SSA_RERANK_EPOCHS
        eval_patience = SSA_RERANK_PATIENCE
        score_label = "rerank_weighted_rmse"

    best_components = DECOMP_NUM_COMPONENTS
    best_params: Dict[str, object] = {"window": SSA_WINDOW}
    best_score = float("inf")
    eval_rows: List[Dict[str, object]] = []

    for eval_rank, (_, row) in enumerate(shortlist_df.iterrows(), start=1):
        num_components = int(row["num_components"])
        params = {"window": int(row["window"])}
        exact_score = evaluate_search_candidate_with_model(
            df_in=df_in,
            base_feature_cols=base_feature_cols,
            method="ssa",
            source_cols=source_cols,
            num_components=num_components,
            alpha=VMD_ALPHA,
            decomp_kwargs=params,
            train_epochs=eval_epochs,
            train_patience=eval_patience,
        )
        eval_rows.append(
            {
                "eval_rank": eval_rank,
                "num_components": num_components,
                "window": int(params["window"]),
                score_label: float(exact_score),
                "search_mode": mode,
            }
        )
        running_best = exact_score if best_score == float("inf") else min(best_score, exact_score)
        print(
            f"SSA_{mode.upper()}_SEARCH_INFO: "
            f"candidate={eval_rank}/{len(shortlist_df)}, "
            f"num_components={num_components}, "
            f"params={format_decomp_kwargs('ssa', params)}, "
            f"proxy_score={float(row['proxy_score']):.4f}, "
            f"{score_label}={exact_score:.4f}, "
            f"best_{score_label}={running_best:.4f}"
        )
        if exact_score < best_score:
            best_components = num_components
            best_params = dict(params)
            best_score = float(exact_score)

    if audit_path:
        audit_df = proxy_df.merge(
            pd.DataFrame(eval_rows),
            on=["num_components", "window"],
            how="left",
        )
        audit_df.insert(0, "method", "ssa")
        audit_df["search_mode"] = audit_df["search_mode"].fillna(mode)
        audit_df.to_csv(audit_path, index=False, encoding="utf-8-sig")
        print(f"SSA_SEARCH_AUDIT_SAVED: {audit_path}")

    return best_components, best_params, best_score, score_label


def evaluate_regression(y_true: np.ndarray, y_pred: np.ndarray) -> Tuple[float, float, float]:
    mae = mean_absolute_error(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    return mae, rmse, r2


def safe_regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Tuple[float, float]:
    if len(y_true) == 0:
        return np.nan, np.nan
    mae = mean_absolute_error(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_true, y_pred))
    return mae, rmse


def safe_bias(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    if len(y_true) == 0:
        return np.nan
    return float(np.mean(y_pred - y_true))


def classification_metrics_from_events(y_true_event: np.ndarray, y_pred_event: np.ndarray) -> Dict[str, float]:
    tp = np.sum((y_true_event == 1) & (y_pred_event == 1))
    fp = np.sum((y_true_event == 0) & (y_pred_event == 1))
    fn = np.sum((y_true_event == 1) & (y_pred_event == 0))
    tn = np.sum((y_true_event == 0) & (y_pred_event == 0))

    precision = tp / (tp + fp) if (tp + fp) > 0 else np.nan
    recall = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    if np.isnan(precision) or np.isnan(recall) or (precision + recall) == 0:
        f1 = np.nan
    else:
        f1 = 2 * precision * recall / (precision + recall)

    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    false_alarm_rate = fp / (tp + fp) if (tp + fp) > 0 else np.nan
    miss_rate = fn / (tp + fn) if (tp + fn) > 0 else np.nan
    csi = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else np.nan
    balanced_accuracy = (
        (recall + specificity) / 2
        if not np.isnan(recall) and not np.isnan(specificity)
        else np.nan
    )
    alarm_rate = (tp + fp) / len(y_pred_event) if len(y_pred_event) > 0 else np.nan
    event_rate = (tp + fn) / len(y_true_event) if len(y_true_event) > 0 else np.nan

    return {
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "specificity": float(specificity),
        "false_alarm_rate": float(false_alarm_rate),
        "miss_rate": float(miss_rate),
        "csi": float(csi),
        "balanced_accuracy": float(balanced_accuracy),
        "alarm_rate": float(alarm_rate),
        "event_rate": float(event_rate),
        "tp": float(tp),
        "fp": float(fp),
        "fn": float(fn),
        "tn": float(tn),
    }


def empty_horizon_diagnostics() -> Dict[str, float]:
    metrics = {
        "mae_low": np.nan,
        "rmse_low": np.nan,
        "mae_high": np.nan,
        "rmse_high": np.nan,
        "bias_low": np.nan,
        "bias_high": np.nan,
        "rmse_delta_top10": np.nan,
        "rmse_delta_top10_persistence": np.nan,
        "n_low": np.nan,
        "n_high": np.nan,
        "n_delta_top10": np.nan,
    }
    cls_names = [
        "precision",
        "recall",
        "f1",
        "specificity",
        "false_alarm_rate",
        "miss_rate",
        "csi",
        "balanced_accuracy",
        "alarm_rate",
        "event_rate",
        "tp",
        "fp",
        "fn",
        "tn",
    ]
    for prefix in ["", "persistence_"]:
        for suffix in ["low", "high"]:
            for name in cls_names:
                metrics[f"{prefix}{name}_{suffix}"] = np.nan
    return metrics


def get_engineering_threshold(horizon: int, threshold_map: Dict[int, float]) -> float:
    value = threshold_map.get(horizon)
    if value is None:
        return np.nan
    return float(value)


def parse_threshold_arg(raw_value: str) -> Dict[int, float]:
    values = [v.strip() for v in str(raw_value).split(",") if v.strip()]
    if len(values) != len(HORIZON_MINS):
        raise ValueError(
            f"Threshold argument must provide {len(HORIZON_MINS)} comma-separated values "
            f"for horizons {HORIZON_MINS}, got: {raw_value}"
        )
    parsed: Dict[int, float] = {}
    for horizon, token in zip(HORIZON_MINS, values):
        if token.lower() in {"none", "nan", ""}:
            parsed[horizon] = None
        else:
            parsed[horizon] = float(token)
    return parsed


def get_numeric_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(np.nan, index=df.index, dtype=np.float32)
    return pd.to_numeric(df[col], errors="coerce")


def compute_factory_scene_thresholds(df: pd.DataFrame) -> Dict[str, float]:
    in_water = get_numeric_series(df, "In_Water")
    in_cod = get_numeric_series(df, "In_COD")
    in_an = get_numeric_series(df, "In_AN")
    return {
        "in_water_q90": float(in_water.quantile(0.90)),
        "in_cod_q90": float(in_cod.quantile(0.90)),
        "in_an_q90": float(in_an.quantile(0.90)),
    }


def build_factory_scene_masks(df: pd.DataFrame, thresholds: Dict[str, float]) -> Dict[str, np.ndarray]:
    n_do = get_numeric_series(df, "N_On_DO").to_numpy(dtype=np.float32)
    s_do = get_numeric_series(df, "S_On_DO").to_numpy(dtype=np.float32)
    do_min = np.minimum(n_do, s_do)
    do_max = np.maximum(n_do, s_do)
    s_on_an = get_numeric_series(df, "S_On_AN").to_numpy(dtype=np.float32)
    out_an = get_numeric_series(df, "Out_AN").to_numpy(dtype=np.float32)
    out_tn = get_numeric_series(df, "Out_TN").to_numpy(dtype=np.float32)
    out_cod = get_numeric_series(df, "Out_COD").to_numpy(dtype=np.float32)
    out_ph_series = get_numeric_series(df, "Out_PH")
    out_ph = out_ph_series.to_numpy(dtype=np.float32)
    in_water = get_numeric_series(df, "In_Water").to_numpy(dtype=np.float32)
    in_cod = get_numeric_series(df, "In_COD").to_numpy(dtype=np.float32)
    in_an = get_numeric_series(df, "In_AN").to_numpy(dtype=np.float32)
    air = get_numeric_series(df, TARGET_COL).to_numpy(dtype=np.float32)
    air_median = np.nanmedian(air)
    air_p25 = np.nanpercentile(air, 25)
    air_p75 = np.nanpercentile(air, 75)

    compliant_ph = np.ones(len(df), dtype=bool)
    if not out_ph_series.isna().all():
        compliant_ph = (out_ph >= FACTORY_PH_LOW) & (out_ph <= FACTORY_PH_HIGH)

    masks: Dict[str, np.ndarray] = {}
    masks["full_compliance"] = (
        (out_cod <= FACTORY_OUT_COD_LIMIT)
        & (out_an <= FACTORY_OUT_AN_LIMIT)
        & (out_tn <= FACTORY_OUT_TN_LIMIT)
        & compliant_ph
    )
    masks["compliance_risk"] = ~masks["full_compliance"]
    masks["any_warning"] = (
        ((out_cod > FACTORY_OUT_COD_WARNING) & (out_cod <= FACTORY_OUT_COD_LIMIT))
        | ((out_an > FACTORY_OUT_AN_WARNING) & (out_an <= FACTORY_OUT_AN_LIMIT))
        | ((out_tn > FACTORY_OUT_TN_WARNING) & (out_tn <= FACTORY_OUT_TN_LIMIT))
    )

    masks["do_normal"] = (do_min >= FACTORY_DO_LOW) & (do_max <= FACTORY_DO_HIGH)
    masks["hypoxia"] = do_min < FACTORY_DO_LOW
    masks["critical_hypoxia"] = do_min < FACTORY_DO_CRITICAL_LOW
    masks["over_aeration"] = do_max > FACTORY_DO_HIGH
    masks["critical_over"] = do_max > FACTORY_DO_CRITICAL_HIGH
    masks["nitrification_stable"] = (do_min >= FACTORY_DO_LOW) & (s_on_an < FACTORY_SONAN_WARNING)
    masks["nitrification_inhibition"] = (do_min < FACTORY_DO_LOW) & (s_on_an >= FACTORY_SONAN_WARNING)
    masks["nitrification_failure"] = (do_min < FACTORY_DO_CRITICAL_LOW) & (s_on_an >= FACTORY_SONAN_HIGH)
    masks["false_safety"] = masks["do_normal"] & (s_on_an >= FACTORY_SONAN_HIGH)
    masks["inefficient_aeration"] = (do_min < FACTORY_DO_LOW) & (air > air_median)
    masks["energy_waste"] = (do_max > FACTORY_DO_HIGH) & (s_on_an < 0.5) & (air > air_median)
    masks["ideal_control"] = (
        masks["do_normal"] & (air >= air_p25) & (air <= air_p75)
    )
    masks["inflow_shock"] = (
        (in_water > thresholds["in_water_q90"])
        | (in_cod > thresholds["in_cod_q90"])
        | (in_an > thresholds["in_an_q90"])
    )

    masks["reuse_safe"] = (
        (out_cod <= FACTORY_REUSE_COD)
        & (out_an <= FACTORY_REUSE_AN)
        & (out_tn <= FACTORY_REUSE_TN)
    )
    masks["reuse_fragile"] = (
        ((out_cod > FACTORY_REUSE_COD) | (out_an > FACTORY_REUSE_AN) | (out_tn > FACTORY_REUSE_TN))
        & masks["full_compliance"]
    )
    masks["reuse_risk"] = ~masks["reuse_safe"]
    masks["reuse_high_assurance"] = (
        (out_cod <= FACTORY_OUT_COD_WARNING)
        & (out_an <= FACTORY_OUT_AN_WARNING)
        & (out_tn <= FACTORY_OUT_TN_WARNING)
    )
    masks["reuse_early_warning"] = masks["do_normal"] & masks["any_warning"]

    masks["all"] = np.ones(len(df), dtype=bool)
    masks["all_bio_risk"] = masks["hypoxia"] | masks["over_aeration"] | masks["false_safety"]
    masks["all_critical"] = (
        masks["critical_hypoxia"] | masks["critical_over"] | masks["nitrification_failure"]
    )
    return masks


def build_factory_method_table(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, float]]:
    thresholds = compute_factory_scene_thresholds(df)
    masks = build_factory_scene_masks(df, thresholds)
    total = max(len(df), 1)
    scene_defs = [
        ("all", "全部数据", "All samples", "All available samples", "dataset", "Chronological evaluation split", "Overall predictive benchmark."),
        ("full_compliance", "✅ 一级A全面达标", "Full Class 1A compliance", f"Out_COD<={FACTORY_OUT_COD_LIMIT} and Out_AN<={FACTORY_OUT_AN_LIMIT} and Out_TN<={FACTORY_OUT_TN_LIMIT} and {FACTORY_PH_LOW}<=Out_PH<={FACTORY_PH_HIGH}", "national standard", "GB 18918-2002 Class 1A", "All monitored effluent indicators satisfy the Class 1A standard."),
        ("compliance_risk", "⚠️ 合规风险(任一超标)", "Compliance risk", f"Out_COD>{FACTORY_OUT_COD_LIMIT} or Out_AN>{FACTORY_OUT_AN_LIMIT} or Out_TN>{FACTORY_OUT_TN_LIMIT} or Out_PH outside [{FACTORY_PH_LOW}, {FACTORY_PH_HIGH}]", "national standard", "GB 18918-2002 Class 1A", "At least one effluent indicator exceeds the confirmed discharge requirement."),
        ("any_warning", "预警线(接近限值)", "Near-limit warning", f"Out_COD>{FACTORY_OUT_COD_WARNING} or Out_AN>{FACTORY_OUT_AN_WARNING} or Out_TN>{FACTORY_OUT_TN_WARNING}", "plant-specific warning", "Internal early-warning margin before compliance violation", "Effluent quality approaches the regulatory boundary and warrants proactive adjustment."),
        ("do_normal", "DO正常(2-4)", "Normal DO control zone", f"min(N_On_DO,S_On_DO)>={FACTORY_DO_LOW} and max(N_On_DO,S_On_DO)<={FACTORY_DO_HIGH}", "engineering rule", "A2O-MBR aeration control convention", "Biological aeration stays in the typical operating window."),
        ("hypoxia", "缺氧风险(DO<2)", "Hypoxia risk", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_LOW}", "engineering rule", "DO control rule", "Potential oxygen deficiency that may suppress nitrification."),
        ("critical_hypoxia", "严重缺氧(DO<1)", "Severe hypoxia", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_CRITICAL_LOW}", "engineering rule", "Emergency low-DO warning rule", "Critical aeration deficiency requiring intervention."),
        ("over_aeration", "过曝风险(DO>4)", "Over-aeration risk", f"max(N_On_DO,S_On_DO)>{FACTORY_DO_HIGH}", "engineering rule", "Energy-efficiency rule", "Potential excessive aeration and unnecessary energy use."),
        ("critical_over", "严重过曝(DO>6)", "Severe over-aeration", f"max(N_On_DO,S_On_DO)>{FACTORY_DO_CRITICAL_HIGH}", "engineering rule", "High-DO abnormality warning rule", "Extreme over-aeration or control inefficiency."),
        ("nitrification_stable", "硝化稳定", "Stable nitrification", f"min(N_On_DO,S_On_DO)>={FACTORY_DO_LOW} and S_On_AN<{FACTORY_SONAN_WARNING}", "engineering-bio rule", "DO-ammonia coupled nitrification judgment", "Aerobic-zone DO and ammonia remain in a stable nitrification regime."),
        ("nitrification_inhibition", "硝化受抑(DO<2, NH3≥2)", "Nitrification inhibition", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_LOW} and S_On_AN>={FACTORY_SONAN_WARNING}", "engineering-bio rule", "DO-ammonia coupled nitrification judgment", "Low DO coincides with elevated aerobic-zone ammonia, indicating nitrification suppression."),
        ("nitrification_failure", "硝化失败(DO<1, NH3≥5)", "Nitrification failure", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_CRITICAL_LOW} and S_On_AN>={FACTORY_SONAN_HIGH}", "engineering-bio rule", "Severe DO-ammonia coupled risk rule", "Critical oxygen deficiency coincides with high ammonia and signals severe nitrification deterioration."),
        ("false_safety", "⚠️ 虚假安全(DO正常, NH3高)", "False safety", f"{FACTORY_DO_LOW}<=DO<={FACTORY_DO_HIGH} and S_On_AN>={FACTORY_SONAN_HIGH}", "engineering-bio rule", "DO-normal but ammonia-abnormal hidden-risk rule", "DO appears normal while ammonia remains high, indicating hidden process risk."),
        ("inefficient_aeration", "无效曝气", "Inefficient aeration", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_LOW} and {TARGET_COL}>median", "engineering-energy rule", "High aeration but low-DO response", "Aeration input remains high but oxygen supply is still insufficient."),
        ("energy_waste", "过度曝气浪费", "Energy waste", f"max(N_On_DO,S_On_DO)>{FACTORY_DO_HIGH} and S_On_AN<0.5 and {TARGET_COL}>median", "engineering-energy rule", "High-DO with already low aerobic-zone ammonia", "Further aeration is unlikely to bring substantial treatment benefit."),
        ("ideal_control", "理想控制区", "Ideal control zone", f"{FACTORY_DO_LOW}<=DO<={FACTORY_DO_HIGH} and P25<={TARGET_COL}<=P75", "engineering rule", "Balanced aeration control zone", "Oxygen control and aeration intensity remain in a balanced operating range."),
        ("inflow_shock", "进水冲击", "Influent shock", f"In_Water>{thresholds['in_water_q90']:.2f} or In_COD>{thresholds['in_cod_q90']:.2f} or In_AN>{thresholds['in_an_q90']:.2f}", "data-driven percentile", "Plant historical data q90 thresholds", "Hydraulic or pollutant loading shock."),
        ("reuse_safe", "回用安全", "Reuse safe", f"Out_COD<={FACTORY_REUSE_COD} and Out_AN<={FACTORY_REUSE_AN} and Out_TN<={FACTORY_REUSE_TN}", "plant-specific warning", "Internal reclaimed-water safety threshold", "Effluent quality remains within a conservative reclaimed-water safety margin."),
        ("reuse_fragile", "回用脆弱(接近上限)", "Reuse fragile", f"(Out_COD>{FACTORY_REUSE_COD} or Out_AN>{FACTORY_REUSE_AN} or Out_TN>{FACTORY_REUSE_TN}) and full compliance", "plant-specific warning", "Internal reclaimed-water fragility threshold", "Effluent still complies with discharge limits but the reuse margin has narrowed."),
        ("reuse_risk", "回用风险", "Reuse risk", f"not reuse_safe", "plant-specific warning", "Internal reclaimed-water warning threshold", "Effluent quality no longer satisfies the conservative reuse-safety margin."),
        ("reuse_high_assurance", "回用高保障", "Reuse high assurance", f"Out_COD<={FACTORY_OUT_COD_WARNING} and Out_AN<={FACTORY_OUT_AN_WARNING} and Out_TN<={FACTORY_OUT_TN_WARNING}", "plant-specific warning", "High-assurance reclaimed-water margin", "Effluent quality remains comfortably below the internal warning thresholds."),
        ("reuse_early_warning", "回用预警(DO正常但水质抬升)", "Reuse early warning", f"{FACTORY_DO_LOW}<=DO<={FACTORY_DO_HIGH} and (Out_COD>{FACTORY_OUT_COD_WARNING} or Out_AN>{FACTORY_OUT_AN_WARNING} or Out_TN>{FACTORY_OUT_TN_WARNING})", "plant-specific warning", "DO-normal but reclaimed-water quality warning rule", "Process oxygen appears normal while effluent quality begins to rise toward the warning boundary."),
        ("all_bio_risk", "所有生化风险", "All biological risks", "hypoxia or over-aeration or false safety", "composite engineering rule", "Union of core biological risk scenarios", "Combined view of the main biological reaction risks."),
        ("all_critical", "所有极端工况", "All critical conditions", "critical hypoxia or critical over-aeration or nitrification failure", "composite engineering rule", "Union of critical operating scenarios", "Combined view of the most critical operating conditions."),
    ]
    rows = []
    for scene_id, cn, en, rule_def, source_type, source_reference, meaning in scene_defs:
        count = int(np.sum(masks[scene_id]))
        rows.append({
            "plant_name_cn": PLANT_NAME_CN,
            "plant_process": PLANT_PROCESS_CN,
            "discharge_standard": PLANT_DISCHARGE_STANDARD,
            "reuse_note": PLANT_REUSE_NOTE,
            "scenario_id": scene_id,
            "scenario_cn": cn,
            "scenario_en": en,
            "rule_definition": rule_def,
            "source_type": source_type,
            "source_reference": source_reference,
            "engineering_meaning": meaning,
            "sample_count": count,
            "sample_ratio_pct": round(100.0 * count / total, 2),
        })
    return pd.DataFrame(rows), thresholds


def compute_scene_summary(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    persistence_pred: np.ndarray,
    baseline_now: np.ndarray,
) -> Dict[str, float]:
    mae_model, rmse_model = safe_regression_metrics(y_true, y_pred)
    mae_persistence, rmse_persistence = safe_regression_metrics(y_true, persistence_pred)
    abs_delta = np.abs(y_true - baseline_now)
    change_mask = abs_delta >= np.quantile(abs_delta, TRANSITION_TOP_QUANTILE)
    _, rmse_delta_model = safe_regression_metrics(y_true[change_mask], y_pred[change_mask])
    _, rmse_delta_persistence = safe_regression_metrics(y_true[change_mask], persistence_pred[change_mask])
    mae_gain = np.nan if np.isnan(mae_persistence) or mae_persistence == 0 else 100.0 * (mae_persistence - mae_model) / mae_persistence
    rmse_gain = np.nan if np.isnan(rmse_persistence) or rmse_persistence == 0 else 100.0 * (rmse_persistence - rmse_model) / rmse_persistence
    delta_gain = np.nan if np.isnan(rmse_delta_persistence) or rmse_delta_persistence == 0 else 100.0 * (rmse_delta_persistence - rmse_delta_model) / rmse_delta_persistence
    return {
        "mae": mae_model,
        "rmse": rmse_model,
        "bias": safe_bias(y_true, y_pred),
        "persistence_mae": mae_persistence,
        "persistence_rmse": rmse_persistence,
        "mae_gain_pct_vs_persistence": mae_gain,
        "rmse_gain_pct_vs_persistence": rmse_gain,
        "rmse_delta_top10": rmse_delta_model,
        "persistence_rmse_delta_top10": rmse_delta_persistence,
        "delta_top10_gain_pct_vs_persistence": delta_gain,
        "n_delta_top10": float(np.sum(change_mask)),
    }


def build_factory_scene_diagnostics(
    eval_context_df: pd.DataFrame,
    y_true_selected: np.ndarray,
    y_pred_selected: np.ndarray,
    y_pred_persistence_selected: np.ndarray,
    baseline_now: np.ndarray,
    model_name: str,
) -> pd.DataFrame:
    method_df, thresholds = build_factory_method_table(eval_context_df)
    masks = build_factory_scene_masks(eval_context_df, thresholds)
    lookup = method_df.set_index("scenario_id").to_dict(orient="index")
    total = max(len(eval_context_df), 1)
    rows = []
    for idx, horizon in enumerate(HORIZON_MINS):
        for scene_id in method_df["scenario_id"].tolist():
            mask = masks[scene_id]
            n_samples = int(np.sum(mask))
            meta = lookup[scene_id]
            metric_payload = {
                "mae": np.nan,
                "rmse": np.nan,
                "bias": np.nan,
                "persistence_mae": np.nan,
                "persistence_rmse": np.nan,
                "mae_gain_pct_vs_persistence": np.nan,
                "rmse_gain_pct_vs_persistence": np.nan,
                "rmse_delta_top10": np.nan,
                "persistence_rmse_delta_top10": np.nan,
                "delta_top10_gain_pct_vs_persistence": np.nan,
                "n_delta_top10": 0.0,
            }
            if n_samples >= FACTORY_SCENE_MIN_SAMPLES:
                metric_payload = compute_scene_summary(
                    y_true=y_true_selected[:, idx][mask],
                    y_pred=y_pred_selected[:, idx][mask],
                    persistence_pred=y_pred_persistence_selected[:, idx][mask],
                    baseline_now=baseline_now[mask],
                )
            rows.append({
                "horizon_min": horizon,
                "model_type": model_name,
                "scenario_id": scene_id,
                "scenario_cn": meta["scenario_cn"],
                "scenario_en": meta["scenario_en"],
                "source_type": meta["source_type"],
                "source_reference": meta["source_reference"],
                "rule_definition": meta["rule_definition"],
                "engineering_meaning": meta["engineering_meaning"],
                "n_samples": n_samples,
                "sample_ratio_pct": round(100.0 * n_samples / total, 2),
                **metric_payload,
            })
    return pd.DataFrame(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="TimeMixer / SSA-Conv-PatchTST with decomposition features")
    parser.add_argument(
        "--model-name",
        default=MODEL_NAME,
        choices=("TimeMixer", "OfficialTimeMixer", SSA_CONV_PATCHTST_PUBLIC_NAME),
        help="Model backbone to train; TimeMixer is the arXiv:2405.14616 implementation.",
    )
    parser.add_argument("--random-state", type=int, default=RANDOM_STATE, help="Random seed for reproducibility")
    parser.add_argument("--output-tag", default="", help="Optional suffix appended to output filenames")
    parser.add_argument(
        "--engineering-low-thresholds",
        default="",
        help="Comma-separated engineering low thresholds for 30,60,90 min; use none to disable",
    )
    parser.add_argument(
        "--engineering-high-thresholds",
        default="",
        help="Comma-separated engineering high thresholds for 30,60,90 min; use none to disable",
    )
    parser.add_argument(
        "--decomp-method",
        default=DECOMP_METHOD,
        choices=SUPPORTED_DECOMP_METHODS,
        help="Decomposition method used to generate auxiliary features",
    )
    parser.add_argument("--ablate-no-ssa", action="store_true", help="Disable decomposition features and use the raw base features only.")
    parser.add_argument("--ablate-no-conv", action="store_true", help="Disable the local convolution stem and fall back to the plain PatchTSTExtreme backbone.")
    parser.add_argument("--use-density-loss", action="store_true", help="Use DensityAwareExtremeLoss instead of the default plain MSE loss.")
    parser.add_argument("--ablate-no-asym", action="store_true", help="Legacy switch retained for compatibility. Ignored under the current MSE/DensityAware loss scheme.")
    parser.add_argument("--ablate-no-density", action="store_true", help="Legacy compatibility flag. Under the current MSE mainline it keeps the plain MSE loss.")
    parser.add_argument("--ablate-no-transition", action="store_true", help="Legacy switch retained for compatibility. Ignored under the current MSE/DensityAware loss scheme.")
    parser.add_argument(
        "--decomp-components",
        type=int,
        default=DECOMP_NUM_COMPONENTS,
        help="Number of decomposition components kept per source variable",
    )
    parser.add_argument(
        "--ssa-components",
        type=int,
        default=SSA_FIXED_NUM_COMPONENTS,
        help="Number of SSA components kept per source variable when --decomp-method ssa",
    )
    parser.add_argument(
        "--ssa-window",
        type=int,
        default=SSA_FIXED_WINDOW,
        help="SSA embedding window length when --decomp-method ssa",
    )
    parser.add_argument(
        "--auto-search-decomp",
        action="store_true",
        help="Automatically search decomposition parameters; VMD uses WOA, while SSA is now fixed to the selected best configuration and other methods use lightweight proxy search",
    )
    parser.add_argument(
        "--search-max-candidates",
        type=int,
        default=DECOMP_SEARCH_MAX_CANDIDATES,
        help="Maximum number of non-VMD decomposition candidates evaluated by the proxy scorer",
    )
    parser.add_argument(
        "--ssa-search-mode",
        default=SSA_SEARCH_MODE,
        choices=("exact", "staged"),
        help="SSA-only search mode option retained for compatibility; current SSA runs use the fixed selected best configuration",
    )
    parser.add_argument(
        "--ssa-rerank-topk",
        type=int,
        default=SSA_RERANK_TOPK,
        help="SSA-only rerank option retained for compatibility; current SSA runs use the fixed selected best configuration",
    )
    parser.add_argument("--use-woa-vmd", action="store_true", help="Use whale optimization to search VMD K/alpha")
    parser.add_argument("--woa-pop", type=int, default=WOA_POP_SIZE, help="WOA population size for VMD search")
    parser.add_argument("--woa-iters", type=int, default=WOA_ITERS, help="WOA iterations for VMD search")
    parser.add_argument("--vmd-modes", type=int, default=VMD_NUM_MODES, help="Default VMD mode count when WOA is off")
    parser.add_argument("--vmd-alpha", type=float, default=VMD_ALPHA, help="Default VMD alpha when WOA is off")
    return parser.parse_args()


def compute_horizon_diagnostics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    persistence_pred: np.ndarray,
    baseline_now: np.ndarray,
    low_threshold: float,
    high_threshold: float,
    delta_quantile: float = 0.9,
) -> Dict[str, float]:
    metrics: Dict[str, float] = {}

    low_mask = y_true <= low_threshold
    high_mask = y_true >= high_threshold
    delta = y_true - baseline_now
    change_mask = np.abs(delta) >= np.quantile(np.abs(delta), delta_quantile)

    metrics["mae_low"], metrics["rmse_low"] = safe_regression_metrics(y_true[low_mask], y_pred[low_mask])
    metrics["mae_high"], metrics["rmse_high"] = safe_regression_metrics(y_true[high_mask], y_pred[high_mask])
    metrics["bias_low"] = safe_bias(y_true[low_mask], y_pred[low_mask])
    metrics["bias_high"] = safe_bias(y_true[high_mask], y_pred[high_mask])
    _, metrics["rmse_delta_top10"] = safe_regression_metrics(y_true[change_mask], y_pred[change_mask])
    _, metrics["rmse_delta_top10_persistence"] = safe_regression_metrics(
        y_true[change_mask], persistence_pred[change_mask]
    )

    pred_low_event = (y_pred <= low_threshold).astype(int)
    pred_high_event = (y_pred >= high_threshold).astype(int)
    persistence_low_event = (persistence_pred <= low_threshold).astype(int)
    persistence_high_event = (persistence_pred >= high_threshold).astype(int)
    true_low_event = low_mask.astype(int)
    true_high_event = high_mask.astype(int)

    low_cls = classification_metrics_from_events(true_low_event, pred_low_event)
    high_cls = classification_metrics_from_events(true_high_event, pred_high_event)
    low_cls_persist = classification_metrics_from_events(true_low_event, persistence_low_event)
    high_cls_persist = classification_metrics_from_events(true_high_event, persistence_high_event)

    metrics["n_low"] = float(low_mask.sum())
    metrics["n_high"] = float(high_mask.sum())
    metrics["n_delta_top10"] = float(change_mask.sum())

    for key, value in low_cls.items():
        metrics[f"{key}_low"] = value
    for key, value in high_cls.items():
        metrics[f"{key}_high"] = value
    for key, value in low_cls_persist.items():
        metrics[f"persistence_{key}_low"] = value
    for key, value in high_cls_persist.items():
        metrics[f"persistence_{key}_high"] = value

    return metrics


def prefix_metric_keys(metrics: Dict[str, float], prefix: str) -> Dict[str, float]:
    return {f"{prefix}_{k}": v for k, v in metrics.items()}


def build_time_mark_array(ts: pd.Series, freq: str) -> np.ndarray:
    idx = pd.DatetimeIndex(pd.to_datetime(ts))
    return TSLIB_TIME_FEATURES(idx, freq=freq).transpose(1, 0).astype(np.float32)


def inverse_target_scale(values_scaled: np.ndarray, scaler: MinMaxScaler, target_idx: int) -> np.ndarray:
    return (values_scaled - scaler.min_[target_idx]) / scaler.scale_[target_idx]


def build_official_seq_dataset(
    df_in: pd.DataFrame,
    feature_cols: List[str],
    seq_len: int,
    label_len: int,
    pred_len: int,
    freq: str,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    keep_cols = [TIME_COL] + feature_cols
    temp = df_in[keep_cols].dropna().copy().reset_index(drop=True)
    feature_data = temp[feature_cols].to_numpy(dtype=np.float32)
    time_data = pd.to_datetime(temp[TIME_COL]).reset_index(drop=True)
    time_mark = build_time_mark_array(time_data, freq=freq)
    target_idx = feature_cols.index(TARGET_COL)

    X_seq, Y_seq, X_mark, Y_mark, y_true, t_ref = [], [], [], [], [], []
    max_end = len(temp) - pred_len

    for end_idx in range(seq_len - 1, max_end):
        x_start = end_idx - seq_len + 1
        label_start = end_idx - label_len + 1
        future_start = end_idx + 1
        future_end = future_start + pred_len

        enc_x = feature_data[x_start:end_idx + 1]
        enc_mark = time_mark[x_start:end_idx + 1]

        dec_hist = feature_data[label_start:end_idx + 1]
        dec_future = feature_data[future_start:future_end]
        dec_y = np.concatenate([dec_hist, dec_future], axis=0)

        dec_hist_mark = time_mark[label_start:end_idx + 1]
        dec_future_mark = time_mark[future_start:future_end]
        dec_mark = np.concatenate([dec_hist_mark, dec_future_mark], axis=0)

        X_seq.append(enc_x)
        X_mark.append(enc_mark)
        Y_seq.append(dec_y)
        Y_mark.append(dec_mark)
        y_true.append(dec_future[:, target_idx])
        t_ref.append(time_data.iloc[end_idx])

    return (
        np.asarray(X_seq, dtype=np.float32),
        np.asarray(Y_seq, dtype=np.float32),
        np.asarray(X_mark, dtype=np.float32),
        np.asarray(Y_mark, dtype=np.float32),
        np.asarray(y_true, dtype=np.float32),
        np.asarray(t_ref),
    )


def build_density_weight_tables(
    train_targets_selected: np.ndarray,
    num_bins: int,
    smooth_sigma: float,
    rarity_power: float,
) -> Tuple[np.ndarray, np.ndarray]:
    edge_tables = []
    rarity_tables = []

    radius = max(1, int(math.ceil(3 * smooth_sigma)))
    offsets = np.arange(-radius, radius + 1, dtype=np.float32)
    kernel = np.exp(-0.5 * (offsets / smooth_sigma) ** 2)
    kernel = kernel / kernel.sum()

    for col in range(train_targets_selected.shape[1]):
        values = train_targets_selected[:, col].astype(np.float32)
        vmin, vmax = float(values.min()), float(values.max())
        if vmax <= vmin:
            vmax = vmin + 1.0
        edges = np.linspace(vmin, vmax, num_bins + 1, dtype=np.float32)
        hist, _ = np.histogram(values, bins=edges)
        hist = hist.astype(np.float32)
        smooth = np.convolve(hist, kernel, mode="same") + 1e-6
        rarity = np.power(smooth.mean() / smooth, rarity_power).astype(np.float32)
        rarity = rarity / rarity.mean()
        edge_tables.append(edges)
        rarity_tables.append(rarity)

    return np.stack(edge_tables, axis=0), np.stack(rarity_tables, axis=0)


def build_model(model_name: str, configs: Config) -> nn.Module:
    model_key = model_name.lower()
    if model_key in {"timemixer", "officialtimemixer"}:
        print(
            "TIMEMIXER_CONFIG: "
            f"d_model={configs.d_model}, d_ff={configs.d_ff}, "
            f"moving_avg={configs.moving_avg}, top_k={configs.top_k}, "
            f"channel_independence={configs.channel_independence}, "
            f"decomp_method={configs.decomp_method}, "
            f"down_sampling_layers={configs.down_sampling_layers}, "
            f"down_sampling_window={configs.down_sampling_window}, "
            f"down_sampling_method={configs.down_sampling_method}"
        )
        return TimeMixerOriginalModel(configs)

    if model_key not in SSA_CONV_PATCHTST_KEYS:
        raise ValueError(
            "This script supports TimeMixer and SSA-Conv-PatchTST. "
            f"Received: {model_name}"
        )
    model_cls = PatchTSTExtremeModel if ABLATE_NO_CONV else PatchTSTExtremeConvModel
    return model_cls(
        configs=configs,
        patch_len=configs.patch_len,
        stride=configs.stride,
        horizon_indices=[h - 1 for h in HORIZON_MINS],
    )


def build_training_criterion(
    model_name: str,
    train_targets_selected: np.ndarray,
    train_current_targets: np.ndarray,
    train_targets_full: np.ndarray,
) -> nn.Module:
    model_key = model_name.lower()
    if model_key in {"timemixer", "officialtimemixer"}:
        if USE_DENSITY_LOSS and not ABLATE_NO_DENSITY:
            print("TIMEMIXER_LOSS_INFO: original TimeMixer uses MSE; using plain MSELoss.")
        else:
            print("TIMEMIXER_LOSS_INFO: using original plain MSELoss.")
        return nn.MSELoss()

    if model_key not in SSA_CONV_PATCHTST_KEYS:
        raise ValueError(
            "This script supports TimeMixer and the SSA-Conv-PatchTST loss path."
        )

    low_thresholds = np.quantile(train_targets_selected, EXTREME_TAIL_QUANTILE, axis=0).astype(np.float32)
    high_thresholds = np.quantile(train_targets_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0).astype(np.float32)
    horizon_weights = EXTREME_HORIZON_WEIGHTS
    low_weights = EXTREME_LOW_WEIGHTS
    high_weights = EXTREME_HIGH_WEIGHTS
    density_edges, density_weights = build_density_weight_tables(
        train_targets_selected=train_targets_selected,
        num_bins=DENSITY_NUM_BINS,
        smooth_sigma=DENSITY_SMOOTH_SIGMA,
        rarity_power=DENSITY_WEIGHT_POWER,
    )
    density_blend = DENSITY_WEIGHT_BLEND if USE_DENSITY_LOSS and not ABLATE_NO_DENSITY else 0.0
    mode_name = "density_aware" if USE_DENSITY_LOSS and not ABLATE_NO_DENSITY else "mse"

    horizon_pairs = ", ".join(
        f"h{h}:lw={lw:.2f},hw={hw:.2f},pw={pw:.2f}"
        for h, lw, hw, pw in zip(HORIZON_MINS, low_weights, high_weights, horizon_weights)
    )
    print(
        "EXTREME_LOSS_INFO: "
        f"mode={mode_name}, "
        f"q={EXTREME_TAIL_QUANTILE}, "
        f"low_thr={[round(float(v), 3) for v in low_thresholds]}, "
        f"high_thr={[round(float(v), 3) for v in high_thresholds]}, "
        f"{horizon_pairs}, "
        f"density_bins={DENSITY_NUM_BINS}, sigma={DENSITY_SMOOTH_SIGMA}, "
        f"blend={density_blend}, power={DENSITY_WEIGHT_POWER}"
    )
    if ABLATE_NO_ASYM or ABLATE_NO_TRANSITION:
        print(
            "ABLATION_INFO: "
            "no_asym/no_transition are legacy switches for this script. "
            "They are ignored under the current MSE/DensityAware loss scheme."
        )
    if not USE_DENSITY_LOSS or ABLATE_NO_DENSITY:
        if USE_DENSITY_LOSS and ABLATE_NO_DENSITY:
            print("ABLATION_INFO: no_density=True -> forcing plain MSELoss.")
        else:
            print("FORMAL_LOSS_INFO: using plain MSELoss as the default formal loss.")
        return nn.MSELoss()

    print("FORMAL_LOSS_INFO: using DensityAwareExtremeLoss as the optional loss variant.")
    return DensityAwareExtremeLoss(
        horizon_indices=[h - 1 for h in HORIZON_MINS],
        low_thresholds=low_thresholds.tolist(),
        high_thresholds=high_thresholds.tolist(),
        horizon_weights=horizon_weights,
        low_weights=low_weights,
        high_weights=high_weights,
        density_bin_edges=density_edges,
        density_bin_weights=density_weights,
        density_weight_blend=density_blend,
    )


def amp_enabled_for_model(model_name: str, device: str) -> bool:
    return USE_AMP and device.startswith("cuda")


def extract_forecast_tensor(model_output: torch.Tensor | Dict[str, torch.Tensor]) -> torch.Tensor:
    if isinstance(model_output, dict):
        return model_output["forecast"]
    return model_output


def forward_official(
    model: nn.Module,
    batch_x: torch.Tensor,
    batch_y: torch.Tensor,
    batch_x_mark: torch.Tensor,
    batch_y_mark: torch.Tensor,
    cfg: Config,
) -> Tuple[torch.Tensor, torch.Tensor]:
    true = batch_y[:, -cfg.pred_len:, -1:]

    dec_inp = torch.zeros_like(batch_y[:, -cfg.pred_len:, :], device=batch_y.device)
    dec_inp = torch.cat([batch_y[:, :cfg.label_len, :], dec_inp], dim=1)

    outputs = model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
    pred_full = extract_forecast_tensor(outputs)
    f_dim = -1 if cfg.features == "MS" else 0
    pred = pred_full[:, -cfg.pred_len:, f_dim:]
    if isinstance(outputs, dict):
        pred_bundle = dict(outputs)
        pred_bundle["forecast"] = pred
        if "current_target" not in pred_bundle:
            pred_bundle["current_target"] = batch_x[:, -1, -1]
        return pred_bundle, true
    return pred, true


def train_model(
    model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    cfg: Config,
    model_name: str,
    criterion: nn.Module,
    epochs: int,
    lr: float,
    patience: int,
    device: str,
    verbose: bool = True,
) -> nn.Module:
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=WEIGHT_DECAY)
    amp_enabled = amp_enabled_for_model(model_name, device)
    scaler = torch.cuda.amp.GradScaler(enabled=amp_enabled)

    model.to(device)
    criterion = criterion.to(device)
    best_val = float("inf")
    best_state = None
    wait = 0
    epoch_times = []

    for epoch in range(1, epochs + 1):
        epoch_start = time.perf_counter()
        model.train()
        train_losses = []
        for xb, yb, xb_mark, yb_mark in train_loader:
            xb = xb.to(device, non_blocking=PIN_MEMORY)
            yb = yb.to(device, non_blocking=PIN_MEMORY)
            xb_mark = xb_mark.to(device, non_blocking=PIN_MEMORY)
            yb_mark = yb_mark.to(device, non_blocking=PIN_MEMORY)
            current_target = xb[:, -1, -1].view(-1, 1, 1)

            optimizer.zero_grad()
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled):
                pred, true = forward_official(model, xb, yb, xb_mark, yb_mark, cfg)
                if getattr(criterion, "requires_current_target", False):
                    loss = criterion(pred, true, current_target)
                else:
                    loss = criterion(pred, true)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            train_losses.append(loss.item())

        model.eval()
        val_losses = []
        with torch.no_grad():
            for xb, yb, xb_mark, yb_mark in val_loader:
                xb = xb.to(device, non_blocking=PIN_MEMORY)
                yb = yb.to(device, non_blocking=PIN_MEMORY)
                xb_mark = xb_mark.to(device, non_blocking=PIN_MEMORY)
                yb_mark = yb_mark.to(device, non_blocking=PIN_MEMORY)
                current_target = xb[:, -1, -1].view(-1, 1, 1)

                with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled):
                    pred, true = forward_official(model, xb, yb, xb_mark, yb_mark, cfg)
                    if getattr(criterion, "requires_current_target", False):
                        loss = criterion(pred, true, current_target)
                    else:
                        loss = criterion(pred, true)
                val_losses.append(loss.item())

        train_loss = float(np.mean(train_losses)) if train_losses else np.nan
        val_loss = float(np.mean(val_losses)) if val_losses else np.nan
        epoch_time = time.perf_counter() - epoch_start
        epoch_times.append(epoch_time)
        if verbose:
            print(
                f"Epoch [{epoch}/{epochs}] Train Loss: {train_loss:.6f} | "
                f"Val Loss: {val_loss:.6f} | Epoch Time: {epoch_time:.2f}s ({epoch_time / 60:.2f} min)"
            )

        if val_loss < best_val:
            best_val = val_loss
            best_state = copy.deepcopy(model.state_dict())
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                if verbose:
                    print(f"Early stopping at epoch {epoch}")
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    if epoch_times:
        total_time = float(sum(epoch_times))
        avg_time = total_time / len(epoch_times)
        if verbose:
            print(
                f"Training Time Summary | Total: {total_time:.2f}s ({total_time / 60:.2f} min) | "
                f"Epochs Run: {len(epoch_times)} | Avg/Epoch: {avg_time:.2f}s ({avg_time / 60:.2f} min)"
            )
    return model


def predict_in_batches(
    model: nn.Module,
    X_np: np.ndarray,
    Y_np: np.ndarray,
    X_mark_np: np.ndarray,
    Y_mark_np: np.ndarray,
    cfg: Config,
    model_name: str,
    batch_size: int,
    device: str,
) -> np.ndarray:
    model.eval()
    preds = []
    amp_enabled = amp_enabled_for_model(model_name, device)
    with torch.no_grad():
        for start in range(0, len(X_np), batch_size):
            end = start + batch_size
            xb = torch.tensor(X_np[start:end], dtype=torch.float32, device=device)
            yb = torch.tensor(Y_np[start:end], dtype=torch.float32, device=device)
            xb_mark = torch.tensor(X_mark_np[start:end], dtype=torch.float32, device=device)
            yb_mark = torch.tensor(Y_mark_np[start:end], dtype=torch.float32, device=device)

            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled):
                pred, _ = forward_official(model, xb, yb, xb_mark, yb_mark, cfg)
            forecast = extract_forecast_tensor(pred)
            preds.append(forecast.detach().cpu().numpy().squeeze(-1))

    return np.concatenate(preds, axis=0)


# =========================
# 4. Main
# =========================
def main() -> None:
    global MODEL_NAME, RANDOM_STATE, ENGINEERING_LOW_THRESHOLDS, ENGINEERING_HIGH_THRESHOLDS
    global ABLATE_NO_SSA, ABLATE_NO_CONV, ABLATE_NO_ASYM, ABLATE_NO_DENSITY, ABLATE_NO_TRANSITION, USE_DENSITY_LOSS
    args = parse_args()
    MODEL_NAME = args.model_name
    RANDOM_STATE = args.random_state
    ABLATE_NO_SSA = bool(args.ablate_no_ssa)
    ABLATE_NO_CONV = bool(args.ablate_no_conv)
    ABLATE_NO_ASYM = bool(args.ablate_no_asym)
    ABLATE_NO_DENSITY = bool(args.ablate_no_density)
    ABLATE_NO_TRANSITION = bool(args.ablate_no_transition)
    USE_DENSITY_LOSS = bool(args.use_density_loss)
    decomp_method = args.decomp_method.lower().strip()
    if ABLATE_NO_SSA:
        decomp_method = "none"
    decomp_components = 0 if ABLATE_NO_SSA else max(1, int(args.decomp_components))
    output_tag = args.output_tag.strip() or ("ablate_no_ssa" if ABLATE_NO_SSA else decomp_method)
    use_woa_vmd = bool(args.use_woa_vmd or (args.auto_search_decomp and decomp_method == "vmd"))
    if args.engineering_low_thresholds.strip():
        ENGINEERING_LOW_THRESHOLDS = parse_threshold_arg(args.engineering_low_thresholds)
    if args.engineering_high_thresholds.strip():
        ENGINEERING_HIGH_THRESHOLDS = parse_threshold_arg(args.engineering_high_thresholds)

    print("=" * 80)
    print("TimeMixer / SSA-Conv-PatchTST decomposition experiment")
    print("=" * 80)
    print(f"MODEL_NAME: {MODEL_NAME}")
    print(f"DEVICE: {DEVICE}")
    print(f"TSLIB_ROOT: {TSLIB_ROOT}")
    print(f"INPUT_FILE: {INPUT_FILE}")
    print(f"TARGET_COL: {TARGET_COL}")
    print(f"HORIZON_MINS: {HORIZON_MINS}")
    print(f"SEQ_LEN: {SEQ_LEN}")
    print(f"LABEL_LEN: {LABEL_LEN}")
    print(f"PRED_LEN: {PRED_LEN}")
    print(f"PATCH_LEN: {PATCH_LEN}")
    print(f"BATCH_SIZE: {BATCH_SIZE}")
    print(f"NUM_WORKERS: {NUM_WORKERS}")
    print(f"PIN_MEMORY: {PIN_MEMORY}")
    print(f"USE_AMP: {USE_AMP}")
    print(f"EFFECTIVE_AMP: {amp_enabled_for_model(MODEL_NAME, DEVICE)}")
    print(f"RANDOM_STATE: {RANDOM_STATE}")
    print(f"OUTPUT_TAG: {output_tag or '(none)'}")
    print(f"ENGINEERING_LOW_THRESHOLDS: {ENGINEERING_LOW_THRESHOLDS}")
    print(f"ENGINEERING_HIGH_THRESHOLDS: {ENGINEERING_HIGH_THRESHOLDS}")
    print(f"DECOMP_METHOD: {decomp_method}")
    print(
        "ABLATION_SWITCHES: "
        f"no_ssa={ABLATE_NO_SSA}, "
        f"no_conv={ABLATE_NO_CONV}, "
        f"no_asym={ABLATE_NO_ASYM}, "
        f"no_density={ABLATE_NO_DENSITY}, "
        f"no_transition={ABLATE_NO_TRANSITION}, "
        f"use_density_loss={USE_DENSITY_LOSS}"
    )
    print(f"DECOMP_COMPONENTS: {decomp_components}")
    print(f"AUTO_SEARCH_DECOMP: {args.auto_search_decomp}")
    print(f"SEARCH_MAX_CANDIDATES: {args.search_max_candidates}")
    print(f"SSA_SEARCH_MODE: {args.ssa_search_mode}")
    print(f"SSA_RERANK_TOPK: {args.ssa_rerank_topk}")
    print(f"USE_WOA_VMD: {use_woa_vmd}")

    set_seed(RANDOM_STATE)

    df = pd.read_csv(INPUT_FILE)
    df[TIME_COL] = pd.to_datetime(df[TIME_COL], errors="coerce")
    df = df.dropna(subset=[TIME_COL]).sort_values(TIME_COL).reset_index(drop=True)

    decomp_source_cols = [] if decomp_method == "none" else safe_cols(df, get_decomp_source_seed(decomp_method, for_proxy=False))
    vmd_modes = int(args.vmd_modes)
    vmd_alpha = float(args.vmd_alpha)
    decomp_kwargs: Dict[str, object] = {}
    horizon_tag = "_".join(str(h) for h in HORIZON_MINS)
    file_suffix = f"{MODEL_NAME}_seed{RANDOM_STATE}_h{horizon_tag}"
    if output_tag:
        file_suffix = f"{file_suffix}_{output_tag}"
    print(f"DECOMP_SOURCES: {decomp_source_cols}")
    if decomp_method == "none":
        decomp_components = 0
        decomp_kwargs = {}
        use_woa_vmd = False
    elif decomp_method == "vmd":
        decomp_components = vmd_modes
    elif decomp_method == "ssa":
        decomp_components = max(1, int(args.ssa_components))
        ssa_window = max(2, int(args.ssa_window))
        decomp_kwargs = {"window": ssa_window}
        if args.auto_search_decomp:
            print(
                "SSA_PARAM_CONFIG_INFO: "
                f"auto-search skipped, using command-line SSA parameters "
                f"num_components={decomp_components}, window={ssa_window}"
            )
        else:
            print(
                "SSA_PARAM_CONFIG_INFO: "
                f"using SSA parameters "
                f"num_components={decomp_components}, window={ssa_window}"
            )
    if use_woa_vmd and decomp_method != "vmd":
        raise ValueError("--use-woa-vmd 目前只支持 --decomp-method vmd")
    if use_woa_vmd:
        vmd_modes, vmd_alpha, search_score = whale_optimize_vmd(
            df_in=df,
            base_feature_cols=BASE_FEATURE_COLS,
            source_cols=decomp_source_cols,
            pop_size=int(args.woa_pop),
            iters=int(args.woa_iters),
            k_min=WOA_K_MIN,
            k_max=WOA_K_MAX,
            alpha_min=WOA_ALPHA_MIN,
            alpha_max=WOA_ALPHA_MAX,
        )
        print(
            "WOA_VMD_FINAL: "
            f"K={vmd_modes}, alpha={vmd_alpha:.2f}, proxy_score={search_score:.4f}"
        )
        decomp_components = vmd_modes
    elif args.auto_search_decomp and decomp_method not in {"ssa", "none"}:
        decomp_components, decomp_kwargs, search_score, score_label = search_non_vmd_decomposition(
            df_in=df,
            base_feature_cols=BASE_FEATURE_COLS,
            method=decomp_method,
            source_cols=decomp_source_cols,
            max_candidates=int(args.search_max_candidates),
        )
        print(
            "DECOMP_SEARCH_FINAL: "
            f"method={decomp_method}, "
            f"num_components={decomp_components}, "
            f"params={format_decomp_kwargs(decomp_method, decomp_kwargs)}, "
            f"{score_label}={search_score:.4f}"
        )

    result = run_decomposition_experiment(
        df_in=df,
        base_feature_cols=BASE_FEATURE_COLS,
        method=decomp_method,
        source_cols=decomp_source_cols,
        num_components=decomp_components,
        alpha=vmd_alpha,
        decomp_kwargs=decomp_kwargs,
        include_predictions=True,
    )
    feature_cols = result["feature_cols"]
    decomp_cols = result["generated_cols"]
    summary_df = result["summary_df"]
    diagnostic_df = result["diagnostic_df"]
    scene_diagnostic_df = result["scene_diagnostic_df"]
    method_table_df = result["method_table_df"]
    pred_df = result["pred_df"]
    print(
        "DECOMP_FEATURE_INFO: "
        f"method={decomp_method}, "
        f"sources={decomp_source_cols}, "
        f"num_components={decomp_components}, "
        f"alpha={vmd_alpha:.2f}, "
        f"params={format_decomp_kwargs(decomp_method, decomp_kwargs)}, "
        f"generated={len(decomp_cols)}, "
        f"total_features={len(feature_cols)}, "
        f"weighted_rmse={result['weighted_rmse']:.4f}"
    )

    summary_path = os.path.join(OUTPUT_DIR, f"summary_{file_suffix}.csv")
    diagnostic_path = os.path.join(OUTPUT_DIR, f"diagnostics_{file_suffix}.csv")
    scene_diagnostic_path = os.path.join(OUTPUT_DIR, f"scene_diagnostics_{file_suffix}.csv")
    method_table_path = os.path.join(OUTPUT_DIR, f"scene_method_table_{file_suffix}.csv")
    pred_path = os.path.join(OUTPUT_DIR, f"predictions_{file_suffix}.csv")
    summary_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
    diagnostic_df.to_csv(diagnostic_path, index=False, encoding="utf-8-sig")
    scene_diagnostic_df.to_csv(scene_diagnostic_path, index=False, encoding="utf-8-sig")
    method_table_df.to_csv(method_table_path, index=False, encoding="utf-8-sig")
    pred_df.to_csv(pred_path, index=False, encoding="utf-8-sig")

    print("\n" + "=" * 80)
    print("Results")
    print("=" * 80)
    print(summary_df.to_string(index=False))
    scene_preview_cols = [
        "horizon_min",
        "scenario_cn",
        "n_samples",
        "sample_ratio_pct",
        "rmse",
        "persistence_rmse",
        "rmse_gain_pct_vs_persistence",
        "rmse_delta_top10",
        "persistence_rmse_delta_top10",
        "delta_top10_gain_pct_vs_persistence",
    ]
    print("\nScene Diagnostics")
    print("=" * 80)
    print(scene_diagnostic_df[scene_preview_cols].to_string(index=False))
    print("\nDiagnostics")
    print("=" * 80)
    print(diagnostic_df.to_string(index=False))
    print(f"\nSaved summary to: {summary_path}")
    print(f"Saved diagnostics to: {diagnostic_path}")
    print(f"Saved scene diagnostics to: {scene_diagnostic_path}")
    print(f"Saved scene method table to: {method_table_path}")
    print(f"Saved predictions to: {pred_path}")


if __name__ == "__main__":
    main()
