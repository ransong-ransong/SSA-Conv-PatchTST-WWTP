# -*- coding: utf-8 -*-
"""Unified command-line dispatcher for the experiment scripts."""

from __future__ import annotations

import argparse
import runpy
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent

ENTRYPOINTS = {
    "ssa": SCRIPT_DIR / "train_ssa_conv_patchtst.py",
    "baseline": SCRIPT_DIR / "train_baselines.py",
    "external": SCRIPT_DIR / "train_external_validation.py",
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run SSA-Conv-PatchTST-WWTP experiments")
    parser.add_argument(
        "--mode",
        choices=sorted(ENTRYPOINTS),
        required=True,
        help="Experiment entrypoint: ssa, baseline, or external.",
    )
    args, passthrough = parser.parse_known_args()

    script = ENTRYPOINTS[args.mode]
    if not script.exists():
        raise FileNotFoundError(f"Entrypoint not found: {script}")

    sys.argv = [str(script), *passthrough]
    runpy.run_path(str(script), run_name="__main__")


if __name__ == "__main__":
    main()

