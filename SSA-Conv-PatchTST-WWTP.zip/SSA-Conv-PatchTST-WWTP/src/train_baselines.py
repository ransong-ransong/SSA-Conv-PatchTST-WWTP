# -*- coding: utf-8 -*-
"""
Official TSLib model comparison script.

This script keeps the user's chronological split / scaling / export workflow,
but replaces all custom "official-style" approximations with the real official
model classes from TSLib.

Supported backbones / hybrids:
- TimeXer
- iTransformer
- PatchTST
- PatchTSTKAN
- PatchTSTExtremeConv
- PatchTSTExtremeTCNFront
- PatchTSTExtremeConvDeep
- PatchTSTExtremeCNN
- PatchTSTExtremeAsymmetric
- PatchTSTExtremeAsymmetricV2
- PatchTSTExtremeMultiScale
- TCN
- NBEATSx
- DeepARLike
- LSTM
- GRU
- Crossformer
- Autoformer
- TimesNet
- SCINet
- DLinear
- TiDE
"""

import copy
import argparse
import importlib
import importlib.util
import math
import os
import random
import sys
import time
import types
import warnings
from dataclasses import dataclass
from typing import Dict, List, Tuple

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import DataLoader, TensorDataset


# =========================
# 1. Paths and basic settings
# =========================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(SCRIPT_DIR)
INPUT_FILE = os.environ.get(
    "WWTP_INPUT_FILE",
    os.path.join(REPO_ROOT, "data", "processed", "device_data_wide_final_1min1_filtered_ffill.csv"),
)
OUTPUT_DIR = os.environ.get("WWTP_OUTPUT_DIR", os.path.join(REPO_ROOT, "results", "generated"))
TSLIB_ROOT = os.environ.get(
    "TSLIB_OFFICIAL_ROOT",
    r"C:\Users\71863\Documents\Playground\TSLib_official",
)
os.makedirs(OUTPUT_DIR, exist_ok=True)

if not os.path.isdir(TSLIB_ROOT):
    raise FileNotFoundError(
        f"TSLIB_OFFICIAL_ROOT not found: {TSLIB_ROOT}\n"
        "Set environment variable TSLIB_OFFICIAL_ROOT to your official TSLib path."
    )

if TSLIB_ROOT not in sys.path:
    sys.path.insert(0, TSLIB_ROOT)


def ensure_tslib_optional_dependencies() -> None:
    try:
        importlib.import_module("einops")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "Missing required dependency 'einops'. Install it in the same Python environment with:\n"
            r"D:\pc\pythonProject\.venv\Scripts\python.exe -m pip install einops"
        ) from exc

    if "reformer_pytorch" in sys.modules:
        return

    try:
        importlib.import_module("reformer_pytorch")
        return
    except ModuleNotFoundError:
        pass

    stub_module = types.ModuleType("reformer_pytorch")

    class LSHSelfAttention(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def forward(self, x, **kwargs):
            return x

    stub_module.LSHSelfAttention = LSHSelfAttention
    sys.modules["reformer_pytorch"] = stub_module


ensure_tslib_optional_dependencies()


TIME_COL = "sample_time"
TARGET_COL = "Main_AirV"
HORIZON_MINS = [30, 60, 90]
TRAIN_RATIO = 0.8
RANDOM_STATE = 7

SEQ_LEN = 180
LABEL_LEN = 60
PRED_LEN = max(HORIZON_MINS)
PATCH_LEN = 10

BATCH_SIZE = 64
EPOCHS = 100
PATIENCE = 10
LR = 1e-4
WEIGHT_DECAY = 1e-5
NUM_WORKERS = 0
PIN_MEMORY = torch.cuda.is_available()
USE_AMP = torch.cuda.is_available()

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

if torch.cuda.is_available():
    torch.backends.cudnn.benchmark = True

MODEL_NAME = "PatchTSTExtremeConv"
# "TimeXer"
# "iTransformer"
# "PatchTST"
# "PatchTSTKAN"
# "PatchTSTHead"
# "PatchTSTHeadTail"
# "PatchTSTHeadHorizon"
# "PatchTSTExtreme"
# "PatchTSTExtremeConv"
# "PatchTSTExtremeConvV1"
# "PatchTSTExtremeConvAsymmetricV2"
# "PatchTSTExtremeConvAsymmetricV2FreezeTune"
# "PatchTSTExtremeConvTargetBranch"
# "PatchTSTExtremeTCNFront"
# "PatchTSTExtremeConvDeep"
# "PatchTSTExtremeCNN"
# "PatchTSTExtremeAsymmetric"
# "PatchTSTExtremeAsymmetricV2"
# "PatchTSTExtremeMultiScale"
# "PatchTSTExtremeAdaptive"
# "PatchTSTExtremeEvent"
# "PatchTSTExtremeRefine"
# "TCN"
# "NBEATSx"
# "DeepARLike"
# "LSTM"
# "GRU"
# "Crossformer"
# "Autoformer"
# "TimesNet"
# "SCINet"
# "DLinear"
# "TiDE"

BASE_FEATURE_COLS = [
    "In_Water",
    "In_COD",
    "In_AN",
    "N_On_DO",
    "S_On_DO",
    "Out_AN",
    "Out_TN",
    "Out_COD",
    "Main_AirV",  # target MUST be last
]

MODEL_MODULES: Dict[str, str] = {
    "timexer": "TimeXer",
    "itransformer": "iTransformer",
    "patchtst": "PatchTST",
    "patchtstkan": "custom",
    "patchtsthead": "PatchTST",
    "patchtstheadtail": "PatchTST",
    "patchtstheadhorizon": "PatchTST",
    "patchtstextreme": "PatchTST",
    "patchtstextremeconv": "custom",
    "patchtstextremeconvv1": "custom",
    "patchtstextremeconvasymmetricv2": "custom",
    "patchtstextremeconvasymmetricv2freezetune": "custom",
    "patchtstextremeconvtargetbranch": "custom",
    "patchtstextremetcnfront": "custom",
    "patchtstextremeconvdeep": "custom",
    "patchtstextremecnn": "custom",
    "patchtstextremeasymmetric": "PatchTST",
    "patchtstextremeasymmetricv2": "PatchTST",
    "patchtstextrememultiscale": "custom",
    "patchtstextremeadaptive": "PatchTST",
    "patchtstextremeevent": "PatchTST",
    "patchtstextremerefine": "PatchTST",
    "tcn": "custom",
    "nbeatsx": "custom",
    "deeparlike": "custom",
    "lstm": "custom",
    "gru": "custom",
    "crossformer": "Crossformer",
    "autoformer": "Autoformer",
    "timesnet": "TimesNet",
    "scinet": "SCINet",
    "dlinear": "DLinear",
    "tide": "TiDE",
}

AMP_UNSAFE_MODELS = {"timesnet", "autoformer"}
EXTREME_TAIL_QUANTILE = 0.05
EXTREME_HORIZON_WEIGHTS = [1.75, 2.00, 2.25]
EXTREME_LOW_WEIGHTS = [1.15, 1.25, 1.35]
EXTREME_HIGH_WEIGHTS = [0.85, 0.75, 0.65]
DENSITY_NUM_BINS = 64
DENSITY_SMOOTH_SIGMA = 1.5
DENSITY_WEIGHT_BLEND = 0.35
DENSITY_WEIGHT_POWER = 0.5
FREEZE_TUNE_SOURCE_RATIO = 0.45
FREEZE_TUNE_STAGE1_RATIO = 0.30
FREEZE_TUNE_STAGE2_LR_SCALE = 0.25
ADAPTIVE_EXTREME_STRENGTH = 0.80
ADAPTIVE_DIRECTION_STRENGTH = 1.10
ADAPTIVE_DIRECTION_ERROR_POWER = 1.00
ADAPTIVE_HIGH_TAIL_SCALE = 0.90
ADAPTIVE_LOW_TAIL_SCALE = 1.00
ADAPTIVE_MAX_POINT_WEIGHT = 12.0
ASYM_EXTREME_STRENGTH = 0.90
ASYM_LOW_OVER_STRENGTH = 1.35
ASYM_HIGH_UNDER_STRENGTH = 1.55
ASYM_DIRECTION_ERROR_POWER = 1.00
ASYM_HIGH_TAIL_SCALE = 0.90
ASYM_LOW_TAIL_SCALE = 1.00
ASYM_TRANSITION_STRENGTH = 0.75
ASYM_MAX_POINT_WEIGHT = 16.0
ASYM_V2_EXTREME_STRENGTH = 1.00
ASYM_V2_LOW_OVER_STRENGTH = 1.45
ASYM_V2_HIGH_UNDER_STRENGTH = 1.90
ASYM_V2_DIRECTION_ERROR_POWER = 1.10
ASYM_V2_HIGH_TAIL_SCALE = 0.85
ASYM_V2_LOW_TAIL_SCALE = 1.00
ASYM_V2_TRANSITION_STRENGTH = 1.15
ASYM_V2_MAX_POINT_WEIGHT = 20.0
TRANSITION_TOP_QUANTILE = 0.90
EVENT_DELTA_LOSS_WEIGHT = 0.25
EVENT_BCE_LOSS_WEIGHT = 0.10
EVENT_TRANSITION_WEIGHT = 1.5
EVENT_TAIL_WEIGHT = 0.75
REFINE_BRANCH_HIDDEN = 128
REFINE_DELTA_LOSS_WEIGHT = 0.40
REFINE_EVENT_LOSS_WEIGHT = 0.08
REFINE_TRANSITION_WEIGHT = 1.75
ENGINEERING_LOW_THRESHOLDS = {30: None, 60: None, 90: None}
ENGINEERING_HIGH_THRESHOLDS = {30: None, 60: None, 90: None}
PLANT_NAME_CN = "达拉特旗污水处理厂"
PLANT_PROCESS_CN = "A2O + MBR + magnetic coagulation + ozone oxidation"
PLANT_DISCHARGE_STANDARD = "GB 18918-2002 Class 1A"
PLANT_REUSE_NOTE = "100% reclaimed water reuse to the industrial park"
FACTORY_DO_LOW = 2.0
FACTORY_DO_HIGH = 4.0
FACTORY_DO_CRITICAL_LOW = 1.0
FACTORY_DO_CRITICAL_HIGH = 6.0
FACTORY_PH_LOW = 6.0
FACTORY_PH_HIGH = 9.0
FACTORY_SONAN_WARNING = 2.0
FACTORY_SONAN_HIGH = 5.0
FACTORY_OUT_AN_WARNING = 4.0
FACTORY_OUT_AN_LIMIT = 5.0
FACTORY_OUT_TN_WARNING = 13.0
FACTORY_OUT_TN_LIMIT = 15.0
FACTORY_OUT_COD_WARNING = 45.0
FACTORY_OUT_COD_LIMIT = 50.0
FACTORY_REUSE_COD = FACTORY_OUT_COD_WARNING
FACTORY_REUSE_AN = FACTORY_OUT_AN_WARNING
FACTORY_REUSE_TN = FACTORY_OUT_TN_WARNING
FACTORY_SCENE_MIN_SAMPLES = 30
ABLATE_NO_CONV = False
ABLATE_NO_ASYM = False
ABLATE_NO_DENSITY = False
ABLATE_NO_TRANSITION = False

UNIFORM_HORIZON_WEIGHT = float(np.mean(EXTREME_HORIZON_WEIGHTS))
UNIFORM_LOW_WEIGHT = float(np.mean(EXTREME_LOW_WEIGHTS))
UNIFORM_HIGH_WEIGHT = float(np.mean(EXTREME_HIGH_WEIGHTS))


# =========================
# 2. Hyperparameters
# =========================
@dataclass
class Config:
    task_name: str = "long_term_forecast"
    seq_len: int = SEQ_LEN
    label_len: int = LABEL_LEN
    pred_len: int = PRED_LEN
    patch_len: int = PATCH_LEN
    stride: int = PATCH_LEN

    d_model: int = 128
    d_ff: int = 128
    n_heads: int = 4
    e_layers: int = 2
    d_layers: int = 1
    dropout: float = 0.1
    activation: str = "gelu"
    factor: int = 3
    use_norm: bool = True

    enc_in: int = len(BASE_FEATURE_COLS)
    dec_in: int = len(BASE_FEATURE_COLS)
    c_out: int = len(BASE_FEATURE_COLS)
    features: str = "MS"
    embed: str = "timeF"
    freq: str = "t"

    moving_avg: int = 15
    top_k: int = 3
    num_kernels: int = 3
    num_class: int = 1
    individual: bool = False

    kan_hidden_dim: int = 64
    kan_grid_size: int = 8
    kan_spline_order: int = 3
    kan_input_dropout: float = 0.05
    kan_grid_min: float = -4.0
    kan_grid_max: float = 4.0

    tcn_hidden_dim: int = 128
    tcn_num_layers: int = 4
    tcn_dropout: float = 0.1

    nbeats_hidden_dim: int = 256
    nbeats_num_blocks: int = 4
    nbeats_num_layers: int = 4
    nbeats_context_dim: int = 128
    nbeats_dropout: float = 0.1

    deepar_hidden_dim: int = 128
    deepar_dropout: float = 0.1
    deepar_horizon_embed_dim: int = 32

    multiscale_patch_lens: Tuple[int, ...] = (10, 30)
    conv_kernels: Tuple[int, ...] = (3, 7, 15)
    conv_stem_dropout: float = 0.05
    tcn_front_hidden: int = 64
    tcn_front_kernel: int = 7
    tcn_front_dilations: Tuple[int, ...] = (1, 2, 4)
    tcn_front_dropout: float = 0.03
    conv_deep_dilations: Tuple[int, ...] = (1, 2, 4)
    conv_deep_kernel: int = 5
    cnn_local_hidden: int = 16
    cnn_local_blocks: int = 4
    cnn_local_kernels: Tuple[int, ...] = (3, 7, 15)
    cnn_local_dropout: float = 0.08


class Transpose(nn.Module):
    def __init__(self, *dims, contiguous: bool = False):
        super().__init__()
        self.dims = dims
        self.contiguous = contiguous

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.contiguous:
            return x.transpose(*self.dims).contiguous()
        return x.transpose(*self.dims)


class FlattenHead(nn.Module):
    def __init__(self, n_vars: int, nf: int, target_window: int, head_dropout: float = 0.0):
        super().__init__()
        self.flatten = nn.Flatten(start_dim=-2)
        self.linear = nn.Linear(nf, target_window)
        self.dropout = nn.Dropout(head_dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.flatten(x)
        x = self.linear(x)
        return self.dropout(x)


class BSplineKANLinear(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        grid_size: int = 8,
        spline_order: int = 3,
        grid_range: Tuple[float, float] = (-4.0, 4.0),
    ):
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.grid_size = int(grid_size)
        self.spline_order = int(spline_order)
        self.base_activation = nn.SiLU()

        grid_min, grid_max = float(grid_range[0]), float(grid_range[1])
        grid_step = (grid_max - grid_min) / float(self.grid_size)
        base_grid = (
            torch.arange(-self.spline_order, self.grid_size + self.spline_order + 1, dtype=torch.float32)
            * grid_step
            + grid_min
        )
        self.register_buffer("grid", base_grid.unsqueeze(0).repeat(self.in_features, 1))

        self.base_weight = nn.Parameter(torch.empty(self.out_features, self.in_features))
        self.spline_weight = nn.Parameter(
            torch.empty(self.out_features, self.in_features, self.grid_size + self.spline_order)
        )
        self.bias = nn.Parameter(torch.zeros(self.out_features))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.kaiming_uniform_(self.base_weight, a=math.sqrt(5))
        nn.init.trunc_normal_(self.spline_weight, mean=0.0, std=0.02)
        fan_in, _ = nn.init._calculate_fan_in_and_fan_out(self.base_weight)
        bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
        nn.init.uniform_(self.bias, -bound, bound)

    def _b_splines(self, x: torch.Tensor) -> torch.Tensor:
        grid = self.grid.unsqueeze(0)
        x = x.unsqueeze(-1)
        bases = ((x >= grid[:, :, :-1]) & (x < grid[:, :, 1:])).to(x.dtype)

        for order in range(1, self.spline_order + 1):
            left_num = x - grid[:, :, : -(order + 1)]
            left_den = grid[:, :, order:-1] - grid[:, :, : -(order + 1)]
            right_num = grid[:, :, order + 1:] - x
            right_den = grid[:, :, order + 1:] - grid[:, :, 1:-order]

            left = left_num / left_den.clamp_min(1e-6)
            right = right_num / right_den.clamp_min(1e-6)
            bases = left * bases[:, :, :-1] + right * bases[:, :, 1:]

        return bases.contiguous()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        original_shape = x.shape[:-1]
        x = x.reshape(-1, self.in_features)
        x_min = self.grid[:, self.spline_order].min()
        x_max = self.grid[:, -(self.spline_order + 1)].max()
        x = x.clamp(min=float(x_min), max=float(x_max) - 1e-6)

        base_out = F.linear(self.base_activation(x), self.base_weight, self.bias)
        spline_basis = self._b_splines(x).reshape(x.shape[0], -1)
        spline_out = F.linear(spline_basis, self.spline_weight.reshape(self.out_features, -1))
        out = base_out + spline_out
        return out.reshape(*original_shape, self.out_features)


class KAN(nn.Module):
    def __init__(
        self,
        layer_sizes: List[int],
        grid_size: int = 8,
        spline_order: int = 3,
        grid_range: Tuple[float, float] = (-4.0, 4.0),
        dropout: float = 0.0,
    ):
        super().__init__()
        if len(layer_sizes) < 2:
            raise ValueError("KAN requires at least input and output dimensions.")

        self.layers = nn.ModuleList(
            [
                BSplineKANLinear(
                    in_features=layer_sizes[idx],
                    out_features=layer_sizes[idx + 1],
                    grid_size=grid_size,
                    spline_order=spline_order,
                    grid_range=grid_range,
                )
                for idx in range(len(layer_sizes) - 1)
            ]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for idx, layer in enumerate(self.layers):
            x = layer(x)
            if idx < len(self.layers) - 1:
                x = self.dropout(x)
        return x


class TargetTokenHead(nn.Module):
    def __init__(self, nf: int, out_dim: int, dropout: float = 0.0):
        super().__init__()
        self.flatten = nn.Flatten(start_dim=-2)
        self.linear = nn.Linear(nf, out_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.flatten(x)
        x = self.linear(x)
        return self.dropout(x)


class PatchTSTKANModel(nn.Module):
    def __init__(
        self,
        configs: Config,
        patch_len: int,
        stride: int,
        target_feature_idx: int,
    ):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.target_feature_idx = int(target_feature_idx)
        padding = stride

        self.patch_embedding = PatchEmbedding(
            configs.d_model, patch_len, stride, padding, configs.dropout
        )
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=False,
                        ),
                        configs.d_model,
                        configs.n_heads,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.Sequential(
                Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
            ),
        )

        self.head_nf = configs.d_model * int((configs.seq_len - patch_len) / stride + 2)
        self.var_mix_logits = nn.Parameter(torch.zeros(configs.enc_in))
        kan_input_dim = self.head_nf * 2
        self.head_norm = nn.LayerNorm(kan_input_dim)
        self.head_dropout = nn.Dropout(configs.kan_input_dropout)
        self.e_kan = KAN(
            [kan_input_dim, configs.kan_hidden_dim, configs.pred_len],
            grid_size=configs.kan_grid_size,
            spline_order=configs.kan_spline_order,
            grid_range=(configs.kan_grid_min, configs.kan_grid_max),
            dropout=configs.dropout,
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc / stdev

        x_enc = x_enc.permute(0, 2, 1)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        target_tokens = enc_out[:, self.target_feature_idx, :, :]
        var_weights = torch.softmax(self.var_mix_logits, dim=0).to(enc_out.dtype)
        mixed_tokens = torch.einsum("v,bvdp->bdp", var_weights, enc_out)

        head_input = torch.cat([target_tokens.flatten(1), mixed_tokens.flatten(1)], dim=1)
        head_input = self.head_norm(head_input)
        head_input = self.head_dropout(head_input)

        dec_out = self.e_kan(head_input).unsqueeze(-1)
        dec_out = dec_out * stdev[:, 0, self.target_feature_idx].view(-1, 1, 1)
        dec_out = dec_out + means[:, 0, self.target_feature_idx].view(-1, 1, 1)
        return dec_out

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]
        raise NotImplementedError("PatchTSTKANModel only supports forecasting tasks")


class TemporalConvResBlock(nn.Module):
    def __init__(self, channels: int, dilation: int, dropout: float):
        super().__init__()
        padding = dilation
        self.conv1 = nn.Conv1d(channels, channels, kernel_size=3, padding=padding, dilation=dilation)
        self.conv2 = nn.Conv1d(channels, channels, kernel_size=3, padding=padding, dilation=dilation)
        self.norm1 = nn.BatchNorm1d(channels)
        self.norm2 = nn.BatchNorm1d(channels)
        self.dropout = nn.Dropout(dropout)
        self.act = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.act(x)
        x = self.dropout(x)
        x = self.conv2(x)
        x = self.norm2(x)
        x = self.dropout(x)
        return self.act(x + residual)


class DirectRNNForecaster(nn.Module):
    def __init__(
        self,
        input_dim: int,
        pred_len: int,
        hidden_dim: int = 128,
        dense_dim: int = 64,
        dropout: float = 0.1,
        cell_type: str = "lstm",
    ):
        super().__init__()
        rnn_cls = nn.LSTM if cell_type == "lstm" else nn.GRU
        self.pred_len = pred_len
        self.cell_type = cell_type
        self.rnn = rnn_cls(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=1,
            batch_first=True,
        )
        self.dropout = nn.Dropout(dropout)
        self.fc1 = nn.Linear(hidden_dim, dense_dim)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(dense_dim, pred_len)

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        out, _ = self.rnn(x_enc)
        out = out[:, -1, :]
        out = self.dropout(out)
        out = self.relu(self.fc1(out))
        pred_target = self.fc2(out).unsqueeze(-1)
        return pred_target


class TCNForecaster(nn.Module):
    def __init__(
        self,
        input_dim: int,
        pred_len: int,
        hidden_dim: int = 128,
        num_layers: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.pred_len = pred_len
        self.input_proj = nn.Conv1d(input_dim, hidden_dim, kernel_size=1)
        self.blocks = nn.ModuleList(
            [
                TemporalConvResBlock(
                    channels=hidden_dim,
                    dilation=2 ** layer_idx,
                    dropout=dropout,
                )
                for layer_idx in range(num_layers)
            ]
        )
        self.dropout = nn.Dropout(dropout)
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, pred_len),
        )

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        x = x_enc.transpose(1, 2)
        x = self.input_proj(x)
        for block in self.blocks:
            x = block(x)
        pooled = torch.cat([x[:, :, -1], x.mean(dim=-1)], dim=1)
        pred_target = self.head(self.dropout(pooled)).unsqueeze(-1)
        return pred_target


class NBeatsXBlock(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        num_layers: int,
        seq_len: int,
        pred_len: int,
        dropout: float,
    ):
        super().__init__()
        layers: List[nn.Module] = []
        in_dim = input_dim
        for _ in range(num_layers):
            layers.append(nn.Linear(in_dim, hidden_dim))
            layers.append(nn.GELU())
            layers.append(nn.Dropout(dropout))
            in_dim = hidden_dim
        self.mlp = nn.Sequential(*layers)
        self.backcast = nn.Linear(hidden_dim, seq_len)
        self.forecast = nn.Linear(hidden_dim, pred_len)

    def forward(self, block_input: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        hidden = self.mlp(block_input)
        return self.backcast(hidden), self.forecast(hidden)


class NBeatsXForecaster(nn.Module):
    def __init__(
        self,
        input_dim: int,
        seq_len: int,
        pred_len: int,
        hidden_dim: int = 256,
        num_blocks: int = 4,
        num_layers: int = 4,
        context_dim: int = 128,
        dropout: float = 0.1,
        target_feature_idx: int = -1,
    ):
        super().__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.target_feature_idx = target_feature_idx
        self.context_encoder = nn.Sequential(
            nn.Linear(seq_len * input_dim, context_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(context_dim, context_dim),
            nn.GELU(),
        )
        block_input_dim = seq_len + context_dim
        self.blocks = nn.ModuleList(
            [
                NBeatsXBlock(
                    input_dim=block_input_dim,
                    hidden_dim=hidden_dim,
                    num_layers=num_layers,
                    seq_len=seq_len,
                    pred_len=pred_len,
                    dropout=dropout,
                )
                for _ in range(num_blocks)
            ]
        )

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        target_history = x_enc[:, :, self.target_feature_idx]
        residual = target_history
        context = self.context_encoder(x_enc.reshape(x_enc.size(0), -1))
        forecast = torch.zeros(
            x_enc.size(0),
            self.pred_len,
            device=x_enc.device,
            dtype=x_enc.dtype,
        )
        for block in self.blocks:
            block_input = torch.cat([residual, context], dim=1)
            backcast, block_forecast = block(block_input)
            residual = residual - backcast
            forecast = forecast + block_forecast
        return forecast.unsqueeze(-1)


class DeepARLikeForecaster(nn.Module):
    def __init__(
        self,
        input_dim: int,
        pred_len: int,
        hidden_dim: int = 128,
        dropout: float = 0.1,
        target_feature_idx: int = -1,
        horizon_embed_dim: int = 32,
    ):
        super().__init__()
        self.pred_len = pred_len
        self.target_feature_idx = target_feature_idx
        self.encoder = nn.GRU(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=1,
            batch_first=True,
        )
        self.horizon_embedding = nn.Embedding(pred_len, horizon_embed_dim)
        self.decoder = nn.GRUCell(1 + horizon_embed_dim, hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.delta_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        _, hidden = self.encoder(x_enc)
        hidden = hidden[-1]
        prev = x_enc[:, -1, self.target_feature_idx].unsqueeze(-1)
        preds = []
        step_ids = torch.arange(self.pred_len, device=x_enc.device)
        horizon_embeds = self.horizon_embedding(step_ids)
        for step in range(self.pred_len):
            step_embed = horizon_embeds[step].unsqueeze(0).expand(x_enc.size(0), -1)
            decoder_input = torch.cat([prev, step_embed], dim=1)
            hidden = self.decoder(decoder_input, hidden)
            delta = self.delta_head(self.dropout(hidden))
            prev = prev + delta
            preds.append(prev)
        return torch.stack(preds, dim=1)


class PatchTSTExtremeModel(nn.Module):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.horizon_indices = horizon_indices
        padding = stride

        self.patch_embedding = PatchEmbedding(
            configs.d_model, patch_len, stride, padding, configs.dropout
        )
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=False,
                        ),
                        configs.d_model,
                        configs.n_heads,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.Sequential(
                Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
            ),
        )

        self.head_nf = configs.d_model * int((configs.seq_len - patch_len) / stride + 2)
        self.base_head = FlattenHead(
            configs.enc_in, self.head_nf, configs.pred_len, head_dropout=configs.dropout
        )
        self.horizon_head = FlattenHead(
            configs.enc_in,
            self.head_nf,
            len(horizon_indices),
            head_dropout=configs.dropout,
        )
        self.horizon_gate = nn.Parameter(torch.zeros(len(horizon_indices)))

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]
        raise NotImplementedError("PatchTSTExtremeModel only supports forecasting tasks")


class LocalConvStem(nn.Module):
    def __init__(self, channels: int, kernels: Tuple[int, ...], dropout: float):
        super().__init__()
        self.branches = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv1d(
                        channels,
                        channels,
                        kernel_size=int(k),
                        padding=int(k) // 2,
                        groups=channels,
                        bias=False,
                    ),
                    nn.GELU(),
                )
                for k in kernels
            ]
        )
        self.fuse = nn.Sequential(
            nn.Conv1d(channels * len(kernels), channels, kernel_size=1, bias=False),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        # Channel-wise residual gating lets the stem amplify only the variables
        # whose local dynamics are actually helpful, instead of perturbing every
        # channel with the same global strength.
        self.gate = nn.Parameter(torch.zeros(1, channels, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        branch_outs = [branch(x) for branch in self.branches]
        fused = self.fuse(torch.cat(branch_outs, dim=1))
        gate = torch.sigmoid(self.gate)
        return residual + gate * fused


class TCNFrontResidualBlock(nn.Module):
    def __init__(self, channels: int, kernel_size: int, dilation: int, dropout: float):
        super().__init__()
        padding = dilation * (kernel_size // 2)
        self.block = nn.Sequential(
            nn.Conv1d(
                channels,
                channels,
                kernel_size=kernel_size,
                padding=padding,
                dilation=dilation,
                bias=False,
            ),
            nn.GroupNorm(num_groups=1, num_channels=channels),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(
                channels,
                channels,
                kernel_size=kernel_size,
                padding=padding,
                dilation=dilation,
                bias=False,
            ),
            nn.GroupNorm(num_groups=1, num_channels=channels),
        )
        self.gate = nn.Parameter(torch.tensor(0.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        update = self.block(x)
        gate = torch.sigmoid(self.gate)
        return F.gelu(residual + gate * update)


class LocalTCNFront(nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int, kernel_size: int, dilations: Tuple[int, ...], dropout: float):
        super().__init__()
        self.input_proj = nn.Sequential(
            nn.Conv1d(in_channels, hidden_channels, kernel_size=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=hidden_channels),
            nn.GELU(),
        )
        self.blocks = nn.ModuleList(
            [
                TCNFrontResidualBlock(
                    channels=hidden_channels,
                    kernel_size=int(kernel_size),
                    dilation=int(d),
                    dropout=dropout,
                )
                for d in dilations
            ]
        )
        self.output_proj = nn.Sequential(
            nn.Conv1d(hidden_channels, in_channels, kernel_size=1, bias=False),
            nn.Dropout(dropout),
        )
        self.gate = nn.Parameter(torch.tensor(0.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.input_proj(x)
        for block in self.blocks:
            x = block(x)
        x = self.output_proj(x)
        gate = torch.sigmoid(self.gate)
        return residual + gate * x


class LocalConvResidualBlock(nn.Module):
    def __init__(self, channels: int, kernel_size: int, dilation: int, dropout: float):
        super().__init__()
        padding = dilation * (kernel_size // 2)
        self.block = nn.Sequential(
            nn.Conv1d(
                channels,
                channels,
                kernel_size=kernel_size,
                padding=padding,
                dilation=dilation,
                groups=channels,
                bias=False,
            ),
            nn.Conv1d(channels, channels, kernel_size=1, bias=False),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(
                channels,
                channels,
                kernel_size=kernel_size,
                padding=padding,
                dilation=dilation,
                groups=channels,
                bias=False,
            ),
            nn.Conv1d(channels, channels, kernel_size=1, bias=False),
        )
        self.norm = nn.BatchNorm1d(channels)
        self.gate = nn.Parameter(torch.tensor(0.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        update = self.block(x)
        gate = torch.sigmoid(self.gate)
        out = residual + gate * update
        return self.norm(out)


class DeepLocalConvStem(nn.Module):
    def __init__(
        self,
        channels: int,
        kernels: Tuple[int, ...],
        dilations: Tuple[int, ...],
        kernel_size: int,
        dropout: float,
    ):
        super().__init__()
        self.shallow = LocalConvStem(channels=channels, kernels=kernels, dropout=dropout)
        self.blocks = nn.ModuleList(
            [
                LocalConvResidualBlock(
                    channels=channels,
                    kernel_size=int(kernel_size),
                    dilation=int(d),
                    dropout=dropout,
                )
                for d in dilations
            ]
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.shallow(x)
        for block in self.blocks:
            x = block(x)
        return x


class PatchTSTExtremeConvModel(PatchTSTExtremeModel):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__(configs=configs, patch_len=patch_len, stride=stride, horizon_indices=horizon_indices)
        self.local_stem = LocalConvStem(
            channels=configs.enc_in,
            kernels=tuple(int(v) for v in configs.conv_kernels),
            dropout=configs.conv_stem_dropout,
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        x_enc = self.local_stem(x_enc)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out


class PatchTSTExtremeConvTargetBranchModel(PatchTSTExtremeModel):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__(configs=configs, patch_len=patch_len, stride=stride, horizon_indices=horizon_indices)
        self.local_stem = LocalConvStem(
            channels=configs.enc_in,
            kernels=tuple(int(v) for v in configs.conv_kernels),
            dropout=configs.conv_stem_dropout,
        )
        self.target_feature_indices = [
            idx for idx, name in enumerate(BASE_FEATURE_COLS)
            if name in {"In_Water", "In_COD", "In_AN", "N_On_DO", "S_On_DO", "Main_AirV"}
        ]
        target_channels = max(1, len(self.target_feature_indices))
        self.target_local_stem = LocalConvStem(
            channels=target_channels,
            kernels=tuple(int(v) for v in configs.conv_kernels),
            dropout=configs.conv_stem_dropout,
        )
        self.target_mix_gate = nn.Parameter(torch.tensor(0.0))

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        full_feat = self.local_stem(x_enc)

        if self.target_feature_indices:
            target_x = x_enc[:, self.target_feature_indices, :]
            target_feat = self.target_local_stem(target_x)
            mixed = full_feat.clone()
            mix_gate = torch.sigmoid(self.target_mix_gate)
            mixed[:, self.target_feature_indices, :] = (
                full_feat[:, self.target_feature_indices, :]
                + mix_gate * (target_feat - target_x)
            )
            x_enc = mixed
        else:
            x_enc = full_feat

        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out


class PatchTSTExtremeTCNFrontModel(PatchTSTExtremeModel):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__(configs=configs, patch_len=patch_len, stride=stride, horizon_indices=horizon_indices)
        self.local_stem = LocalTCNFront(
            in_channels=configs.enc_in,
            hidden_channels=int(configs.tcn_front_hidden),
            kernel_size=int(configs.tcn_front_kernel),
            dilations=tuple(int(v) for v in configs.tcn_front_dilations),
            dropout=float(configs.tcn_front_dropout),
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        x_enc = self.local_stem(x_enc)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out


class PatchTSTExtremeConvDeepModel(PatchTSTExtremeModel):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__(configs=configs, patch_len=patch_len, stride=stride, horizon_indices=horizon_indices)
        self.local_stem = DeepLocalConvStem(
            channels=configs.enc_in,
            kernels=tuple(int(v) for v in configs.conv_kernels),
            dilations=tuple(int(v) for v in configs.conv_deep_dilations),
            kernel_size=int(configs.conv_deep_kernel),
            dropout=configs.conv_stem_dropout,
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        x_enc = self.local_stem(x_enc)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out


class CNNInceptionResidualBlock(nn.Module):
    def __init__(self, channels: int, kernels: Tuple[int, ...], dropout: float):
        super().__init__()
        branch_channels = max(channels // len(kernels), 8)
        self.pre = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=channels),
            nn.GELU(),
        )
        self.branches = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv1d(
                        channels,
                        branch_channels,
                        kernel_size=int(k),
                        padding=int(k) // 2,
                        bias=False,
                    ),
                    nn.GroupNorm(num_groups=1, num_channels=branch_channels),
                    nn.GELU(),
                )
                for k in kernels
            ]
        )
        fused_channels = branch_channels * len(kernels)
        self.post = nn.Sequential(
            nn.Conv1d(fused_channels, channels, kernel_size=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=channels),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=channels),
        )
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Conv1d(channels, max(channels // 4, 8), kernel_size=1),
            nn.GELU(),
            nn.Conv1d(max(channels // 4, 8), channels, kernel_size=1),
            nn.Sigmoid(),
        )
        self.gate = nn.Parameter(torch.tensor(0.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.pre(x)
        x = torch.cat([branch(x) for branch in self.branches], dim=1)
        x = self.post(x)
        x = x * self.se(x)
        gate = torch.sigmoid(self.gate)
        return F.gelu(residual + gate * x)


class LocalCNNEncoder(nn.Module):
    def __init__(
        self,
        in_channels: int,
        hidden_channels: int,
        num_blocks: int,
        kernels: Tuple[int, ...],
        dropout: float,
    ):
        super().__init__()
        self.input_proj = nn.Sequential(
            nn.Conv1d(in_channels, hidden_channels, kernel_size=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=hidden_channels),
            nn.GELU(),
        )
        self.blocks = nn.ModuleList(
            [
                CNNInceptionResidualBlock(
                    channels=hidden_channels,
                    kernels=kernels,
                    dropout=dropout,
                )
                for _ in range(num_blocks)
            ]
        )
        self.output_proj = nn.Sequential(
            nn.Conv1d(hidden_channels, hidden_channels, kernel_size=3, padding=1, bias=False),
            nn.GroupNorm(num_groups=1, num_channels=hidden_channels),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Conv1d(hidden_channels, in_channels, kernel_size=1, bias=False),
        )
        self.gate = nn.Parameter(torch.tensor(0.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.input_proj(x)
        for block in self.blocks:
            x = block(x)
        x = self.output_proj(x)
        gate = torch.sigmoid(self.gate)
        return residual + gate * x


class PatchTSTExtremeCNNModel(PatchTSTExtremeModel):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__(configs=configs, patch_len=patch_len, stride=stride, horizon_indices=horizon_indices)
        self.local_encoder = LocalCNNEncoder(
            in_channels=configs.enc_in,
            hidden_channels=configs.cnn_local_hidden,
            num_blocks=configs.cnn_local_blocks,
            kernels=tuple(int(v) for v in configs.cnn_local_kernels),
            dropout=configs.cnn_local_dropout,
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        x_enc = self.local_encoder(x_enc)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out


class PatchTSTExtremeMultiScaleModel(nn.Module):
    def __init__(self, configs: Config, horizon_indices: List[int], target_feature_idx: int):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.horizon_indices = horizon_indices
        self.target_feature_idx = int(target_feature_idx)
        self.patch_lens = tuple(int(v) for v in configs.multiscale_patch_lens)

        self.patch_embeddings = nn.ModuleList()
        self.encoders = nn.ModuleList()
        self.scale_projectors = nn.ModuleList()
        self.scale_logits = nn.Parameter(torch.zeros(len(self.patch_lens)))

        total_patch_tokens = 0
        for patch_len in self.patch_lens:
            stride = patch_len
            padding = stride
            self.patch_embeddings.append(
                PatchEmbedding(configs.d_model, patch_len, stride, padding, configs.dropout)
            )
            self.encoders.append(
                Encoder(
                    [
                        EncoderLayer(
                            AttentionLayer(
                                FullAttention(
                                    False,
                                    configs.factor,
                                    attention_dropout=configs.dropout,
                                    output_attention=False,
                                ),
                                configs.d_model,
                                configs.n_heads,
                            ),
                            configs.d_model,
                            configs.d_ff,
                            dropout=configs.dropout,
                            activation=configs.activation,
                        )
                        for _ in range(configs.e_layers)
                    ],
                    norm_layer=nn.Sequential(
                        Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
                    ),
                )
            )
            patch_tokens = int((configs.seq_len - patch_len) / stride + 2)
            total_patch_tokens += patch_tokens
            self.scale_projectors.append(
                nn.Sequential(
                    nn.Conv1d(configs.d_model, configs.d_model, kernel_size=1),
                    nn.GELU(),
                    nn.Dropout(configs.dropout),
                )
            )

        self.head_nf = configs.d_model * total_patch_tokens
        self.base_head = FlattenHead(
            configs.enc_in, self.head_nf, configs.pred_len, head_dropout=configs.dropout
        )
        self.horizon_head = FlattenHead(
            configs.enc_in,
            self.head_nf,
            len(horizon_indices),
            head_dropout=configs.dropout,
        )
        self.horizon_gate = nn.Parameter(torch.zeros(len(horizon_indices)))

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_norm = x_enc - means
        stdev = torch.sqrt(torch.var(x_norm, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_norm = x_norm / stdev

        x_patch_in = x_norm.permute(0, 2, 1)
        scale_weights = torch.softmax(self.scale_logits, dim=0)
        scale_features = []
        for scale_idx, (patch_embed, encoder, projector) in enumerate(
            zip(self.patch_embeddings, self.encoders, self.scale_projectors)
        ):
            enc_tokens, n_vars = patch_embed(x_patch_in)
            enc_tokens, _ = encoder(enc_tokens)
            enc_tokens = torch.reshape(
                enc_tokens,
                (-1, n_vars, enc_tokens.shape[-2], enc_tokens.shape[-1]),
            )
            enc_tokens = enc_tokens.permute(0, 1, 3, 2)
            bsz, nvars, d_model, patch_num = enc_tokens.shape
            proj_in = enc_tokens.reshape(bsz * nvars, d_model, patch_num)
            proj_out = projector(proj_in).reshape(bsz, nvars, d_model, patch_num)
            scale_features.append(proj_out * scale_weights[scale_idx])

        fused = torch.cat(scale_features, dim=-1)
        dec_out = self.base_head(fused).permute(0, 2, 1)
        horizon_residual = self.horizon_head(fused).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]
        raise NotImplementedError("PatchTSTExtremeMultiScaleModel only supports forecasting tasks")


class PatchTSTExtremeEventModel(nn.Module):
    def __init__(
        self,
        configs: Config,
        patch_len: int,
        stride: int,
        horizon_indices: List[int],
        target_feature_idx: int,
    ):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.horizon_indices = horizon_indices
        self.target_feature_idx = int(target_feature_idx)
        padding = stride

        self.patch_embedding = PatchEmbedding(
            configs.d_model, patch_len, stride, padding, configs.dropout
        )
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=False,
                        ),
                        configs.d_model,
                        configs.n_heads,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.Sequential(
                Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
            ),
        )

        self.head_nf = configs.d_model * int((configs.seq_len - patch_len) / stride + 2)
        self.base_head = FlattenHead(
            configs.enc_in, self.head_nf, configs.pred_len, head_dropout=configs.dropout
        )
        self.horizon_head = FlattenHead(
            configs.enc_in,
            self.head_nf,
            len(horizon_indices),
            head_dropout=configs.dropout,
        )
        self.target_delta_head = TargetTokenHead(
            self.head_nf,
            len(horizon_indices),
            dropout=configs.dropout,
        )
        self.target_event_head = TargetTokenHead(
            self.head_nf,
            len(horizon_indices) * 3,
            dropout=configs.dropout,
        )
        self.horizon_gate = nn.Parameter(torch.zeros(len(horizon_indices)))
        self.transition_mix_gate = nn.Parameter(torch.full((len(horizon_indices),), -0.5))
        self.tail_mix_gate = nn.Parameter(torch.full((len(horizon_indices),), -1.0))

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        current_target = x_enc[:, -1, self.target_feature_idx]

        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc / stdev
        current_target_norm = x_enc[:, -1, self.target_feature_idx]

        x_enc = x_enc.permute(0, 2, 1)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        target_tokens = enc_out[:, self.target_feature_idx, :, :]
        delta_pred_norm = self.target_delta_head(target_tokens).to(dec_out.dtype)
        event_logits = self.target_event_head(target_tokens).view(-1, len(self.horizon_indices), 3).to(dec_out.dtype)
        event_probs = torch.sigmoid(event_logits)
        tail_prob = torch.maximum(event_probs[:, :, 0], event_probs[:, :, 1])
        transition_prob = event_probs[:, :, 2]

        mix = (
            torch.sigmoid(self.transition_mix_gate).view(1, -1) * transition_prob
            + torch.sigmoid(self.tail_mix_gate).view(1, -1) * tail_prob
        ).clamp(max=0.95)
        target_base_selected = dec_out[:, self.horizon_indices, self.target_feature_idx]
        delta_level_selected = current_target_norm.unsqueeze(1).to(dec_out.dtype) + delta_pred_norm.to(dec_out.dtype)
        refined_target = target_base_selected + mix.to(dec_out.dtype) * (delta_level_selected - target_base_selected)
        dec_out[:, self.horizon_indices, self.target_feature_idx] = refined_target

        target_stdev = stdev[:, 0, self.target_feature_idx].unsqueeze(1)
        delta_pred = delta_pred_norm * target_stdev
        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return {
            "forecast": dec_out,
            "delta_pred": delta_pred,
            "event_logits": event_logits,
            "event_probs": event_probs,
            "current_target": current_target,
        }

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> Dict[str, torch.Tensor]:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            dec_out["forecast"] = dec_out["forecast"][:, -self.pred_len:, :]
            return dec_out
        raise NotImplementedError("PatchTSTExtremeEventModel only supports forecasting tasks")


class PatchTSTExtremeRefineModel(nn.Module):
    def __init__(
        self,
        configs: Config,
        patch_len: int,
        stride: int,
        horizon_indices: List[int],
        target_feature_idx: int,
    ):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.horizon_indices = horizon_indices
        self.target_feature_idx = int(target_feature_idx)
        padding = stride

        self.patch_embedding = PatchEmbedding(
            configs.d_model, patch_len, stride, padding, configs.dropout
        )
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=False,
                        ),
                        configs.d_model,
                        configs.n_heads,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.Sequential(
                Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
            ),
        )

        self.head_nf = configs.d_model * int((configs.seq_len - patch_len) / stride + 2)
        self.base_head = FlattenHead(
            configs.enc_in, self.head_nf, configs.pred_len, head_dropout=configs.dropout
        )
        self.horizon_head = FlattenHead(
            configs.enc_in,
            self.head_nf,
            len(horizon_indices),
            head_dropout=configs.dropout,
        )
        self.horizon_gate = nn.Parameter(torch.zeros(len(horizon_indices)))

        refine_in = configs.enc_in * 2
        self.refine_proj = nn.Conv1d(refine_in, REFINE_BRANCH_HIDDEN, kernel_size=3, padding=1)
        self.refine_blocks = nn.ModuleList(
            [
                TemporalConvResBlock(REFINE_BRANCH_HIDDEN, dilation=1, dropout=configs.dropout),
                TemporalConvResBlock(REFINE_BRANCH_HIDDEN, dilation=2, dropout=configs.dropout),
                TemporalConvResBlock(REFINE_BRANCH_HIDDEN, dilation=4, dropout=configs.dropout),
                TemporalConvResBlock(REFINE_BRANCH_HIDDEN, dilation=8, dropout=configs.dropout),
            ]
        )
        rep_dim = REFINE_BRANCH_HIDDEN * 3
        self.refine_delta_head = nn.Sequential(
            nn.Linear(rep_dim, REFINE_BRANCH_HIDDEN),
            nn.GELU(),
            nn.Dropout(configs.dropout),
            nn.Linear(REFINE_BRANCH_HIDDEN, configs.pred_len),
        )
        self.refine_gate_head = nn.Sequential(
            nn.Linear(rep_dim, REFINE_BRANCH_HIDDEN // 2),
            nn.GELU(),
            nn.Dropout(configs.dropout),
            nn.Linear(REFINE_BRANCH_HIDDEN // 2, len(horizon_indices)),
        )
        self.event_head = nn.Sequential(
            nn.Linear(rep_dim, REFINE_BRANCH_HIDDEN // 2),
            nn.GELU(),
            nn.Dropout(configs.dropout),
            nn.Linear(REFINE_BRANCH_HIDDEN // 2, len(horizon_indices) * 3),
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        current_target = x_enc[:, -1, self.target_feature_idx]

        means = x_enc.mean(1, keepdim=True).detach()
        x_norm = x_enc - means
        stdev = torch.sqrt(torch.var(x_norm, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_norm = x_norm / stdev
        current_target_norm = x_norm[:, -1, self.target_feature_idx]

        patch_in = x_norm.permute(0, 2, 1)
        enc_out, n_vars = self.patch_embedding(patch_in)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        diff_norm = torch.diff(x_norm, dim=1, prepend=x_norm[:, :1, :])
        refine_input = torch.cat([x_norm, diff_norm], dim=-1).permute(0, 2, 1)
        refine_state = self.refine_proj(refine_input)
        for block in self.refine_blocks:
            refine_state = block(refine_state)

        rep_last = refine_state[:, :, -1]
        rep_mean = refine_state.mean(dim=-1)
        rep_max = refine_state.max(dim=-1).values
        rep = torch.cat([rep_last, rep_mean, rep_max], dim=1)

        delta_seq_norm = self.refine_delta_head(rep).to(dec_out.dtype)
        refine_gate = torch.sigmoid(self.refine_gate_head(rep)).to(dec_out.dtype)
        event_logits = self.event_head(rep).view(-1, len(self.horizon_indices), 3).to(dec_out.dtype)

        alt_target_seq = current_target_norm.unsqueeze(1).to(dec_out.dtype) + delta_seq_norm
        target_base_selected = dec_out[:, self.horizon_indices, self.target_feature_idx]
        alt_target_selected = alt_target_seq[:, self.horizon_indices]
        corrected_target = target_base_selected + refine_gate * (alt_target_selected - target_base_selected)
        dec_out[:, self.horizon_indices, self.target_feature_idx] = corrected_target

        target_stdev = stdev[:, 0, self.target_feature_idx].unsqueeze(1)
        delta_seq = delta_seq_norm * target_stdev
        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return {
            "forecast": dec_out,
            "delta_pred_full": delta_seq,
            "event_logits": event_logits,
            "current_target": current_target,
            "refine_gate": refine_gate,
        }

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> Dict[str, torch.Tensor]:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            dec_out["forecast"] = dec_out["forecast"][:, -self.pred_len:, :]
            return dec_out
        raise NotImplementedError("PatchTSTExtremeRefineModel only supports forecasting tasks")


class DensityAwareExtremeLoss(nn.Module):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
    ):
        super().__init__()
        self.horizon_indices = horizon_indices
        self.low_thresholds = [float(v) for v in low_thresholds]
        self.high_thresholds = [float(v) for v in high_thresholds]
        self.horizon_weights = [float(v) for v in horizon_weights]
        self.low_weights = [float(v) for v in low_weights]
        self.high_weights = [float(v) for v in high_weights]
        self.density_weight_blend = float(density_weight_blend)
        self.register_buffer(
            "density_bin_edges",
            torch.tensor(density_bin_edges, dtype=torch.float32),
        )
        self.register_buffer(
            "density_bin_weights",
            torch.tensor(density_bin_weights, dtype=torch.float32),
        )

    def _density_multiplier(self, horizon_pos: int, horizon_values: torch.Tensor) -> torch.Tensor:
        edges = self.density_bin_edges[horizon_pos]
        rarity = self.density_bin_weights[horizon_pos]
        bin_idx = torch.bucketize(horizon_values, edges[1:-1])
        density_mult = rarity[bin_idx]
        return 1.0 + self.density_weight_blend * (density_mult - 1.0)

    def _build_point_weights(self, true: torch.Tensor) -> torch.Tensor:
        weights = torch.ones_like(true)
        for horizon_pos, (idx, low_thr, high_thr, horizon_w, low_w, high_w) in enumerate(
            zip(
                self.horizon_indices,
                self.low_thresholds,
                self.high_thresholds,
                self.horizon_weights,
                self.low_weights,
                self.high_weights,
            )
        ):
            horizon_true = true[:, idx:idx + 1, :]
            horizon_weights = weights[:, idx:idx + 1, :] * horizon_w
            horizon_weights = torch.where(horizon_true <= low_thr, horizon_weights * low_w, horizon_weights)
            horizon_weights = torch.where(horizon_true >= high_thr, horizon_weights * high_w, horizon_weights)
            density_mult = self._density_multiplier(horizon_pos, horizon_true[:, 0, 0]).view(-1, 1, 1)
            horizon_weights = horizon_weights * density_mult
            weights[:, idx:idx + 1, :] = horizon_weights
        return weights

    def forward(self, pred: torch.Tensor, true: torch.Tensor) -> torch.Tensor:
        sq_err = (pred - true) ** 2
        weights = self._build_point_weights(true)
        weights = weights / weights.mean().clamp_min(1e-6)
        return (sq_err * weights).mean()


class AdaptiveDensityAwareExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        adaptive_extreme_strength: float,
        adaptive_direction_strength: float,
        adaptive_direction_error_power: float,
        adaptive_high_tail_scale: float,
        adaptive_low_tail_scale: float,
        adaptive_max_point_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.adaptive_extreme_strength = float(adaptive_extreme_strength)
        self.adaptive_direction_strength = float(adaptive_direction_strength)
        self.adaptive_direction_error_power = float(adaptive_direction_error_power)
        self.adaptive_high_tail_scale = float(adaptive_high_tail_scale)
        self.adaptive_low_tail_scale = float(adaptive_low_tail_scale)
        self.adaptive_max_point_weight = float(adaptive_max_point_weight)

    def _tail_scales(
        self,
        low_thr: float,
        high_thr: float,
        horizon_true: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        center = 0.5 * (low_thr + high_thr)
        low_scale = max(center - low_thr, 1.0) * self.adaptive_low_tail_scale
        high_scale = max(high_thr - center, 1.0) * self.adaptive_high_tail_scale
        return torch.full_like(horizon_true, low_scale), torch.full_like(horizon_true, high_scale)

    def _build_point_weights_adaptive(self, pred: torch.Tensor, true: torch.Tensor) -> torch.Tensor:
        weights = torch.ones_like(true)
        for horizon_pos, (idx, low_thr, high_thr, horizon_w, low_w, high_w) in enumerate(
            zip(
                self.horizon_indices,
                self.low_thresholds,
                self.high_thresholds,
                self.horizon_weights,
                self.low_weights,
                self.high_weights,
            )
        ):
            horizon_true = true[:, idx:idx + 1, :]
            horizon_pred = pred[:, idx:idx + 1, :]
            horizon_weights_t = weights[:, idx:idx + 1, :] * horizon_w

            low_scale, high_scale = self._tail_scales(low_thr, high_thr, horizon_true)
            low_degree = torch.relu((low_thr - horizon_true) / low_scale)
            high_degree = torch.relu((horizon_true - high_thr) / high_scale)

            low_amp = max(low_w - 1.0, 0.0)
            high_amp = max(1.0 - high_w, 0.0)
            low_tail_weight = 1.0 + low_amp * (1.0 + self.adaptive_extreme_strength * low_degree)
            high_tail_weight = 1.0 + high_amp * (1.0 + self.adaptive_extreme_strength * high_degree)

            over_low = torch.relu((horizon_pred - horizon_true) / low_scale)
            under_high = torch.relu((horizon_true - horizon_pred) / high_scale)
            over_low = torch.pow(over_low, self.adaptive_direction_error_power)
            under_high = torch.pow(under_high, self.adaptive_direction_error_power)

            low_dir_weight = 1.0 + self.adaptive_direction_strength * over_low * (1.0 + low_degree)
            high_dir_weight = 1.0 + self.adaptive_direction_strength * under_high * (1.0 + high_degree)

            low_mask = (horizon_true <= low_thr).to(horizon_true.dtype)
            high_mask = (horizon_true >= high_thr).to(horizon_true.dtype)
            neutral_mask = (1.0 - low_mask - high_mask).clamp_min(0.0)

            adaptive_tail_weight = (
                neutral_mask
                + low_mask * low_tail_weight * low_dir_weight
                + high_mask * high_tail_weight * high_dir_weight
            )

            density_mult = self._density_multiplier(horizon_pos, horizon_true[:, 0, 0]).view(-1, 1, 1)
            horizon_weights_t = horizon_weights_t * adaptive_tail_weight * density_mult
            horizon_weights_t = horizon_weights_t.clamp(max=self.adaptive_max_point_weight)
            weights[:, idx:idx + 1, :] = horizon_weights_t
        return weights

    def forward(self, pred: torch.Tensor, true: torch.Tensor) -> torch.Tensor:
        sq_err = (pred - true) ** 2
        weights = self._build_point_weights_adaptive(pred, true)
        weights = weights / weights.mean().clamp_min(1e-6)
        return (sq_err * weights).mean()


class AsymmetricDirectionalExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        transition_thresholds: List[float],
        extreme_strength: float,
        low_over_strength: float,
        high_under_strength: float,
        direction_error_power: float,
        high_tail_scale: float,
        low_tail_scale: float,
        transition_strength: float,
        max_point_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.requires_current_target = True
        self.extreme_strength = float(extreme_strength)
        self.low_over_strength = float(low_over_strength)
        self.high_under_strength = float(high_under_strength)
        self.direction_error_power = float(direction_error_power)
        self.high_tail_scale = float(high_tail_scale)
        self.low_tail_scale = float(low_tail_scale)
        self.transition_strength = float(transition_strength)
        self.max_point_weight = float(max_point_weight)
        self.register_buffer(
            "transition_thresholds",
            torch.tensor(transition_thresholds, dtype=torch.float32),
        )

    def _tail_scales(
        self,
        low_thr: float,
        high_thr: float,
        horizon_true: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        center = 0.5 * (low_thr + high_thr)
        low_scale = max(center - low_thr, 1.0) * self.low_tail_scale
        high_scale = max(high_thr - center, 1.0) * self.high_tail_scale
        return torch.full_like(horizon_true, low_scale), torch.full_like(horizon_true, high_scale)

    def _build_point_weights(
        self,
        pred: torch.Tensor,
        true: torch.Tensor,
        current_target: torch.Tensor,
    ) -> torch.Tensor:
        weights = torch.ones_like(true)
        current_target = current_target.to(true.dtype)
        if current_target.ndim == 2:
            current_target = current_target.unsqueeze(-1)
        if current_target.ndim == 1:
            current_target = current_target.view(-1, 1, 1)

        for horizon_pos, (idx, low_thr, high_thr, horizon_w, low_w, high_w) in enumerate(
            zip(
                self.horizon_indices,
                self.low_thresholds,
                self.high_thresholds,
                self.horizon_weights,
                self.low_weights,
                self.high_weights,
            )
        ):
            horizon_true = true[:, idx:idx + 1, :]
            horizon_pred = pred[:, idx:idx + 1, :]
            horizon_weights_t = weights[:, idx:idx + 1, :] * horizon_w

            low_scale, high_scale = self._tail_scales(low_thr, high_thr, horizon_true)
            low_degree = torch.relu((low_thr - horizon_true) / low_scale)
            high_degree = torch.relu((horizon_true - high_thr) / high_scale)

            low_amp = max(low_w - 1.0, 0.0)
            high_amp = max(1.0 - high_w, 0.0)
            low_tail_weight = 1.0 + low_amp * (1.0 + self.extreme_strength * low_degree)
            high_tail_weight = 1.0 + high_amp * (1.0 + self.extreme_strength * high_degree)

            over_low = torch.relu((horizon_pred - horizon_true) / low_scale)
            under_high = torch.relu((horizon_true - horizon_pred) / high_scale)
            over_low = torch.pow(over_low, self.direction_error_power)
            under_high = torch.pow(under_high, self.direction_error_power)

            low_dir_weight = 1.0 + self.low_over_strength * over_low * (1.0 + low_degree)
            high_dir_weight = 1.0 + self.high_under_strength * under_high * (1.0 + high_degree)

            low_mask = (horizon_true <= low_thr).to(horizon_true.dtype)
            high_mask = (horizon_true >= high_thr).to(horizon_true.dtype)
            neutral_mask = (1.0 - low_mask - high_mask).clamp_min(0.0)

            tail_weight = (
                neutral_mask
                + low_mask * low_tail_weight * low_dir_weight
                + high_mask * high_tail_weight * high_dir_weight
            )

            transition_thr = float(self.transition_thresholds[horizon_pos].item())
            transition_scale = max(transition_thr, 1.0)
            delta_true = torch.abs(horizon_true - current_target)
            transition_degree = torch.relu((delta_true - transition_thr) / transition_scale)
            transition_weight = 1.0 + self.transition_strength * transition_degree

            density_mult = self._density_multiplier(horizon_pos, horizon_true[:, 0, 0]).view(-1, 1, 1)
            horizon_weights_t = horizon_weights_t * tail_weight * transition_weight * density_mult
            horizon_weights_t = horizon_weights_t.clamp(max=self.max_point_weight)
            weights[:, idx:idx + 1, :] = horizon_weights_t

        return weights

    def forward(
        self,
        pred: torch.Tensor,
        true: torch.Tensor,
        current_target: torch.Tensor,
    ) -> torch.Tensor:
        sq_err = (pred - true) ** 2
        weights = self._build_point_weights(pred, true, current_target)
        weights = weights / weights.mean().clamp_min(1e-6)
        return (sq_err * weights).mean()


class EventAwareExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        transition_thresholds: List[float],
        event_pos_weights: np.ndarray,
        delta_loss_weight: float,
        event_loss_weight: float,
        transition_weight: float,
        tail_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.delta_loss_weight = float(delta_loss_weight)
        self.event_loss_weight = float(event_loss_weight)
        self.transition_weight = float(transition_weight)
        self.tail_weight = float(tail_weight)
        self.register_buffer(
            "transition_thresholds",
            torch.tensor(transition_thresholds, dtype=torch.float32),
        )
        self.register_buffer(
            "event_pos_weights",
            torch.tensor(event_pos_weights, dtype=torch.float32),
        )

    def forward(self, pred_bundle: Dict[str, torch.Tensor], true: torch.Tensor) -> torch.Tensor:
        forecast = pred_bundle["forecast"]
        current_target = pred_bundle["current_target"]
        delta_pred = pred_bundle["delta_pred"]
        event_logits = pred_bundle["event_logits"]

        base_loss = super().forward(forecast, true)

        delta_targets = []
        event_targets = []
        sample_weights = []
        for horizon_pos, idx in enumerate(self.horizon_indices):
            horizon_true = true[:, idx, 0]
            delta_true = horizon_true - current_target
            low_target = (horizon_true <= self.low_thresholds[horizon_pos]).float()
            high_target = (horizon_true >= self.high_thresholds[horizon_pos]).float()
            transition_target = (delta_true.abs() >= self.transition_thresholds[horizon_pos]).float()

            delta_targets.append(delta_true)
            event_targets.append(torch.stack([low_target, high_target, transition_target], dim=-1))

            tail_target = torch.maximum(low_target, high_target)
            weights = torch.ones_like(delta_true) * self.horizon_weights[horizon_pos]
            weights = weights * (1.0 + self.transition_weight * transition_target + self.tail_weight * tail_target)
            sample_weights.append(weights)

        delta_true = torch.stack(delta_targets, dim=1)
        event_target = torch.stack(event_targets, dim=1)
        sample_weight = torch.stack(sample_weights, dim=1)
        sample_weight = sample_weight / sample_weight.mean().clamp_min(1e-6)

        delta_loss = F.smooth_l1_loss(delta_pred, delta_true, reduction="none")
        delta_loss = (delta_loss * sample_weight).mean()

        pos_weight = self.event_pos_weights.view(1, len(self.horizon_indices), 3)
        event_loss = F.binary_cross_entropy_with_logits(
            event_logits,
            event_target,
            pos_weight=pos_weight,
            reduction="none",
        )
        event_loss = (event_loss * sample_weight.unsqueeze(-1)).mean()

        return base_loss + self.delta_loss_weight * delta_loss + self.event_loss_weight * event_loss


class RefineAwareExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        transition_thresholds: List[float],
        full_delta_threshold: float,
        event_pos_weights: np.ndarray,
        delta_loss_weight: float,
        event_loss_weight: float,
        transition_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.delta_loss_weight = float(delta_loss_weight)
        self.event_loss_weight = float(event_loss_weight)
        self.transition_weight = float(transition_weight)
        self.register_buffer(
            "transition_thresholds",
            torch.tensor(transition_thresholds, dtype=torch.float32),
        )
        self.register_buffer(
            "event_pos_weights",
            torch.tensor(event_pos_weights, dtype=torch.float32),
        )
        self.full_delta_threshold = float(full_delta_threshold)

    def forward(self, pred_bundle: Dict[str, torch.Tensor], true: torch.Tensor) -> torch.Tensor:
        forecast = pred_bundle["forecast"]
        current_target = pred_bundle["current_target"]
        delta_pred_full = pred_bundle["delta_pred_full"]
        event_logits = pred_bundle["event_logits"]

        base_loss = super().forward(forecast, true)

        delta_true_full = true[:, :, 0] - current_target.unsqueeze(1)
        delta_weights = torch.ones_like(delta_true_full)
        delta_weights = torch.where(
            delta_true_full.abs() >= self.full_delta_threshold,
            delta_weights * (1.0 + self.transition_weight),
            delta_weights,
        )
        for horizon_pos, idx in enumerate(self.horizon_indices):
            delta_weights[:, idx] = delta_weights[:, idx] * self.horizon_weights[horizon_pos]
        delta_weights = delta_weights / delta_weights.mean().clamp_min(1e-6)

        delta_loss = F.smooth_l1_loss(delta_pred_full, delta_true_full, reduction="none")
        delta_loss = (delta_loss * delta_weights).mean()

        event_targets = []
        for horizon_pos, idx in enumerate(self.horizon_indices):
            horizon_true = true[:, idx, 0]
            delta_true = delta_true_full[:, idx]
            low_target = (horizon_true <= self.low_thresholds[horizon_pos]).float()
            high_target = (horizon_true >= self.high_thresholds[horizon_pos]).float()
            transition_target = (delta_true.abs() >= self.transition_thresholds[horizon_pos]).float()
            event_targets.append(torch.stack([low_target, high_target, transition_target], dim=-1))
        event_target = torch.stack(event_targets, dim=1)

        pos_weight = self.event_pos_weights.view(1, len(self.horizon_indices), 3)
        event_loss = F.binary_cross_entropy_with_logits(
            event_logits,
            event_target,
            pos_weight=pos_weight,
            reduction="none",
        )
        sample_weight = torch.ones_like(event_target[..., 0])
        for horizon_pos in range(len(self.horizon_indices)):
            sample_weight[:, horizon_pos] = sample_weight[:, horizon_pos] * self.horizon_weights[horizon_pos]
        sample_weight = sample_weight / sample_weight.mean().clamp_min(1e-6)
        event_loss = (event_loss * sample_weight.unsqueeze(-1)).mean()

        return base_loss + self.delta_loss_weight * delta_loss + self.event_loss_weight * event_loss


def load_tslib_time_features(tslib_root: str):
    module_path = os.path.join(tslib_root, "utils", "timefeatures.py")
    if not os.path.isfile(module_path):
        raise FileNotFoundError(f"Official TSLib timefeatures.py not found: {module_path}")

    spec = importlib.util.spec_from_file_location("tslib_timefeatures", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load TSLib timefeatures module from: {module_path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.time_features


TSLIB_TIME_FEATURES = load_tslib_time_features(TSLIB_ROOT)


def load_tslib_symbol(module_rel_path: str, symbol_name: str):
    module_path = os.path.join(TSLIB_ROOT, *module_rel_path.split(".")) + ".py"
    if not os.path.isfile(module_path):
        raise FileNotFoundError(f"Official TSLib module not found: {module_path}")

    cache_key = f"tslib_dynamic_{module_rel_path.replace('.', '_')}"
    if cache_key in sys.modules:
        module = sys.modules[cache_key]
    else:
        spec = importlib.util.spec_from_file_location(cache_key, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Unable to load TSLib module from: {module_path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        sys.modules[cache_key] = module

    if not hasattr(module, symbol_name):
        raise AttributeError(f"Symbol '{symbol_name}' not found in {module_path}")
    return getattr(module, symbol_name)


# =========================
# 3. Utilities
# =========================
def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def safe_cols(df: pd.DataFrame, cols: List[str]) -> List[str]:
    return [c for c in cols if c in df.columns]


def evaluate_regression(y_true: np.ndarray, y_pred: np.ndarray) -> Tuple[float, float, float]:
    mae = mean_absolute_error(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    return mae, rmse, r2


def safe_regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Tuple[float, float]:
    if len(y_true) == 0:
        return np.nan, np.nan
    mae = mean_absolute_error(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_true, y_pred))
    return mae, rmse


def safe_bias(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    if len(y_true) == 0:
        return np.nan
    return float(np.mean(y_pred - y_true))


def classification_metrics_from_events(y_true_event: np.ndarray, y_pred_event: np.ndarray) -> Dict[str, float]:
    tp = np.sum((y_true_event == 1) & (y_pred_event == 1))
    fp = np.sum((y_true_event == 0) & (y_pred_event == 1))
    fn = np.sum((y_true_event == 1) & (y_pred_event == 0))
    tn = np.sum((y_true_event == 0) & (y_pred_event == 0))

    precision = tp / (tp + fp) if (tp + fp) > 0 else np.nan
    recall = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    if np.isnan(precision) or np.isnan(recall) or (precision + recall) == 0:
        f1 = np.nan
    else:
        f1 = 2 * precision * recall / (precision + recall)

    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    false_alarm_rate = fp / (tp + fp) if (tp + fp) > 0 else np.nan
    miss_rate = fn / (tp + fn) if (tp + fn) > 0 else np.nan
    csi = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else np.nan
    balanced_accuracy = (
        (recall + specificity) / 2
        if not np.isnan(recall) and not np.isnan(specificity)
        else np.nan
    )
    alarm_rate = (tp + fp) / len(y_pred_event) if len(y_pred_event) > 0 else np.nan
    event_rate = (tp + fn) / len(y_true_event) if len(y_true_event) > 0 else np.nan

    return {
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "specificity": float(specificity),
        "false_alarm_rate": float(false_alarm_rate),
        "miss_rate": float(miss_rate),
        "csi": float(csi),
        "balanced_accuracy": float(balanced_accuracy),
        "alarm_rate": float(alarm_rate),
        "event_rate": float(event_rate),
        "tp": float(tp),
        "fp": float(fp),
        "fn": float(fn),
        "tn": float(tn),
    }


def empty_horizon_diagnostics() -> Dict[str, float]:
    metrics = {
        "mae_low": np.nan,
        "rmse_low": np.nan,
        "mae_high": np.nan,
        "rmse_high": np.nan,
        "bias_low": np.nan,
        "bias_high": np.nan,
        "rmse_delta_top10": np.nan,
        "rmse_delta_top10_persistence": np.nan,
        "n_low": np.nan,
        "n_high": np.nan,
        "n_delta_top10": np.nan,
    }
    cls_names = [
        "precision",
        "recall",
        "f1",
        "specificity",
        "false_alarm_rate",
        "miss_rate",
        "csi",
        "balanced_accuracy",
        "alarm_rate",
        "event_rate",
        "tp",
        "fp",
        "fn",
        "tn",
    ]
    for prefix in ["", "persistence_"]:
        for suffix in ["low", "high"]:
            for name in cls_names:
                metrics[f"{prefix}{name}_{suffix}"] = np.nan
    return metrics


def get_engineering_threshold(horizon: int, threshold_map: Dict[int, float]) -> float:
    value = threshold_map.get(horizon)
    if value is None:
        return np.nan
    return float(value)


def parse_threshold_arg(raw_value: str) -> Dict[int, float]:
    values = [v.strip() for v in str(raw_value).split(",") if v.strip()]
    if len(values) != len(HORIZON_MINS):
        raise ValueError(
            f"Threshold argument must provide {len(HORIZON_MINS)} comma-separated values "
            f"for horizons {HORIZON_MINS}, got: {raw_value}"
        )
    parsed: Dict[int, float] = {}
    for horizon, token in zip(HORIZON_MINS, values):
        if token.lower() in {"none", "nan", ""}:
            parsed[horizon] = None
        else:
            parsed[horizon] = float(token)
    return parsed


def get_numeric_series(df: pd.DataFrame, col: str) -> pd.Series:
    if col not in df.columns:
        return pd.Series(np.nan, index=df.index, dtype=np.float32)
    return pd.to_numeric(df[col], errors="coerce")


def compute_factory_scene_thresholds(df: pd.DataFrame) -> Dict[str, float]:
    in_water = get_numeric_series(df, "In_Water")
    in_cod = get_numeric_series(df, "In_COD")
    in_an = get_numeric_series(df, "In_AN")
    return {
        "in_water_q90": float(in_water.quantile(0.90)),
        "in_cod_q90": float(in_cod.quantile(0.90)),
        "in_an_q90": float(in_an.quantile(0.90)),
    }


def build_factory_scene_masks(df: pd.DataFrame, thresholds: Dict[str, float]) -> Dict[str, np.ndarray]:
    n_do = get_numeric_series(df, "N_On_DO").to_numpy(dtype=np.float32)
    s_do = get_numeric_series(df, "S_On_DO").to_numpy(dtype=np.float32)
    do_min = np.minimum(n_do, s_do)
    do_max = np.maximum(n_do, s_do)
    s_on_an = get_numeric_series(df, "S_On_AN").to_numpy(dtype=np.float32)
    out_an = get_numeric_series(df, "Out_AN").to_numpy(dtype=np.float32)
    out_tn = get_numeric_series(df, "Out_TN").to_numpy(dtype=np.float32)
    out_cod = get_numeric_series(df, "Out_COD").to_numpy(dtype=np.float32)
    out_ph_series = get_numeric_series(df, "Out_PH")
    out_ph = out_ph_series.to_numpy(dtype=np.float32)
    in_water = get_numeric_series(df, "In_Water").to_numpy(dtype=np.float32)
    in_cod = get_numeric_series(df, "In_COD").to_numpy(dtype=np.float32)
    in_an = get_numeric_series(df, "In_AN").to_numpy(dtype=np.float32)
    air = get_numeric_series(df, TARGET_COL).to_numpy(dtype=np.float32)
    air_median = np.nanmedian(air)
    air_p25 = np.nanpercentile(air, 25)
    air_p75 = np.nanpercentile(air, 75)

    compliant_ph = np.ones(len(df), dtype=bool)
    if not out_ph_series.isna().all():
        compliant_ph = (out_ph >= FACTORY_PH_LOW) & (out_ph <= FACTORY_PH_HIGH)

    masks: Dict[str, np.ndarray] = {}
    masks["full_compliance"] = (
        (out_cod <= FACTORY_OUT_COD_LIMIT)
        & (out_an <= FACTORY_OUT_AN_LIMIT)
        & (out_tn <= FACTORY_OUT_TN_LIMIT)
        & compliant_ph
    )
    masks["compliance_risk"] = ~masks["full_compliance"]
    masks["any_warning"] = (
        ((out_cod > FACTORY_OUT_COD_WARNING) & (out_cod <= FACTORY_OUT_COD_LIMIT))
        | ((out_an > FACTORY_OUT_AN_WARNING) & (out_an <= FACTORY_OUT_AN_LIMIT))
        | ((out_tn > FACTORY_OUT_TN_WARNING) & (out_tn <= FACTORY_OUT_TN_LIMIT))
    )

    masks["do_normal"] = (do_min >= FACTORY_DO_LOW) & (do_max <= FACTORY_DO_HIGH)
    masks["hypoxia"] = do_min < FACTORY_DO_LOW
    masks["critical_hypoxia"] = do_min < FACTORY_DO_CRITICAL_LOW
    masks["over_aeration"] = do_max > FACTORY_DO_HIGH
    masks["critical_over"] = do_max > FACTORY_DO_CRITICAL_HIGH
    masks["nitrification_stable"] = (do_min >= FACTORY_DO_LOW) & (s_on_an < FACTORY_SONAN_WARNING)
    masks["nitrification_inhibition"] = (do_min < FACTORY_DO_LOW) & (s_on_an >= FACTORY_SONAN_WARNING)
    masks["nitrification_failure"] = (do_min < FACTORY_DO_CRITICAL_LOW) & (s_on_an >= FACTORY_SONAN_HIGH)
    masks["false_safety"] = masks["do_normal"] & (s_on_an >= FACTORY_SONAN_HIGH)
    masks["inefficient_aeration"] = (do_min < FACTORY_DO_LOW) & (air > air_median)
    masks["energy_waste"] = (do_max > FACTORY_DO_HIGH) & (s_on_an < 0.5) & (air > air_median)
    masks["ideal_control"] = masks["do_normal"] & (air >= air_p25) & (air <= air_p75)
    masks["inflow_shock"] = (
        (in_water > thresholds["in_water_q90"])
        | (in_cod > thresholds["in_cod_q90"])
        | (in_an > thresholds["in_an_q90"])
    )

    masks["reuse_safe"] = (
        (out_cod <= FACTORY_REUSE_COD)
        & (out_an <= FACTORY_REUSE_AN)
        & (out_tn <= FACTORY_REUSE_TN)
    )
    masks["reuse_fragile"] = (
        ((out_cod > FACTORY_REUSE_COD) | (out_an > FACTORY_REUSE_AN) | (out_tn > FACTORY_REUSE_TN))
        & masks["full_compliance"]
    )
    masks["reuse_risk"] = ~masks["reuse_safe"]
    masks["reuse_high_assurance"] = (
        (out_cod <= FACTORY_OUT_COD_WARNING)
        & (out_an <= FACTORY_OUT_AN_WARNING)
        & (out_tn <= FACTORY_OUT_TN_WARNING)
    )
    masks["reuse_early_warning"] = masks["do_normal"] & masks["any_warning"]

    masks["all"] = np.ones(len(df), dtype=bool)
    masks["all_bio_risk"] = masks["hypoxia"] | masks["over_aeration"] | masks["false_safety"]
    masks["all_critical"] = (
        masks["critical_hypoxia"] | masks["critical_over"] | masks["nitrification_failure"]
    )
    return masks


def build_factory_method_table(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict[str, float]]:
    thresholds = compute_factory_scene_thresholds(df)
    masks = build_factory_scene_masks(df, thresholds)
    total = max(len(df), 1)
    scene_defs = [
        ("all", "全部数据", "All samples", "All available samples", "dataset", "Chronological evaluation split", "Overall predictive benchmark."),
        ("full_compliance", "✅ 一级A全面达标", "Full Class 1A compliance", f"Out_COD<={FACTORY_OUT_COD_LIMIT} and Out_AN<={FACTORY_OUT_AN_LIMIT} and Out_TN<={FACTORY_OUT_TN_LIMIT} and {FACTORY_PH_LOW}<=Out_PH<={FACTORY_PH_HIGH}", "national standard", "GB 18918-2002 Class 1A", "All monitored effluent indicators satisfy the Class 1A standard."),
        ("compliance_risk", "⚠️ 合规风险(任一超标)", "Compliance risk", f"Out_COD>{FACTORY_OUT_COD_LIMIT} or Out_AN>{FACTORY_OUT_AN_LIMIT} or Out_TN>{FACTORY_OUT_TN_LIMIT} or Out_PH outside [{FACTORY_PH_LOW}, {FACTORY_PH_HIGH}]", "national standard", "GB 18918-2002 Class 1A", "At least one effluent indicator exceeds the confirmed discharge requirement."),
        ("any_warning", "预警线(接近限值)", "Near-limit warning", f"Out_COD>{FACTORY_OUT_COD_WARNING} or Out_AN>{FACTORY_OUT_AN_WARNING} or Out_TN>{FACTORY_OUT_TN_WARNING}", "plant-specific warning", "Internal early-warning margin before compliance violation", "Effluent quality approaches the regulatory boundary and warrants proactive adjustment."),
        ("do_normal", "DO正常(2-4)", "Normal DO control zone", f"min(N_On_DO,S_On_DO)>={FACTORY_DO_LOW} and max(N_On_DO,S_On_DO)<={FACTORY_DO_HIGH}", "engineering rule", "A2O-MBR aeration control convention", "Biological aeration stays in the typical operating window."),
        ("hypoxia", "缺氧风险(DO<2)", "Hypoxia risk", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_LOW}", "engineering rule", "DO control rule", "Potential oxygen deficiency that may suppress nitrification."),
        ("critical_hypoxia", "严重缺氧(DO<1)", "Severe hypoxia", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_CRITICAL_LOW}", "engineering rule", "Emergency low-DO warning rule", "Critical aeration deficiency requiring intervention."),
        ("over_aeration", "过曝风险(DO>4)", "Over-aeration risk", f"max(N_On_DO,S_On_DO)>{FACTORY_DO_HIGH}", "engineering rule", "Energy-efficiency rule", "Potential excessive aeration and unnecessary energy use."),
        ("critical_over", "严重过曝(DO>6)", "Severe over-aeration", f"max(N_On_DO,S_On_DO)>{FACTORY_DO_CRITICAL_HIGH}", "engineering rule", "High-DO abnormality warning rule", "Extreme over-aeration or control inefficiency."),
        ("nitrification_stable", "硝化稳定", "Stable nitrification", f"min(N_On_DO,S_On_DO)>={FACTORY_DO_LOW} and S_On_AN<{FACTORY_SONAN_WARNING}", "engineering-bio rule", "DO-ammonia coupled nitrification judgment", "Aerobic-zone DO and ammonia remain in a stable nitrification regime."),
        ("nitrification_inhibition", "硝化受抑(DO<2, NH3≥2)", "Nitrification inhibition", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_LOW} and S_On_AN>={FACTORY_SONAN_WARNING}", "engineering-bio rule", "DO-ammonia coupled nitrification judgment", "Low DO coincides with elevated aerobic-zone ammonia, indicating nitrification suppression."),
        ("nitrification_failure", "硝化失败(DO<1, NH3≥5)", "Nitrification failure", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_CRITICAL_LOW} and S_On_AN>={FACTORY_SONAN_HIGH}", "engineering-bio rule", "Severe DO-ammonia coupled risk rule", "Critical oxygen deficiency coincides with high ammonia and signals severe nitrification deterioration."),
        ("false_safety", "⚠️ 虚假安全(DO正常, NH3高)", "False safety", f"{FACTORY_DO_LOW}<=DO<={FACTORY_DO_HIGH} and S_On_AN>={FACTORY_SONAN_HIGH}", "engineering-bio rule", "DO-normal but ammonia-abnormal hidden-risk rule", "DO appears normal while ammonia remains high, indicating hidden process risk."),
        ("inefficient_aeration", "无效曝气", "Inefficient aeration", f"min(N_On_DO,S_On_DO)<{FACTORY_DO_LOW} and {TARGET_COL}>median", "engineering-energy rule", "High aeration but low-DO response", "Aeration input remains high but oxygen supply is still insufficient."),
        ("energy_waste", "过度曝气浪费", "Energy waste", f"max(N_On_DO,S_On_DO)>{FACTORY_DO_HIGH} and S_On_AN<0.5 and {TARGET_COL}>median", "engineering-energy rule", "High-DO with already low aerobic-zone ammonia", "Further aeration is unlikely to bring substantial treatment benefit."),
        ("ideal_control", "理想控制区", "Ideal control zone", f"{FACTORY_DO_LOW}<=DO<={FACTORY_DO_HIGH} and P25<={TARGET_COL}<=P75", "engineering rule", "Balanced aeration control zone", "Oxygen control and aeration intensity remain in a balanced operating range."),
        ("inflow_shock", "进水冲击", "Influent shock", f"In_Water>{thresholds['in_water_q90']:.2f} or In_COD>{thresholds['in_cod_q90']:.2f} or In_AN>{thresholds['in_an_q90']:.2f}", "data-driven percentile", "Plant historical data q90 thresholds", "Hydraulic or pollutant loading shock."),
        ("reuse_safe", "回用安全", "Reuse safe", f"Out_COD<={FACTORY_REUSE_COD} and Out_AN<={FACTORY_REUSE_AN} and Out_TN<={FACTORY_REUSE_TN}", "plant-specific warning", "Internal reclaimed-water safety threshold", "Effluent quality remains within a conservative reclaimed-water safety margin."),
        ("reuse_fragile", "回用脆弱(接近上限)", "Reuse fragile", f"(Out_COD>{FACTORY_REUSE_COD} or Out_AN>{FACTORY_REUSE_AN} or Out_TN>{FACTORY_REUSE_TN}) and full compliance", "plant-specific warning", "Internal reclaimed-water fragility threshold", "Effluent still complies with discharge limits but the reuse margin has narrowed."),
        ("reuse_risk", "回用风险", "Reuse risk", f"not reuse_safe", "plant-specific warning", "Internal reclaimed-water warning threshold", "Effluent quality no longer satisfies the conservative reuse-safety margin."),
        ("reuse_high_assurance", "回用高保障", "Reuse high assurance", f"Out_COD<={FACTORY_OUT_COD_WARNING} and Out_AN<={FACTORY_OUT_AN_WARNING} and Out_TN<={FACTORY_OUT_TN_WARNING}", "plant-specific warning", "High-assurance reclaimed-water margin", "Effluent quality remains comfortably below the internal warning thresholds."),
        ("reuse_early_warning", "回用预警(DO正常但水质抬升)", "Reuse early warning", f"{FACTORY_DO_LOW}<=DO<={FACTORY_DO_HIGH} and (Out_COD>{FACTORY_OUT_COD_WARNING} or Out_AN>{FACTORY_OUT_AN_WARNING} or Out_TN>{FACTORY_OUT_TN_WARNING})", "plant-specific warning", "DO-normal but reclaimed-water quality warning rule", "Process oxygen appears normal while effluent quality begins to rise toward the warning boundary."),
        ("all_bio_risk", "所有生化风险", "All biological risks", "hypoxia or over-aeration or false safety", "composite engineering rule", "Union of core biological risk scenarios", "Combined view of the main biological reaction risks."),
        ("all_critical", "所有极端工况", "All critical conditions", "critical hypoxia or critical over-aeration or nitrification failure", "composite engineering rule", "Union of critical operating scenarios", "Combined view of the most critical operating conditions."),
    ]
    rows = []
    for scene_id, cn, en, rule_def, source_type, source_reference, meaning in scene_defs:
        count = int(np.sum(masks[scene_id]))
        rows.append({
            "plant_name_cn": PLANT_NAME_CN,
            "plant_process": PLANT_PROCESS_CN,
            "discharge_standard": PLANT_DISCHARGE_STANDARD,
            "reuse_note": PLANT_REUSE_NOTE,
            "scenario_id": scene_id,
            "scenario_cn": cn,
            "scenario_en": en,
            "rule_definition": rule_def,
            "source_type": source_type,
            "source_reference": source_reference,
            "engineering_meaning": meaning,
            "sample_count": count,
            "sample_ratio_pct": round(100.0 * count / total, 2),
        })
    return pd.DataFrame(rows), thresholds


def compute_scene_summary(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    persistence_pred: np.ndarray,
    baseline_now: np.ndarray,
) -> Dict[str, float]:
    mae_model, rmse_model = safe_regression_metrics(y_true, y_pred)
    mae_persistence, rmse_persistence = safe_regression_metrics(y_true, persistence_pred)
    abs_delta = np.abs(y_true - baseline_now)
    change_mask = abs_delta >= np.quantile(abs_delta, TRANSITION_TOP_QUANTILE)
    _, rmse_delta_model = safe_regression_metrics(y_true[change_mask], y_pred[change_mask])
    _, rmse_delta_persistence = safe_regression_metrics(y_true[change_mask], persistence_pred[change_mask])
    mae_gain = np.nan if np.isnan(mae_persistence) or mae_persistence == 0 else 100.0 * (mae_persistence - mae_model) / mae_persistence
    rmse_gain = np.nan if np.isnan(rmse_persistence) or rmse_persistence == 0 else 100.0 * (rmse_persistence - rmse_model) / rmse_persistence
    delta_gain = np.nan if np.isnan(rmse_delta_persistence) or rmse_delta_persistence == 0 else 100.0 * (rmse_delta_persistence - rmse_delta_model) / rmse_delta_persistence
    return {
        "mae": mae_model,
        "rmse": rmse_model,
        "bias": safe_bias(y_true, y_pred),
        "persistence_mae": mae_persistence,
        "persistence_rmse": rmse_persistence,
        "mae_gain_pct_vs_persistence": mae_gain,
        "rmse_gain_pct_vs_persistence": rmse_gain,
        "rmse_delta_top10": rmse_delta_model,
        "persistence_rmse_delta_top10": rmse_delta_persistence,
        "delta_top10_gain_pct_vs_persistence": delta_gain,
        "n_delta_top10": float(np.sum(change_mask)),
    }


def build_factory_scene_diagnostics(
    eval_context_df: pd.DataFrame,
    y_true_selected: np.ndarray,
    y_pred_selected: np.ndarray,
    y_pred_persistence_selected: np.ndarray,
    baseline_now: np.ndarray,
    model_name: str,
) -> pd.DataFrame:
    method_df, thresholds = build_factory_method_table(eval_context_df)
    masks = build_factory_scene_masks(eval_context_df, thresholds)
    lookup = method_df.set_index("scenario_id").to_dict(orient="index")
    total = max(len(eval_context_df), 1)
    rows = []
    for idx, horizon in enumerate(HORIZON_MINS):
        for scene_id in method_df["scenario_id"].tolist():
            mask = masks[scene_id]
            n_samples = int(np.sum(mask))
            meta = lookup[scene_id]
            metric_payload = {
                "mae": np.nan,
                "rmse": np.nan,
                "bias": np.nan,
                "persistence_mae": np.nan,
                "persistence_rmse": np.nan,
                "mae_gain_pct_vs_persistence": np.nan,
                "rmse_gain_pct_vs_persistence": np.nan,
                "rmse_delta_top10": np.nan,
                "persistence_rmse_delta_top10": np.nan,
                "delta_top10_gain_pct_vs_persistence": np.nan,
                "n_delta_top10": 0.0,
            }
            if n_samples >= FACTORY_SCENE_MIN_SAMPLES:
                metric_payload = compute_scene_summary(
                    y_true=y_true_selected[:, idx][mask],
                    y_pred=y_pred_selected[:, idx][mask],
                    persistence_pred=y_pred_persistence_selected[:, idx][mask],
                    baseline_now=baseline_now[mask],
                )
            rows.append({
                "horizon_min": horizon,
                "model_type": model_name,
                "scenario_id": scene_id,
                "scenario_cn": meta["scenario_cn"],
                "scenario_en": meta["scenario_en"],
                "source_type": meta["source_type"],
                "source_reference": meta["source_reference"],
                "rule_definition": meta["rule_definition"],
                "engineering_meaning": meta["engineering_meaning"],
                "n_samples": n_samples,
                "sample_ratio_pct": round(100.0 * n_samples / total, 2),
                **metric_payload,
            })
    return pd.DataFrame(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Official TSLib model comparison with chronological split")
    parser.add_argument(
        "--model-name",
        default=MODEL_NAME,
        help="Model name to run, e.g. PatchTST, PatchTSTExtreme, LSTM, or GRU",
    )
    parser.add_argument("--random-state", type=int, default=RANDOM_STATE, help="Random seed for reproducibility")
    parser.add_argument("--output-tag", default="", help="Optional suffix appended to output filenames")
    parser.add_argument(
        "--engineering-low-thresholds",
        default="",
        help="Comma-separated engineering low thresholds for 30,60,90 min; use none to disable",
    )
    parser.add_argument(
        "--engineering-high-thresholds",
        default="",
        help="Comma-separated engineering high thresholds for 30,60,90 min; use none to disable",
    )
    parser.add_argument("--ablate-no-conv", action="store_true", help="Disable the local convolution stem for PatchTSTExtremeConvAsymmetricV2-family models.")
    parser.add_argument("--ablate-no-asym", action="store_true", help="Legacy switch retained for compatibility. The formal asymmetric-v2 family now uses DensityAwareExtremeLoss by default, so this flag is informational only.")
    parser.add_argument("--ablate-no-density", action="store_true", help="Disable DensityAwareExtremeLoss and fall back to the plain MSE loss.")
    parser.add_argument("--ablate-no-transition", action="store_true", help="Legacy switch retained for compatibility. The formal asymmetric-v2 family now uses DensityAwareExtremeLoss by default, so this flag is informational only.")
    return parser.parse_args()


def compute_horizon_diagnostics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    persistence_pred: np.ndarray,
    baseline_now: np.ndarray,
    low_threshold: float,
    high_threshold: float,
    delta_quantile: float = 0.9,
) -> Dict[str, float]:
    metrics: Dict[str, float] = {}

    low_mask = y_true <= low_threshold
    high_mask = y_true >= high_threshold
    delta = y_true - baseline_now
    change_mask = np.abs(delta) >= np.quantile(np.abs(delta), delta_quantile)

    metrics["mae_low"], metrics["rmse_low"] = safe_regression_metrics(y_true[low_mask], y_pred[low_mask])
    metrics["mae_high"], metrics["rmse_high"] = safe_regression_metrics(y_true[high_mask], y_pred[high_mask])
    metrics["bias_low"] = safe_bias(y_true[low_mask], y_pred[low_mask])
    metrics["bias_high"] = safe_bias(y_true[high_mask], y_pred[high_mask])
    _, metrics["rmse_delta_top10"] = safe_regression_metrics(y_true[change_mask], y_pred[change_mask])
    _, metrics["rmse_delta_top10_persistence"] = safe_regression_metrics(
        y_true[change_mask], persistence_pred[change_mask]
    )

    pred_low_event = (y_pred <= low_threshold).astype(int)
    pred_high_event = (y_pred >= high_threshold).astype(int)
    persistence_low_event = (persistence_pred <= low_threshold).astype(int)
    persistence_high_event = (persistence_pred >= high_threshold).astype(int)
    true_low_event = low_mask.astype(int)
    true_high_event = high_mask.astype(int)

    low_cls = classification_metrics_from_events(true_low_event, pred_low_event)
    high_cls = classification_metrics_from_events(true_high_event, pred_high_event)
    low_cls_persist = classification_metrics_from_events(true_low_event, persistence_low_event)
    high_cls_persist = classification_metrics_from_events(true_high_event, persistence_high_event)

    metrics["n_low"] = float(low_mask.sum())
    metrics["n_high"] = float(high_mask.sum())
    metrics["n_delta_top10"] = float(change_mask.sum())

    for key, value in low_cls.items():
        metrics[f"{key}_low"] = value
    for key, value in high_cls.items():
        metrics[f"{key}_high"] = value
    for key, value in low_cls_persist.items():
        metrics[f"persistence_{key}_low"] = value
    for key, value in high_cls_persist.items():
        metrics[f"persistence_{key}_high"] = value

    return metrics


def prefix_metric_keys(metrics: Dict[str, float], prefix: str) -> Dict[str, float]:
    return {f"{prefix}_{k}": v for k, v in metrics.items()}


def build_time_mark_array(ts: pd.Series, freq: str) -> np.ndarray:
    idx = pd.DatetimeIndex(pd.to_datetime(ts))
    return TSLIB_TIME_FEATURES(idx, freq=freq).transpose(1, 0).astype(np.float32)


def inverse_target_scale(values_scaled: np.ndarray, scaler: MinMaxScaler, target_idx: int) -> np.ndarray:
    return (values_scaled - scaler.min_[target_idx]) / scaler.scale_[target_idx]


def build_official_seq_dataset(
    df_in: pd.DataFrame,
    feature_cols: List[str],
    seq_len: int,
    label_len: int,
    pred_len: int,
    freq: str,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    keep_cols = [TIME_COL] + feature_cols
    temp = df_in[keep_cols].dropna().copy().reset_index(drop=True)
    feature_data = temp[feature_cols].to_numpy(dtype=np.float32)
    time_data = pd.to_datetime(temp[TIME_COL]).reset_index(drop=True)
    time_mark = build_time_mark_array(time_data, freq=freq)
    target_idx = feature_cols.index(TARGET_COL)

    X_seq, Y_seq, X_mark, Y_mark, y_true, t_ref = [], [], [], [], [], []
    max_end = len(temp) - pred_len

    for end_idx in range(seq_len - 1, max_end):
        x_start = end_idx - seq_len + 1
        label_start = end_idx - label_len + 1
        future_start = end_idx + 1
        future_end = future_start + pred_len

        enc_x = feature_data[x_start:end_idx + 1]
        enc_mark = time_mark[x_start:end_idx + 1]

        dec_hist = feature_data[label_start:end_idx + 1]
        dec_future = feature_data[future_start:future_end]
        dec_y = np.concatenate([dec_hist, dec_future], axis=0)

        dec_hist_mark = time_mark[label_start:end_idx + 1]
        dec_future_mark = time_mark[future_start:future_end]
        dec_mark = np.concatenate([dec_hist_mark, dec_future_mark], axis=0)

        X_seq.append(enc_x)
        X_mark.append(enc_mark)
        Y_seq.append(dec_y)
        Y_mark.append(dec_mark)
        y_true.append(dec_future[:, target_idx])
        t_ref.append(time_data.iloc[end_idx])

    return (
        np.asarray(X_seq, dtype=np.float32),
        np.asarray(Y_seq, dtype=np.float32),
        np.asarray(X_mark, dtype=np.float32),
        np.asarray(Y_mark, dtype=np.float32),
        np.asarray(y_true, dtype=np.float32),
        np.asarray(t_ref),
    )


def build_density_weight_tables(
    train_targets_selected: np.ndarray,
    num_bins: int,
    smooth_sigma: float,
    rarity_power: float,
) -> Tuple[np.ndarray, np.ndarray]:
    edge_tables = []
    rarity_tables = []

    radius = max(1, int(math.ceil(3 * smooth_sigma)))
    offsets = np.arange(-radius, radius + 1, dtype=np.float32)
    kernel = np.exp(-0.5 * (offsets / smooth_sigma) ** 2)
    kernel = kernel / kernel.sum()

    for col in range(train_targets_selected.shape[1]):
        values = train_targets_selected[:, col].astype(np.float32)
        vmin, vmax = float(values.min()), float(values.max())
        if vmax <= vmin:
            vmax = vmin + 1.0
        edges = np.linspace(vmin, vmax, num_bins + 1, dtype=np.float32)
        hist, _ = np.histogram(values, bins=edges)
        hist = hist.astype(np.float32)
        smooth = np.convolve(hist, kernel, mode="same") + 1e-6
        rarity = np.power(smooth.mean() / smooth, rarity_power).astype(np.float32)
        rarity = rarity / rarity.mean()
        edge_tables.append(edges)
        rarity_tables.append(rarity)

    return np.stack(edge_tables, axis=0), np.stack(rarity_tables, axis=0)


def build_model(model_name: str, configs: Config) -> nn.Module:
    model_key = model_name.lower()
    if model_key not in MODEL_MODULES:
        raise ValueError(f"Unsupported MODEL_NAME: {model_name}")

    if model_key == "patchtstkan":
        return PatchTSTKANModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            target_feature_idx=configs.enc_in - 1,
        )
    if model_key == "patchtstextrememultiscale":
        return PatchTSTExtremeMultiScaleModel(
            configs=configs,
            horizon_indices=[h - 1 for h in HORIZON_MINS],
            target_feature_idx=configs.enc_in - 1,
        )
    if model_key in {
        "patchtstextremeconv",
        "patchtstextremeconvv1",
        "patchtstextremeconvasymmetricv2",
        "patchtstextremeconvasymmetricv2freezetune",
    }:
        model_cls = PatchTSTExtremeModel if ABLATE_NO_CONV else PatchTSTExtremeConvModel
        return model_cls(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_MINS],
        )
    if model_key == "patchtstextremeconvtargetbranch":
        return PatchTSTExtremeConvTargetBranchModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_MINS],
        )
    if model_key == "patchtstextremetcnfront":
        return PatchTSTExtremeTCNFrontModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_MINS],
        )
    if model_key == "patchtstextremeconvdeep":
        return PatchTSTExtremeConvDeepModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_MINS],
        )
    if model_key == "patchtstextremecnn":
        return PatchTSTExtremeCNNModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_MINS],
        )
    if model_key == "patchtstextremerefine":
        return PatchTSTExtremeRefineModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_MINS],
            target_feature_idx=configs.enc_in - 1,
        )
    if model_key == "patchtstextremeevent":
        return PatchTSTExtremeEventModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_MINS],
            target_feature_idx=configs.enc_in - 1,
        )
    if model_key in {
        "patchtsthead",
        "patchtstheadtail",
        "patchtstheadhorizon",
        "patchtstextreme",
        "patchtstextremeadaptive",
        "patchtstextremeasymmetric",
        "patchtstextremeasymmetricv2",
    }:
        return PatchTSTExtremeModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_MINS],
        )
    if model_key == "tcn":
        return TCNForecaster(
            input_dim=configs.enc_in,
            pred_len=configs.pred_len,
            hidden_dim=configs.tcn_hidden_dim,
            num_layers=configs.tcn_num_layers,
            dropout=configs.tcn_dropout,
        )
    if model_key == "nbeatsx":
        return NBeatsXForecaster(
            input_dim=configs.enc_in,
            seq_len=configs.seq_len,
            pred_len=configs.pred_len,
            hidden_dim=configs.nbeats_hidden_dim,
            num_blocks=configs.nbeats_num_blocks,
            num_layers=configs.nbeats_num_layers,
            context_dim=configs.nbeats_context_dim,
            dropout=configs.nbeats_dropout,
            target_feature_idx=configs.enc_in - 1,
        )
    if model_key == "deeparlike":
        return DeepARLikeForecaster(
            input_dim=configs.enc_in,
            pred_len=configs.pred_len,
            hidden_dim=configs.deepar_hidden_dim,
            dropout=configs.deepar_dropout,
            target_feature_idx=configs.enc_in - 1,
            horizon_embed_dim=configs.deepar_horizon_embed_dim,
        )
    if model_key in {"lstm", "gru"}:
        return DirectRNNForecaster(
            input_dim=configs.enc_in,
            pred_len=configs.pred_len,
            hidden_dim=128,
            dense_dim=64,
            dropout=0.1,
            cell_type=model_key,
        )

    module = importlib.import_module(f"models.{MODEL_MODULES[model_key]}")

    if model_key == "patchtst":
        return module.Model(configs, patch_len=configs.patch_len, stride=configs.stride)
    if model_key == "dlinear":
        return module.Model(configs, individual=configs.individual)
    return module.Model(configs)


def build_training_criterion(
    model_name: str,
    train_targets_selected: np.ndarray,
    train_current_targets: np.ndarray,
    train_targets_full: np.ndarray,
) -> nn.Module:
    model_key = model_name.lower()
    if model_key not in {
        "patchtstheadtail",
        "patchtstheadhorizon",
        "patchtstextreme",
        "patchtstextremeconv",
        "patchtstextremeconvv1",
        "patchtstextremeconvasymmetricv2",
        "patchtstextremeconvasymmetricv2freezetune",
        "patchtstextremeconvtargetbranch",
        "patchtstextremetcnfront",
        "patchtstextremeconvdeep",
        "patchtstextremecnn",
        "patchtstextremeasymmetric",
        "patchtstextremeasymmetricv2",
        "patchtstextrememultiscale",
        "patchtstextremeadaptive",
        "patchtstextremeevent",
        "patchtstextremerefine",
    }:
        return nn.MSELoss()

    low_thresholds = np.quantile(train_targets_selected, EXTREME_TAIL_QUANTILE, axis=0).astype(np.float32)
    high_thresholds = np.quantile(train_targets_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0).astype(np.float32)

    if model_key == "patchtstheadtail":
        horizon_weights = [UNIFORM_HORIZON_WEIGHT] * len(HORIZON_MINS)
        low_weights = [UNIFORM_LOW_WEIGHT] * len(HORIZON_MINS)
        high_weights = [UNIFORM_HIGH_WEIGHT] * len(HORIZON_MINS)
        density_edges = np.zeros((len(HORIZON_MINS), 2), dtype=np.float32)
        density_weights = np.ones((len(HORIZON_MINS), 1), dtype=np.float32)
        density_blend = 0.0
        mode_name = "uniform_tail"
    elif model_key == "patchtstheadhorizon":
        horizon_weights = EXTREME_HORIZON_WEIGHTS
        low_weights = EXTREME_LOW_WEIGHTS
        high_weights = EXTREME_HIGH_WEIGHTS
        density_edges = np.zeros((len(HORIZON_MINS), 2), dtype=np.float32)
        density_weights = np.ones((len(HORIZON_MINS), 1), dtype=np.float32)
        density_blend = 0.0
        mode_name = "horizon_specific"
    else:
        horizon_weights = EXTREME_HORIZON_WEIGHTS
        low_weights = EXTREME_LOW_WEIGHTS
        high_weights = EXTREME_HIGH_WEIGHTS
        density_edges, density_weights = build_density_weight_tables(
            train_targets_selected=train_targets_selected,
            num_bins=DENSITY_NUM_BINS,
            smooth_sigma=DENSITY_SMOOTH_SIGMA,
            rarity_power=DENSITY_WEIGHT_POWER,
        )
        density_blend = 0.0 if ABLATE_NO_DENSITY else DENSITY_WEIGHT_BLEND
        mode_name = "density_aware"
        if model_key == "patchtstextremeevent":
            mode_name = "density_event_aware"
        elif model_key in {
            "patchtstextremeasymmetricv2",
            "patchtstextremeconvasymmetricv2",
            "patchtstextremeconvasymmetricv2freezetune",
            "patchtstextremeconvtargetbranch",
        }:
            mode_name = "mse_ablation" if ABLATE_NO_DENSITY else "density_aware_formal"
        elif model_key == "patchtstextremeasymmetric":
            mode_name = "density_asymmetric"
        elif model_key == "patchtstextremeadaptive":
            mode_name = "density_adaptive"

    horizon_pairs = ", ".join(
        f"h{h}:lw={lw:.2f},hw={hw:.2f},pw={pw:.2f}"
        for h, lw, hw, pw in zip(HORIZON_MINS, low_weights, high_weights, horizon_weights)
    )
    print(
        "EXTREME_LOSS_INFO: "
        f"mode={mode_name}, "
        f"q={EXTREME_TAIL_QUANTILE}, "
        f"low_thr={[round(float(v), 3) for v in low_thresholds]}, "
        f"high_thr={[round(float(v), 3) for v in high_thresholds]}, "
        f"{horizon_pairs}, "
        f"density_bins={DENSITY_NUM_BINS}, sigma={DENSITY_SMOOTH_SIGMA}, "
        f"blend={density_blend}, power={DENSITY_WEIGHT_POWER}"
    )
    if model_key == "patchtstextremeadaptive":
        print(
            "EXTREME_ADAPTIVE_INFO: "
            f"extreme_strength={ADAPTIVE_EXTREME_STRENGTH}, "
            f"direction_strength={ADAPTIVE_DIRECTION_STRENGTH}, "
            f"error_power={ADAPTIVE_DIRECTION_ERROR_POWER}, "
            f"high_tail_scale={ADAPTIVE_HIGH_TAIL_SCALE}, "
            f"low_tail_scale={ADAPTIVE_LOW_TAIL_SCALE}, "
            f"max_point_weight={ADAPTIVE_MAX_POINT_WEIGHT}"
        )
        return AdaptiveDensityAwareExtremeLoss(
            horizon_indices=[h - 1 for h in HORIZON_MINS],
            low_thresholds=low_thresholds.tolist(),
            high_thresholds=high_thresholds.tolist(),
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_edges,
            density_bin_weights=density_weights,
            density_weight_blend=density_blend,
            adaptive_extreme_strength=ADAPTIVE_EXTREME_STRENGTH,
            adaptive_direction_strength=ADAPTIVE_DIRECTION_STRENGTH,
            adaptive_direction_error_power=ADAPTIVE_DIRECTION_ERROR_POWER,
            adaptive_high_tail_scale=ADAPTIVE_HIGH_TAIL_SCALE,
            adaptive_low_tail_scale=ADAPTIVE_LOW_TAIL_SCALE,
            adaptive_max_point_weight=ADAPTIVE_MAX_POINT_WEIGHT,
        )

    if model_key == "patchtstextremeasymmetric":
        delta_train = train_targets_selected - train_current_targets[:, None]
        transition_thresholds = np.quantile(
            np.abs(delta_train),
            TRANSITION_TOP_QUANTILE,
            axis=0,
        ).astype(np.float32)
        print(
            "EXTREME_ASYM_INFO: "
            f"transition_q={TRANSITION_TOP_QUANTILE}, "
            f"transition_thr={[round(float(v), 3) for v in transition_thresholds]}, "
            f"extreme_strength={ASYM_EXTREME_STRENGTH}, "
            f"low_over_strength={ASYM_LOW_OVER_STRENGTH}, "
            f"high_under_strength={ASYM_HIGH_UNDER_STRENGTH}, "
            f"error_power={ASYM_DIRECTION_ERROR_POWER}, "
            f"high_tail_scale={ASYM_HIGH_TAIL_SCALE}, "
            f"low_tail_scale={ASYM_LOW_TAIL_SCALE}, "
            f"transition_strength={ASYM_TRANSITION_STRENGTH}, "
            f"max_point_weight={ASYM_MAX_POINT_WEIGHT}"
        )
        return AsymmetricDirectionalExtremeLoss(
            horizon_indices=[h - 1 for h in HORIZON_MINS],
            low_thresholds=low_thresholds.tolist(),
            high_thresholds=high_thresholds.tolist(),
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_edges,
            density_bin_weights=density_weights,
            density_weight_blend=density_blend,
            transition_thresholds=transition_thresholds.tolist(),
            extreme_strength=ASYM_EXTREME_STRENGTH,
            low_over_strength=ASYM_LOW_OVER_STRENGTH,
            high_under_strength=ASYM_HIGH_UNDER_STRENGTH,
            direction_error_power=ASYM_DIRECTION_ERROR_POWER,
            high_tail_scale=ASYM_HIGH_TAIL_SCALE,
            low_tail_scale=ASYM_LOW_TAIL_SCALE,
            transition_strength=ASYM_TRANSITION_STRENGTH,
            max_point_weight=ASYM_MAX_POINT_WEIGHT,
        )

    if model_key in {
        "patchtstextremeasymmetricv2",
        "patchtstextremeconvasymmetricv2",
        "patchtstextremeconvasymmetricv2freezetune",
        "patchtstextremeconvtargetbranch",
    }:
        if ABLATE_NO_ASYM or ABLATE_NO_TRANSITION:
            print(
                "ABLATION_INFO: "
                "no_asym/no_transition are legacy switches for the asymmetric-v2 family. "
                "The formal model now uses DensityAwareExtremeLoss by default."
            )
        if ABLATE_NO_DENSITY:
            print("ABLATION_INFO: no_density=True -> using plain MSELoss.")
            return nn.MSELoss()
        print("FORMAL_LOSS_INFO: using DensityAwareExtremeLoss as the default formal loss.")
        return DensityAwareExtremeLoss(
            horizon_indices=[h - 1 for h in HORIZON_MINS],
            low_thresholds=low_thresholds.tolist(),
            high_thresholds=high_thresholds.tolist(),
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_edges,
            density_bin_weights=density_weights,
            density_weight_blend=density_blend,
        )

    if model_key == "patchtstextremeevent":
        delta_train = train_targets_selected - train_current_targets[:, None]
        transition_thresholds = np.quantile(np.abs(delta_train), TRANSITION_TOP_QUANTILE, axis=0).astype(np.float32)

        low_targets = (train_targets_selected <= low_thresholds[None, :]).astype(np.float32)
        high_targets = (train_targets_selected >= high_thresholds[None, :]).astype(np.float32)
        transition_targets = (np.abs(delta_train) >= transition_thresholds[None, :]).astype(np.float32)
        stacked_targets = np.stack([low_targets, high_targets, transition_targets], axis=-1)
        positive_rate = stacked_targets.mean(axis=0)
        event_pos_weights = (1.0 - positive_rate) / np.clip(positive_rate, 1e-4, None)
        event_pos_weights = np.clip(event_pos_weights, 1.0, 20.0).astype(np.float32)

        print(
            "EXTREME_EVENT_INFO: "
            f"transition_q={TRANSITION_TOP_QUANTILE}, "
            f"transition_thr={[round(float(v), 3) for v in transition_thresholds]}, "
            f"delta_loss_w={EVENT_DELTA_LOSS_WEIGHT}, "
            f"event_bce_w={EVENT_BCE_LOSS_WEIGHT}, "
            f"transition_weight={EVENT_TRANSITION_WEIGHT}, "
            f"tail_weight={EVENT_TAIL_WEIGHT}"
        )
        return EventAwareExtremeLoss(
            horizon_indices=[h - 1 for h in HORIZON_MINS],
            low_thresholds=low_thresholds.tolist(),
            high_thresholds=high_thresholds.tolist(),
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_edges,
            density_bin_weights=density_weights,
            density_weight_blend=density_blend,
            transition_thresholds=transition_thresholds.tolist(),
            event_pos_weights=event_pos_weights,
            delta_loss_weight=EVENT_DELTA_LOSS_WEIGHT,
            event_loss_weight=EVENT_BCE_LOSS_WEIGHT,
            transition_weight=EVENT_TRANSITION_WEIGHT,
            tail_weight=EVENT_TAIL_WEIGHT,
        )

    if model_key == "patchtstextremerefine":
        delta_train_selected = train_targets_selected - train_current_targets[:, None]
        transition_thresholds = np.quantile(
            np.abs(delta_train_selected),
            TRANSITION_TOP_QUANTILE,
            axis=0,
        ).astype(np.float32)
        delta_train_full = train_targets_full - train_current_targets[:, None]
        full_delta_threshold = float(np.quantile(np.abs(delta_train_full), TRANSITION_TOP_QUANTILE))

        low_targets = (train_targets_selected <= low_thresholds[None, :]).astype(np.float32)
        high_targets = (train_targets_selected >= high_thresholds[None, :]).astype(np.float32)
        transition_targets = (np.abs(delta_train_selected) >= transition_thresholds[None, :]).astype(np.float32)
        stacked_targets = np.stack([low_targets, high_targets, transition_targets], axis=-1)
        positive_rate = stacked_targets.mean(axis=0)
        event_pos_weights = (1.0 - positive_rate) / np.clip(positive_rate, 1e-4, None)
        event_pos_weights = np.clip(event_pos_weights, 1.0, 20.0).astype(np.float32)

        print(
            "EXTREME_REFINE_INFO: "
            f"transition_q={TRANSITION_TOP_QUANTILE}, "
            f"selected_transition_thr={[round(float(v), 3) for v in transition_thresholds]}, "
            f"full_delta_thr={round(full_delta_threshold, 3)}, "
            f"delta_loss_w={REFINE_DELTA_LOSS_WEIGHT}, "
            f"event_loss_w={REFINE_EVENT_LOSS_WEIGHT}, "
            f"transition_weight={REFINE_TRANSITION_WEIGHT}"
        )
        return RefineAwareExtremeLoss(
            horizon_indices=[h - 1 for h in HORIZON_MINS],
            low_thresholds=low_thresholds.tolist(),
            high_thresholds=high_thresholds.tolist(),
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_edges,
            density_bin_weights=density_weights,
            density_weight_blend=density_blend,
            transition_thresholds=transition_thresholds.tolist(),
            full_delta_threshold=full_delta_threshold,
            event_pos_weights=event_pos_weights,
            delta_loss_weight=REFINE_DELTA_LOSS_WEIGHT,
            event_loss_weight=REFINE_EVENT_LOSS_WEIGHT,
            transition_weight=REFINE_TRANSITION_WEIGHT,
        )

    return DensityAwareExtremeLoss(
        horizon_indices=[h - 1 for h in HORIZON_MINS],
        low_thresholds=low_thresholds.tolist(),
        high_thresholds=high_thresholds.tolist(),
        horizon_weights=horizon_weights,
        low_weights=low_weights,
        high_weights=high_weights,
        density_bin_edges=density_edges,
        density_bin_weights=density_weights,
        density_weight_blend=density_blend,
    )


def amp_enabled_for_model(model_name: str, device: str) -> bool:
    return USE_AMP and device.startswith("cuda") and model_name.lower() not in AMP_UNSAFE_MODELS


def extract_forecast_tensor(model_output: torch.Tensor | Dict[str, torch.Tensor]) -> torch.Tensor:
    if isinstance(model_output, dict):
        return model_output["forecast"]
    return model_output


def forward_official(
    model: nn.Module,
    batch_x: torch.Tensor,
    batch_y: torch.Tensor,
    batch_x_mark: torch.Tensor,
    batch_y_mark: torch.Tensor,
    cfg: Config,
) -> Tuple[torch.Tensor, torch.Tensor]:
    true = batch_y[:, -cfg.pred_len:, -1:]

    if isinstance(model, DirectRNNForecaster):
        outputs = model(batch_x, batch_x_mark, None, None)
        pred = outputs[:, -cfg.pred_len:, :]
        return pred, true

    dec_inp = torch.zeros_like(batch_y[:, -cfg.pred_len:, :], device=batch_y.device)
    dec_inp = torch.cat([batch_y[:, :cfg.label_len, :], dec_inp], dim=1)

    outputs = model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
    pred_full = extract_forecast_tensor(outputs)
    f_dim = -1 if cfg.features == "MS" else 0
    pred = pred_full[:, -cfg.pred_len:, f_dim:]
    if isinstance(outputs, dict):
        pred_bundle = dict(outputs)
        pred_bundle["forecast"] = pred
        if "current_target" not in pred_bundle:
            pred_bundle["current_target"] = batch_x[:, -1, -1]
        return pred_bundle, true
    return pred, true


def train_model(
    model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    cfg: Config,
    model_name: str,
    criterion: nn.Module,
    epochs: int,
    lr: float,
    patience: int,
    device: str,
) -> nn.Module:
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=WEIGHT_DECAY)
    amp_enabled = amp_enabled_for_model(model_name, device)
    scaler = torch.cuda.amp.GradScaler(enabled=amp_enabled)

    model.to(device)
    criterion = criterion.to(device)
    best_val = float("inf")
    best_state = None
    wait = 0
    epoch_times = []

    for epoch in range(1, epochs + 1):
        epoch_start = time.perf_counter()
        model.train()
        train_losses = []
        for xb, yb, xb_mark, yb_mark in train_loader:
            xb = xb.to(device, non_blocking=PIN_MEMORY)
            yb = yb.to(device, non_blocking=PIN_MEMORY)
            xb_mark = xb_mark.to(device, non_blocking=PIN_MEMORY)
            yb_mark = yb_mark.to(device, non_blocking=PIN_MEMORY)
            current_target = xb[:, -1, -1].view(-1, 1, 1)

            optimizer.zero_grad()
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled):
                pred, true = forward_official(model, xb, yb, xb_mark, yb_mark, cfg)
                if getattr(criterion, "requires_current_target", False):
                    loss = criterion(pred, true, current_target)
                else:
                    loss = criterion(pred, true)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            train_losses.append(loss.item())

        model.eval()
        val_losses = []
        with torch.no_grad():
            for xb, yb, xb_mark, yb_mark in val_loader:
                xb = xb.to(device, non_blocking=PIN_MEMORY)
                yb = yb.to(device, non_blocking=PIN_MEMORY)
                xb_mark = xb_mark.to(device, non_blocking=PIN_MEMORY)
                yb_mark = yb_mark.to(device, non_blocking=PIN_MEMORY)
                current_target = xb[:, -1, -1].view(-1, 1, 1)

                with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled):
                    pred, true = forward_official(model, xb, yb, xb_mark, yb_mark, cfg)
                    if getattr(criterion, "requires_current_target", False):
                        loss = criterion(pred, true, current_target)
                    else:
                        loss = criterion(pred, true)
                val_losses.append(loss.item())

        train_loss = float(np.mean(train_losses)) if train_losses else np.nan
        val_loss = float(np.mean(val_losses)) if val_losses else np.nan
        epoch_time = time.perf_counter() - epoch_start
        epoch_times.append(epoch_time)
        print(
            f"Epoch [{epoch}/{epochs}] Train Loss: {train_loss:.6f} | "
            f"Val Loss: {val_loss:.6f} | Epoch Time: {epoch_time:.2f}s ({epoch_time / 60:.2f} min)"
        )

        if val_loss < best_val:
            best_val = val_loss
            best_state = copy.deepcopy(model.state_dict())
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                print(f"Early stopping at epoch {epoch}")
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    if epoch_times:
        total_time = float(sum(epoch_times))
        avg_time = total_time / len(epoch_times)
        print(
            f"Training Time Summary | Total: {total_time:.2f}s ({total_time / 60:.2f} min) | "
            f"Epochs Run: {len(epoch_times)} | Avg/Epoch: {avg_time:.2f}s ({avg_time / 60:.2f} min)"
        )
    return model


def load_matching_state_dict(target_model: nn.Module, source_state: Dict[str, torch.Tensor]) -> Tuple[int, int]:
    target_state = target_model.state_dict()
    matched = {
        k: v
        for k, v in source_state.items()
        if k in target_state and target_state[k].shape == v.shape
    }
    target_state.update(matched)
    target_model.load_state_dict(target_state)
    return len(matched), len(target_state)


def set_trainable_by_name(model: nn.Module, trainable_prefixes: Tuple[str, ...]) -> None:
    for name, param in model.named_parameters():
        param.requires_grad = any(name.startswith(prefix) for prefix in trainable_prefixes)


def set_all_trainable(model: nn.Module) -> None:
    for param in model.parameters():
        param.requires_grad = True


def train_freeze_tune_patchtst_extreme_conv_asym_v2(
    cfg: Config,
    train_loader: DataLoader,
    val_loader: DataLoader,
    train_targets_selected: np.ndarray,
    train_current_targets: np.ndarray,
    train_targets_full: np.ndarray,
    epochs: int,
    lr: float,
    patience: int,
    device: str,
) -> nn.Module:
    source_epochs = max(1, int(round(epochs * FREEZE_TUNE_SOURCE_RATIO)))
    stage1_epochs = max(1, int(round(epochs * FREEZE_TUNE_STAGE1_RATIO)))
    stage2_epochs = max(1, epochs - source_epochs - stage1_epochs)

    source_patience = max(3, min(patience, int(round(patience * 0.7))))
    stage1_patience = max(3, min(patience, int(round(patience * 0.5))))
    stage2_patience = max(3, patience)
    stage2_lr = lr * FREEZE_TUNE_STAGE2_LR_SCALE

    print(
        "FREEZE_TUNE_INFO: "
        f"source=PatchTSTExtreme({source_epochs} epochs, lr={lr}), "
        f"stage1=frozen-conv({stage1_epochs} epochs, lr={lr}), "
        f"stage2=joint-finetune({stage2_epochs} epochs, lr={stage2_lr})"
    )

    source_model_name = "PatchTSTExtreme"
    source_model = build_model(source_model_name, cfg).to(device)
    source_criterion = build_training_criterion(
        source_model_name,
        train_targets_selected,
        train_current_targets,
        train_targets_full,
    )
    source_model = train_model(
        source_model,
        train_loader,
        val_loader,
        cfg,
        source_model_name,
        source_criterion,
        source_epochs,
        lr,
        source_patience,
        device,
    )

    target_model_name = "PatchTSTExtremeConvAsymmetricV2"
    target_model = build_model(target_model_name, cfg).to(device)
    matched, total = load_matching_state_dict(target_model, source_model.state_dict())
    print(f"FREEZE_TUNE_INFO: transferred {matched}/{total} parameter tensors from PatchTSTExtreme")

    target_criterion = build_training_criterion(
        target_model_name,
        train_targets_selected,
        train_current_targets,
        train_targets_full,
    )

    set_trainable_by_name(
        target_model,
        trainable_prefixes=("local_stem", "base_head", "horizon_head", "horizon_gate"),
    )
    target_model = train_model(
        target_model,
        train_loader,
        val_loader,
        cfg,
        target_model_name,
        target_criterion,
        stage1_epochs,
        lr,
        stage1_patience,
        device,
    )

    set_all_trainable(target_model)
    target_model = train_model(
        target_model,
        train_loader,
        val_loader,
        cfg,
        target_model_name,
        target_criterion,
        stage2_epochs,
        stage2_lr,
        stage2_patience,
        device,
    )
    return target_model

def predict_in_batches(
    model: nn.Module,
    X_np: np.ndarray,
    Y_np: np.ndarray,
    X_mark_np: np.ndarray,
    Y_mark_np: np.ndarray,
    cfg: Config,
    model_name: str,
    batch_size: int,
    device: str,
) -> np.ndarray:
    model.eval()
    preds = []
    amp_enabled = amp_enabled_for_model(model_name, device)
    with torch.no_grad():
        for start in range(0, len(X_np), batch_size):
            end = start + batch_size
            xb = torch.tensor(X_np[start:end], dtype=torch.float32, device=device)
            yb = torch.tensor(Y_np[start:end], dtype=torch.float32, device=device)
            xb_mark = torch.tensor(X_mark_np[start:end], dtype=torch.float32, device=device)
            yb_mark = torch.tensor(Y_mark_np[start:end], dtype=torch.float32, device=device)

            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled):
                pred, _ = forward_official(model, xb, yb, xb_mark, yb_mark, cfg)
            forecast = extract_forecast_tensor(pred)
            preds.append(forecast.detach().cpu().numpy().squeeze(-1))

    return np.concatenate(preds, axis=0)


# =========================
# 4. Main
# =========================
def main() -> None:
    global MODEL_NAME, RANDOM_STATE, ENGINEERING_LOW_THRESHOLDS, ENGINEERING_HIGH_THRESHOLDS
    global ABLATE_NO_CONV, ABLATE_NO_ASYM, ABLATE_NO_DENSITY, ABLATE_NO_TRANSITION
    args = parse_args()
    MODEL_NAME = args.model_name
    RANDOM_STATE = args.random_state
    ABLATE_NO_CONV = bool(args.ablate_no_conv)
    ABLATE_NO_ASYM = bool(args.ablate_no_asym)
    ABLATE_NO_DENSITY = bool(args.ablate_no_density)
    ABLATE_NO_TRANSITION = bool(args.ablate_no_transition)
    output_tag = args.output_tag.strip()
    if args.engineering_low_thresholds.strip():
        ENGINEERING_LOW_THRESHOLDS = parse_threshold_arg(args.engineering_low_thresholds)
    if args.engineering_high_thresholds.strip():
        ENGINEERING_HIGH_THRESHOLDS = parse_threshold_arg(args.engineering_high_thresholds)

    print("=" * 80)
    print("Official TSLib model comparison with user's chronological split")
    print("=" * 80)
    print(f"MODEL_NAME: {MODEL_NAME}")
    print(f"DEVICE: {DEVICE}")
    print(f"TSLIB_ROOT: {TSLIB_ROOT}")
    print(f"INPUT_FILE: {INPUT_FILE}")
    print(f"TARGET_COL: {TARGET_COL}")
    print(f"HORIZON_MINS: {HORIZON_MINS}")
    print(f"SEQ_LEN: {SEQ_LEN}")
    print(f"LABEL_LEN: {LABEL_LEN}")
    print(f"PRED_LEN: {PRED_LEN}")
    print(f"PATCH_LEN: {PATCH_LEN}")
    print(f"BATCH_SIZE: {BATCH_SIZE}")
    print(f"NUM_WORKERS: {NUM_WORKERS}")
    print(f"PIN_MEMORY: {PIN_MEMORY}")
    print(f"USE_AMP: {USE_AMP}")
    print(f"EFFECTIVE_AMP: {amp_enabled_for_model(MODEL_NAME, DEVICE)}")
    print(f"RANDOM_STATE: {RANDOM_STATE}")
    print(f"OUTPUT_TAG: {output_tag or '(none)'}")
    print(
        "ABLATION_SWITCHES: "
        f"no_conv={ABLATE_NO_CONV}, "
        f"no_asym={ABLATE_NO_ASYM}, "
        f"no_density={ABLATE_NO_DENSITY}, "
        f"no_transition={ABLATE_NO_TRANSITION}"
    )
    print(f"ENGINEERING_LOW_THRESHOLDS: {ENGINEERING_LOW_THRESHOLDS}")
    print(f"ENGINEERING_HIGH_THRESHOLDS: {ENGINEERING_HIGH_THRESHOLDS}")

    set_seed(RANDOM_STATE)

    df = pd.read_csv(INPUT_FILE)
    df[TIME_COL] = pd.to_datetime(df[TIME_COL], errors="coerce")
    df = df.dropna(subset=[TIME_COL]).sort_values(TIME_COL).reset_index(drop=True)

    feature_cols = safe_cols(df, BASE_FEATURE_COLS)
    if not feature_cols:
        raise ValueError("No valid feature columns found.")
    if feature_cols[-1] != TARGET_COL:
        raise ValueError("TARGET_COL must be the last feature in BASE_FEATURE_COLS.")

    X_seq, Y_seq, X_mark, Y_mark, y_true_seq, t_seq = build_official_seq_dataset(
        df_in=df,
        feature_cols=feature_cols,
        seq_len=SEQ_LEN,
        label_len=LABEL_LEN,
        pred_len=PRED_LEN,
        freq="t",
    )

    n = len(X_seq)
    split_idx = int(n * TRAIN_RATIO)

    X_train, X_test = X_seq[:split_idx], X_seq[split_idx:]
    Y_train, Y_test = Y_seq[:split_idx], Y_seq[split_idx:]
    X_mark_train, X_mark_test = X_mark[:split_idx], X_mark[split_idx:]
    Y_mark_train, Y_mark_test = Y_mark[:split_idx], Y_mark[split_idx:]
    y_true_train, y_true_test = y_true_seq[:split_idx], y_true_seq[split_idx:]
    t_test = t_seq[split_idx:]

    n_features = X_train.shape[2]
    x_scaler = MinMaxScaler()
    x_scaler.fit(X_train.reshape(-1, n_features))

    X_train_scaled = x_scaler.transform(X_train.reshape(-1, n_features)).reshape(X_train.shape).astype(np.float32)
    X_test_scaled = x_scaler.transform(X_test.reshape(-1, n_features)).reshape(X_test.shape).astype(np.float32)
    Y_train_scaled = x_scaler.transform(Y_train.reshape(-1, n_features)).reshape(Y_train.shape).astype(np.float32)
    Y_test_scaled = x_scaler.transform(Y_test.reshape(-1, n_features)).reshape(Y_test.shape).astype(np.float32)

    target_idx = feature_cols.index(TARGET_COL)
    selected_horizon_indices = [h - 1 for h in HORIZON_MINS]

    y_true_train_selected = y_true_train[:, selected_horizon_indices]
    y_true_test_selected = y_true_test[:, selected_horizon_indices]
    y_pred_persistence_selected = np.repeat(
        X_test[:, -1, target_idx][:, None],
        len(HORIZON_MINS),
        axis=1,
    )
    train_low_thresholds = np.quantile(y_true_train_selected, EXTREME_TAIL_QUANTILE, axis=0)
    train_high_thresholds = np.quantile(y_true_train_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0)
    test_low_thresholds = np.quantile(y_true_test_selected, EXTREME_TAIL_QUANTILE, axis=0)
    test_high_thresholds = np.quantile(y_true_test_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0)

    split_val = int(len(X_train_scaled) * 0.9)
    X_tr, X_val = X_train_scaled[:split_val], X_train_scaled[split_val:]
    Y_tr, Y_val = Y_train_scaled[:split_val], Y_train_scaled[split_val:]
    X_mark_tr, X_mark_val = X_mark_train[:split_val], X_mark_train[split_val:]
    Y_mark_tr, Y_mark_val = Y_mark_train[:split_val], Y_mark_train[split_val:]

    train_ds = TensorDataset(
        torch.tensor(X_tr, dtype=torch.float32),
        torch.tensor(Y_tr, dtype=torch.float32),
        torch.tensor(X_mark_tr, dtype=torch.float32),
        torch.tensor(Y_mark_tr, dtype=torch.float32),
    )
    val_ds = TensorDataset(
        torch.tensor(X_val, dtype=torch.float32),
        torch.tensor(Y_val, dtype=torch.float32),
        torch.tensor(X_mark_val, dtype=torch.float32),
        torch.tensor(Y_mark_val, dtype=torch.float32),
    )

    loader_kwargs = {
        "batch_size": BATCH_SIZE,
        "shuffle": False,
        "num_workers": NUM_WORKERS,
        "pin_memory": PIN_MEMORY,
    }
    if NUM_WORKERS > 0:
        loader_kwargs["persistent_workers"] = True

    train_loader = DataLoader(train_ds, **loader_kwargs)
    val_loader = DataLoader(val_ds, **loader_kwargs)

    cfg = Config(
        enc_in=len(feature_cols),
        dec_in=len(feature_cols),
        c_out=len(feature_cols),
    )
    if MODEL_NAME.lower() == "patchtstextremeconvasymmetricv2freezetune":
        model = train_freeze_tune_patchtst_extreme_conv_asym_v2(
            cfg=cfg,
            train_loader=train_loader,
            val_loader=val_loader,
            train_targets_selected=y_true_train_selected,
            train_current_targets=X_train[:, -1, target_idx],
            train_targets_full=y_true_train,
            epochs=EPOCHS,
            lr=LR,
            patience=PATIENCE,
            device=DEVICE,
        )
    else:
        model = build_model(MODEL_NAME, cfg)
        model = model.to(DEVICE)
        criterion = build_training_criterion(
            MODEL_NAME,
            y_true_train_selected,
            X_train[:, -1, target_idx],
            y_true_train,
        )
        model = train_model(model, train_loader, val_loader, cfg, MODEL_NAME, criterion, EPOCHS, LR, PATIENCE, DEVICE)

    y_pred_test_scaled = predict_in_batches(
        model=model,
        X_np=X_test_scaled,
        Y_np=Y_test_scaled,
        X_mark_np=X_mark_test,
        Y_mark_np=Y_mark_test,
        cfg=cfg,
        model_name=MODEL_NAME,
        batch_size=256,
        device=DEVICE,
    )
    y_pred_test_scaled_full = np.asarray(y_pred_test_scaled, dtype=np.float32)
    y_pred_test_full = inverse_target_scale(
        y_pred_test_scaled_full.reshape(-1),
        x_scaler,
        target_idx,
    ).reshape(-1, PRED_LEN)
    y_pred_test_selected = y_pred_test_full[:, selected_horizon_indices]

    summary_rows = []
    diagnostic_rows = []
    for idx, horizon in enumerate(HORIZON_MINS):
        p_mae, p_rmse, p_r2 = evaluate_regression(
            y_true_test_selected[:, idx],
            y_pred_persistence_selected[:, idx],
        )
        m_mae, m_rmse, m_r2 = evaluate_regression(
            y_true_test_selected[:, idx],
            y_pred_test_selected[:, idx],
        )
        summary_rows.append(
            {
                "horizon_min": horizon,
                "model_type": "persistence",
                "mae": p_mae,
                "rmse": p_rmse,
                "r2": p_r2,
            }
        )
        summary_rows.append(
            {
                "horizon_min": horizon,
                "model_type": MODEL_NAME,
                "mae": m_mae,
                "rmse": m_rmse,
                "r2": m_r2,
            }
        )

        train_threshold_metrics = compute_horizon_diagnostics(
            y_true=y_true_test_selected[:, idx],
            y_pred=y_pred_test_selected[:, idx],
            persistence_pred=y_pred_persistence_selected[:, idx],
            baseline_now=X_test[:, -1, target_idx],
            low_threshold=float(train_low_thresholds[idx]),
            high_threshold=float(train_high_thresholds[idx]),
        )
        test_relative_metrics = compute_horizon_diagnostics(
            y_true=y_true_test_selected[:, idx],
            y_pred=y_pred_test_selected[:, idx],
            persistence_pred=y_pred_persistence_selected[:, idx],
            baseline_now=X_test[:, -1, target_idx],
            low_threshold=float(test_low_thresholds[idx]),
            high_threshold=float(test_high_thresholds[idx]),
        )
        eng_low_threshold = get_engineering_threshold(horizon, ENGINEERING_LOW_THRESHOLDS)
        eng_high_threshold = get_engineering_threshold(horizon, ENGINEERING_HIGH_THRESHOLDS)
        if not np.isnan(eng_low_threshold) and not np.isnan(eng_high_threshold):
            engineering_metrics = compute_horizon_diagnostics(
                y_true=y_true_test_selected[:, idx],
                y_pred=y_pred_test_selected[:, idx],
                persistence_pred=y_pred_persistence_selected[:, idx],
                baseline_now=X_test[:, -1, target_idx],
                low_threshold=eng_low_threshold,
                high_threshold=eng_high_threshold,
            )
        else:
            engineering_metrics = empty_horizon_diagnostics()
        diagnostic_rows.append(
            {
                "horizon_min": horizon,
                "model_type": MODEL_NAME,
                "train_low_threshold": float(train_low_thresholds[idx]),
                "train_high_threshold": float(train_high_thresholds[idx]),
                "test_low_threshold": float(test_low_thresholds[idx]),
                "test_high_threshold": float(test_high_thresholds[idx]),
                "eng_low_threshold": eng_low_threshold,
                "eng_high_threshold": eng_high_threshold,
                **prefix_metric_keys(train_threshold_metrics, "trainthr"),
                **prefix_metric_keys(test_relative_metrics, "testrel"),
                **prefix_metric_keys(engineering_metrics, "eng"),
            }
        )

    summary_df = pd.DataFrame(summary_rows)
    diagnostic_df = pd.DataFrame(diagnostic_rows)
    method_table_df, _ = build_factory_method_table(df)
    eval_context_df = pd.DataFrame({TIME_COL: pd.to_datetime(t_test)}).merge(
        df[
            [
                col
                for col in [
                    TIME_COL,
                    "In_Water",
                    "In_COD",
                    "In_AN",
                    "N_On_DO",
                    "S_On_DO",
                    "S_On_AN",
                    "Out_AN",
                    "Out_TN",
                    "Out_COD",
                    "Out_PH",
                    TARGET_COL,
                ]
                if col in df.columns
            ]
        ].drop_duplicates(subset=[TIME_COL]),
        on=TIME_COL,
        how="left",
    )
    scene_diagnostic_df = build_factory_scene_diagnostics(
        eval_context_df=eval_context_df,
        y_true_selected=y_true_test_selected,
        y_pred_selected=y_pred_test_selected,
        y_pred_persistence_selected=y_pred_persistence_selected,
        baseline_now=X_test[:, -1, target_idx],
        model_name=MODEL_NAME,
    )

    pred_dict = {TIME_COL: pd.to_datetime(t_test)}
    for idx, horizon in enumerate(HORIZON_MINS):
        pred_dict[f"y_true_t{horizon}"] = y_true_test_selected[:, idx]
        pred_dict[f"y_pred_persistence_t{horizon}"] = y_pred_persistence_selected[:, idx]
        pred_dict[f"y_pred_{MODEL_NAME}_scaled_t{horizon}"] = y_pred_test_scaled_full[:, selected_horizon_indices[idx]]
        pred_dict[f"y_pred_{MODEL_NAME}_t{horizon}"] = y_pred_test_selected[:, idx]

    pred_df = pd.DataFrame(pred_dict)

    horizon_tag = "_".join(str(h) for h in HORIZON_MINS)
    file_suffix = f"{MODEL_NAME}_seed{RANDOM_STATE}_h{horizon_tag}"
    if output_tag:
        file_suffix = f"{file_suffix}_{output_tag}"
    summary_path = os.path.join(OUTPUT_DIR, f"summary_{file_suffix}.csv")
    diagnostic_path = os.path.join(OUTPUT_DIR, f"diagnostics_{file_suffix}.csv")
    scene_diagnostic_path = os.path.join(OUTPUT_DIR, f"scene_diagnostics_{file_suffix}.csv")
    method_table_path = os.path.join(OUTPUT_DIR, f"scene_method_table_{file_suffix}.csv")
    pred_path = os.path.join(OUTPUT_DIR, f"predictions_{file_suffix}.csv")
    summary_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
    diagnostic_df.to_csv(diagnostic_path, index=False, encoding="utf-8-sig")
    scene_diagnostic_df.to_csv(scene_diagnostic_path, index=False, encoding="utf-8-sig")
    method_table_df.to_csv(method_table_path, index=False, encoding="utf-8-sig")
    pred_df.to_csv(pred_path, index=False, encoding="utf-8-sig")

    print("\n" + "=" * 80)
    print("Results")
    print("=" * 80)
    print(summary_df.to_string(index=False))
    scene_preview_cols = [
        "horizon_min",
        "scenario_cn",
        "n_samples",
        "sample_ratio_pct",
        "rmse",
        "persistence_rmse",
        "rmse_gain_pct_vs_persistence",
        "rmse_delta_top10",
        "persistence_rmse_delta_top10",
        "delta_top10_gain_pct_vs_persistence",
    ]
    print("\nScene Diagnostics")
    print("=" * 80)
    print(scene_diagnostic_df[scene_preview_cols].to_string(index=False))
    print("\nDiagnostics")
    print("=" * 80)
    print(diagnostic_df.to_string(index=False))
    print(f"\nSaved summary to: {summary_path}")
    print(f"Saved diagnostics to: {diagnostic_path}")
    print(f"Saved scene diagnostics to: {scene_diagnostic_path}")
    print(f"Saved scene method table to: {method_table_path}")
    print(f"Saved predictions to: {pred_path}")


if __name__ == "__main__":
    main()
