"""Model definitions are implemented in the experiment entrypoint scripts.

The release keeps the original training scripts intact for reproducibility:

- `src/train_ssa_conv_patchtst.py`
- `src/train_baselines.py`
- `src/train_external_validation.py`
"""

