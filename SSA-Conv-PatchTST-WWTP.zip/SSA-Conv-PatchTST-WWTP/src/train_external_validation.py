# -*- coding: utf-8 -*-
"""
Official TSLib model comparison script.

This script keeps the user's chronological split / scaling / export workflow,
but replaces all custom "official-style" approximations with the real official
model classes from TSLib.

Supported backbones / hybrids:
- TimeXer
- iTransformer
- PatchTST
- PatchTSTKAN
- TCN
- NBEATSx
- DeepARLike
- Crossformer
- Autoformer
- TimesNet
- SCINet
- DLinear
- TiDE
"""

import copy
import argparse
import importlib
import importlib.util
import math
import os
import random
import sys
import time
import types
import warnings
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import DataLoader, TensorDataset


# =========================
# 1. Paths and basic settings
# =========================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(SCRIPT_DIR)
INPUT_FILE = os.environ.get(
    "EXTERNAL_DATA_FILE",
    os.path.join(REPO_ROOT, "data", "external", "train_dataset.csv"),
)
OUTPUT_ROOT = os.environ.get(
    "WWTP_EXTERNAL_OUTPUT_DIR",
    os.path.join(REPO_ROOT, "results", "generated", "external_validation"),
)
OUTPUT_DIR = OUTPUT_ROOT
TSLIB_ROOT = os.environ.get(
    "TSLIB_OFFICIAL_ROOT",
    r"C:\Users\71863\Documents\Playground\TSLib_official",
)
os.makedirs(OUTPUT_ROOT, exist_ok=True)

if not os.path.isdir(TSLIB_ROOT):
    raise FileNotFoundError(
        f"TSLIB_OFFICIAL_ROOT not found: {TSLIB_ROOT}\n"
        "Set environment variable TSLIB_OFFICIAL_ROOT to your official TSLib path."
    )

if TSLIB_ROOT not in sys.path:
    sys.path.insert(0, TSLIB_ROOT)


def ensure_tslib_optional_dependencies() -> None:
    try:
        importlib.import_module("einops")
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError(
            "Missing required dependency 'einops'. Install it in the same Python environment with:\n"
            r"D:\pc\pythonProject\.venv\Scripts\python.exe -m pip install einops"
        ) from exc

    if "reformer_pytorch" in sys.modules:
        return

    try:
        importlib.import_module("reformer_pytorch")
        return
    except ModuleNotFoundError:
        pass

    stub_module = types.ModuleType("reformer_pytorch")

    class LSHSelfAttention(nn.Module):
        def __init__(self, *args, **kwargs):
            super().__init__()

        def forward(self, x, **kwargs):
            return x

    stub_module.LSHSelfAttention = LSHSelfAttention
    sys.modules["reformer_pytorch"] = stub_module


ensure_tslib_optional_dependencies()


TIME_COL = "time"
TARGET_COL = "Label1"
SAMPLE_INTERVAL_MIN = 2
HORIZON_MINS = [30, 60, 90]
HORIZON_STEPS = [h // SAMPLE_INTERVAL_MIN for h in HORIZON_MINS]
TRAIN_RATIO = 0.8
RANDOM_STATE = 7

SEQ_LEN = 180
LABEL_LEN = 60
PRED_LEN = max(HORIZON_STEPS)
PATCH_LEN = 10

BATCH_SIZE = 64
EPOCHS = 100
PATIENCE = 10
LR = 1e-4
WEIGHT_DECAY = 1e-5
NUM_WORKERS = 0
PIN_MEMORY = torch.cuda.is_available()
USE_AMP = torch.cuda.is_available()

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

if torch.cuda.is_available():
    torch.backends.cudnn.benchmark = True

MODEL_NAME = "PatchTST"
# "TimeXer"
# "iTransformer"
# "PatchTST"
# "PatchTSTKAN"
# "PatchTSTHead"
# "PatchTSTHeadTail"
# "PatchTSTHeadHorizon"
# "PatchTSTExtreme"
# "PatchTSTExtremeAdaptive"
# "PatchTSTExtremeEvent"
# "PatchTSTExtremeRefine"
# "TCN"
# "NBEATSx"
# "DeepARLike"
# "Crossformer"
# "Autoformer"
# "TimesNet"
# "SCINet"
# "DLinear"
# "TiDE"

SSA_CONV_PATCHTST_MODEL_NAME = "SSA-Conv-PatchTST"
SUPPORTED_DECOMP_METHODS = ("none", "ssa")
SSA_FRAMEWORK_MODULE_NAME = "timexer_allmodeals_vmd_framework"
SSA_FRAMEWORK_FILE = os.path.join(SCRIPT_DIR, "train_ssa_conv_patchtst.py")
OUTPUT_NAME_TAG = "label1"

COMMON_FEATURE_COLS = [
    "JS_NH3",
    "CS_NH3",
    "JS_TN",
    "CS_TN",
    "JS_LL",
    "CS_LL",
    "MCCS_NH4",
    "MCCS_NO3",
    "JS_COD",
    "CS_COD",
    "JS_SW",
    "CS_SW",
]

NORTH_FEATURE_COLS = [
    "B_HYC_NH4",
    "B_HYC_XD",
    "B_HYC_MLSS",
    "B_HYC_JS_DO",
    "B_HYC_DO",
    "B_CS_MQ_SSLL",
    "B_QY_ORP",
]

SOUTH_FEATURE_COLS = [
    "N_HYC_NH4",
    "N_HYC_XD",
    "N_HYC_MLSS",
    "N_HYC_JS_DO",
    "N_HYC_DO",
    "N_CS_MQ_SSLL",
    "N_QY_ORP",
]

# SSA source mapping aligned with the original Main_AirV decomposition group:
# In_Water, In_COD, In_AN, N_On_DO, S_On_DO, Out_AN, Out_TN, Main_AirV.
SSA_SOURCE_FEATURES_BY_TARGET: Dict[str, List[str]] = {
    "Label1": [
        "JS_LL",
        "JS_COD",
        "JS_NH3",
        "B_HYC_JS_DO",
        "B_HYC_DO",
        "CS_NH3",
        "CS_TN",
        "CS_COD",
        "Label1",
    ],
    "Label2": [
        "JS_LL",
        "JS_COD",
        "JS_NH3",
        "N_HYC_JS_DO",
        "N_HYC_DO",
        "CS_NH3",
        "CS_TN",
        "CS_COD",
        "Label2",
    ],
}

FEATURE_COLS_BY_TARGET: Dict[str, List[str]] = {
    "Label1": COMMON_FEATURE_COLS + NORTH_FEATURE_COLS + [
        "Label1",  # target MUST be last
    ],
    "Label2": COMMON_FEATURE_COLS + SOUTH_FEATURE_COLS + [
        "Label2",  # target MUST be last
    ],
}

OUTPUT_TAG_BY_TARGET: Dict[str, str] = {
    "Label1": "label1",
    "Label2": "label2",
}

SSA_SOURCE_FEATURE_COLS = list(SSA_SOURCE_FEATURES_BY_TARGET[TARGET_COL])

BASE_FEATURE_COLS = [
    *COMMON_FEATURE_COLS,
    *NORTH_FEATURE_COLS,
    "Label1",  # target MUST be last
]

MODEL_MODULES: Dict[str, str] = {
    "timexer": "TimeXer",
    "itransformer": "iTransformer",
    "patchtst": "PatchTST",
    "patchtstkan": "custom",
    "patchtsthead": "PatchTST",
    "patchtstheadtail": "PatchTST",
    "patchtstheadhorizon": "PatchTST",
    "patchtstextreme": "PatchTST",
    "patchtstextremeadaptive": "PatchTST",
    "patchtstextremeevent": "PatchTST",
    "patchtstextremerefine": "PatchTST",
    "tcn": "custom",
    "nbeatsx": "custom",
    "deeparlike": "custom",
    "lstm": "custom",
    "gru": "custom",
    "crossformer": "Crossformer",
    "autoformer": "Autoformer",
    "timesnet": "TimesNet",
    "scinet": "SCINet",
    "dlinear": "DLinear",
    "tide": "TiDE",
}

AMP_UNSAFE_MODELS = {"timesnet"}
EXTREME_TAIL_QUANTILE = 0.05
EXTREME_HORIZON_WEIGHTS = [1.75, 2.00, 2.25]
EXTREME_LOW_WEIGHTS = [1.15, 1.25, 1.35]
EXTREME_HIGH_WEIGHTS = [0.85, 0.75, 0.65]
DENSITY_NUM_BINS = 64
DENSITY_SMOOTH_SIGMA = 1.5
DENSITY_WEIGHT_BLEND = 0.35
DENSITY_WEIGHT_POWER = 0.5
ADAPTIVE_EXTREME_STRENGTH = 0.80
ADAPTIVE_DIRECTION_STRENGTH = 1.10
ADAPTIVE_DIRECTION_ERROR_POWER = 1.00
ADAPTIVE_HIGH_TAIL_SCALE = 0.90
ADAPTIVE_LOW_TAIL_SCALE = 1.00
ADAPTIVE_MAX_POINT_WEIGHT = 12.0
TRANSITION_TOP_QUANTILE = 0.90
EVENT_DELTA_LOSS_WEIGHT = 0.25
EVENT_BCE_LOSS_WEIGHT = 0.10
EVENT_TRANSITION_WEIGHT = 1.5
EVENT_TAIL_WEIGHT = 0.75
REFINE_BRANCH_HIDDEN = 128
REFINE_DELTA_LOSS_WEIGHT = 0.40
REFINE_EVENT_LOSS_WEIGHT = 0.08
REFINE_TRANSITION_WEIGHT = 1.75
ENGINEERING_LOW_THRESHOLDS = {30: None, 60: None, 90: None}
ENGINEERING_HIGH_THRESHOLDS = {30: None, 60: None, 90: None}

UNIFORM_HORIZON_WEIGHT = float(np.mean(EXTREME_HORIZON_WEIGHTS))
UNIFORM_LOW_WEIGHT = float(np.mean(EXTREME_LOW_WEIGHTS))
UNIFORM_HIGH_WEIGHT = float(np.mean(EXTREME_HIGH_WEIGHTS))


# =========================
# 2. Hyperparameters
# =========================
@dataclass
class Config:
    task_name: str = "long_term_forecast"
    seq_len: int = SEQ_LEN
    label_len: int = LABEL_LEN
    pred_len: int = PRED_LEN
    patch_len: int = PATCH_LEN
    stride: int = PATCH_LEN

    d_model: int = 128
    d_ff: int = 128
    n_heads: int = 4
    e_layers: int = 2
    d_layers: int = 1
    dropout: float = 0.1
    activation: str = "gelu"
    factor: int = 3
    use_norm: bool = True

    enc_in: int = len(BASE_FEATURE_COLS)
    dec_in: int = len(BASE_FEATURE_COLS)
    c_out: int = len(BASE_FEATURE_COLS)
    features: str = "MS"
    embed: str = "timeF"
    freq: str = "t"

    moving_avg: int = 15
    top_k: int = 3
    num_kernels: int = 3
    num_class: int = 1
    individual: bool = False

    kan_hidden_dim: int = 64
    kan_grid_size: int = 8
    kan_spline_order: int = 3
    kan_input_dropout: float = 0.05
    kan_grid_min: float = -4.0
    kan_grid_max: float = 4.0

    tcn_hidden_dim: int = 128
    tcn_num_layers: int = 4
    tcn_dropout: float = 0.1

    nbeats_hidden_dim: int = 256
    nbeats_num_blocks: int = 4
    nbeats_num_layers: int = 4
    nbeats_context_dim: int = 128
    nbeats_dropout: float = 0.1

    deepar_hidden_dim: int = 128
    deepar_dropout: float = 0.1
    deepar_horizon_embed_dim: int = 32

class Transpose(nn.Module):
    def __init__(self, *dims, contiguous: bool = False):
        super().__init__()
        self.dims = dims
        self.contiguous = contiguous

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.contiguous:
            return x.transpose(*self.dims).contiguous()
        return x.transpose(*self.dims)


class FlattenHead(nn.Module):
    def __init__(self, n_vars: int, nf: int, target_window: int, head_dropout: float = 0.0):
        super().__init__()
        self.flatten = nn.Flatten(start_dim=-2)
        self.linear = nn.Linear(nf, target_window)
        self.dropout = nn.Dropout(head_dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.flatten(x)
        x = self.linear(x)
        return self.dropout(x)


class BSplineKANLinear(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        grid_size: int = 8,
        spline_order: int = 3,
        grid_range: Tuple[float, float] = (-4.0, 4.0),
    ):
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.grid_size = int(grid_size)
        self.spline_order = int(spline_order)
        self.base_activation = nn.SiLU()

        grid_min, grid_max = float(grid_range[0]), float(grid_range[1])
        grid_step = (grid_max - grid_min) / float(self.grid_size)
        base_grid = (
            torch.arange(-self.spline_order, self.grid_size + self.spline_order + 1, dtype=torch.float32)
            * grid_step
            + grid_min
        )
        self.register_buffer("grid", base_grid.unsqueeze(0).repeat(self.in_features, 1))

        self.base_weight = nn.Parameter(torch.empty(self.out_features, self.in_features))
        self.spline_weight = nn.Parameter(
            torch.empty(self.out_features, self.in_features, self.grid_size + self.spline_order)
        )
        self.bias = nn.Parameter(torch.zeros(self.out_features))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.kaiming_uniform_(self.base_weight, a=math.sqrt(5))
        nn.init.trunc_normal_(self.spline_weight, mean=0.0, std=0.02)
        fan_in, _ = nn.init._calculate_fan_in_and_fan_out(self.base_weight)
        bound = 1 / math.sqrt(fan_in) if fan_in > 0 else 0
        nn.init.uniform_(self.bias, -bound, bound)

    def _b_splines(self, x: torch.Tensor) -> torch.Tensor:
        grid = self.grid.unsqueeze(0)
        x = x.unsqueeze(-1)
        bases = ((x >= grid[:, :, :-1]) & (x < grid[:, :, 1:])).to(x.dtype)

        for order in range(1, self.spline_order + 1):
            left_num = x - grid[:, :, : -(order + 1)]
            left_den = grid[:, :, order:-1] - grid[:, :, : -(order + 1)]
            right_num = grid[:, :, order + 1:] - x
            right_den = grid[:, :, order + 1:] - grid[:, :, 1:-order]

            left = left_num / left_den.clamp_min(1e-6)
            right = right_num / right_den.clamp_min(1e-6)
            bases = left * bases[:, :, :-1] + right * bases[:, :, 1:]

        return bases.contiguous()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        original_shape = x.shape[:-1]
        x = x.reshape(-1, self.in_features)
        x_min = self.grid[:, self.spline_order].min()
        x_max = self.grid[:, -(self.spline_order + 1)].max()
        x = x.clamp(min=float(x_min), max=float(x_max) - 1e-6)

        base_out = F.linear(self.base_activation(x), self.base_weight, self.bias)
        spline_basis = self._b_splines(x).reshape(x.shape[0], -1)
        spline_out = F.linear(spline_basis, self.spline_weight.reshape(self.out_features, -1))
        out = base_out + spline_out
        return out.reshape(*original_shape, self.out_features)


class KAN(nn.Module):
    def __init__(
        self,
        layer_sizes: List[int],
        grid_size: int = 8,
        spline_order: int = 3,
        grid_range: Tuple[float, float] = (-4.0, 4.0),
        dropout: float = 0.0,
    ):
        super().__init__()
        if len(layer_sizes) < 2:
            raise ValueError("KAN requires at least input and output dimensions.")

        self.layers = nn.ModuleList(
            [
                BSplineKANLinear(
                    in_features=layer_sizes[idx],
                    out_features=layer_sizes[idx + 1],
                    grid_size=grid_size,
                    spline_order=spline_order,
                    grid_range=grid_range,
                )
                for idx in range(len(layer_sizes) - 1)
            ]
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for idx, layer in enumerate(self.layers):
            x = layer(x)
            if idx < len(self.layers) - 1:
                x = self.dropout(x)
        return x


class TargetTokenHead(nn.Module):
    def __init__(self, nf: int, out_dim: int, dropout: float = 0.0):
        super().__init__()
        self.flatten = nn.Flatten(start_dim=-2)
        self.linear = nn.Linear(nf, out_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.flatten(x)
        x = self.linear(x)
        return self.dropout(x)


class PatchTSTKANModel(nn.Module):
    def __init__(
        self,
        configs: Config,
        patch_len: int,
        stride: int,
        target_feature_idx: int,
    ):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.target_feature_idx = int(target_feature_idx)
        padding = stride

        self.patch_embedding = PatchEmbedding(
            configs.d_model, patch_len, stride, padding, configs.dropout
        )
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=False,
                        ),
                        configs.d_model,
                        configs.n_heads,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.Sequential(
                Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
            ),
        )

        self.head_nf = configs.d_model * int((configs.seq_len - patch_len) / stride + 2)
        self.var_mix_logits = nn.Parameter(torch.zeros(configs.enc_in))
        kan_input_dim = self.head_nf * 2
        self.head_norm = nn.LayerNorm(kan_input_dim)
        self.head_dropout = nn.Dropout(configs.kan_input_dropout)
        self.e_kan = KAN(
            [kan_input_dim, configs.kan_hidden_dim, configs.pred_len],
            grid_size=configs.kan_grid_size,
            spline_order=configs.kan_spline_order,
            grid_range=(configs.kan_grid_min, configs.kan_grid_max),
            dropout=configs.dropout,
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc / stdev

        x_enc = x_enc.permute(0, 2, 1)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        target_tokens = enc_out[:, self.target_feature_idx, :, :]
        var_weights = torch.softmax(self.var_mix_logits, dim=0).to(enc_out.dtype)
        mixed_tokens = torch.einsum("v,bvdp->bdp", var_weights, enc_out)

        head_input = torch.cat([target_tokens.flatten(1), mixed_tokens.flatten(1)], dim=1)
        head_input = self.head_norm(head_input)
        head_input = self.head_dropout(head_input)

        dec_out = self.e_kan(head_input).unsqueeze(-1)
        dec_out = dec_out * stdev[:, 0, self.target_feature_idx].view(-1, 1, 1)
        dec_out = dec_out + means[:, 0, self.target_feature_idx].view(-1, 1, 1)
        return dec_out

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]
        raise NotImplementedError("PatchTSTKANModel only supports forecasting tasks")


class TemporalConvResBlock(nn.Module):
    def __init__(self, channels: int, dilation: int, dropout: float):
        super().__init__()
        padding = dilation
        self.conv1 = nn.Conv1d(channels, channels, kernel_size=3, padding=padding, dilation=dilation)
        self.conv2 = nn.Conv1d(channels, channels, kernel_size=3, padding=padding, dilation=dilation)
        self.norm1 = nn.BatchNorm1d(channels)
        self.norm2 = nn.BatchNorm1d(channels)
        self.dropout = nn.Dropout(dropout)
        self.act = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.act(x)
        x = self.dropout(x)
        x = self.conv2(x)
        x = self.norm2(x)
        x = self.dropout(x)
        return self.act(x + residual)


class DirectRNNForecaster(nn.Module):
    def __init__(
        self,
        input_dim: int,
        pred_len: int,
        hidden_dim: int = 128,
        dense_dim: int = 64,
        dropout: float = 0.1,
        cell_type: str = "lstm",
    ):
        super().__init__()
        rnn_cls = nn.LSTM if cell_type == "lstm" else nn.GRU
        self.pred_len = pred_len
        self.cell_type = cell_type
        self.rnn = rnn_cls(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=1,
            batch_first=True,
        )
        self.dropout = nn.Dropout(dropout)
        self.fc1 = nn.Linear(hidden_dim, dense_dim)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(dense_dim, pred_len)

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        out, _ = self.rnn(x_enc)
        out = out[:, -1, :]
        out = self.dropout(out)
        out = self.relu(self.fc1(out))
        pred_target = self.fc2(out).unsqueeze(-1)
        return pred_target


class TCNForecaster(nn.Module):
    def __init__(
        self,
        input_dim: int,
        pred_len: int,
        hidden_dim: int = 128,
        num_layers: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.pred_len = pred_len
        self.input_proj = nn.Conv1d(input_dim, hidden_dim, kernel_size=1)
        self.blocks = nn.ModuleList(
            [
                TemporalConvResBlock(
                    channels=hidden_dim,
                    dilation=2 ** layer_idx,
                    dropout=dropout,
                )
                for layer_idx in range(num_layers)
            ]
        )
        self.dropout = nn.Dropout(dropout)
        self.head = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, pred_len),
        )

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        x = x_enc.transpose(1, 2)
        x = self.input_proj(x)
        for block in self.blocks:
            x = block(x)
        pooled = torch.cat([x[:, :, -1], x.mean(dim=-1)], dim=1)
        pred_target = self.head(self.dropout(pooled)).unsqueeze(-1)
        return pred_target


class NBeatsXBlock(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        num_layers: int,
        seq_len: int,
        pred_len: int,
        dropout: float,
    ):
        super().__init__()
        layers: List[nn.Module] = []
        in_dim = input_dim
        for _ in range(num_layers):
            layers.append(nn.Linear(in_dim, hidden_dim))
            layers.append(nn.GELU())
            layers.append(nn.Dropout(dropout))
            in_dim = hidden_dim
        self.mlp = nn.Sequential(*layers)
        self.backcast = nn.Linear(hidden_dim, seq_len)
        self.forecast = nn.Linear(hidden_dim, pred_len)

    def forward(self, block_input: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        hidden = self.mlp(block_input)
        return self.backcast(hidden), self.forecast(hidden)


class NBeatsXForecaster(nn.Module):
    def __init__(
        self,
        input_dim: int,
        seq_len: int,
        pred_len: int,
        hidden_dim: int = 256,
        num_blocks: int = 4,
        num_layers: int = 4,
        context_dim: int = 128,
        dropout: float = 0.1,
        target_feature_idx: int = -1,
    ):
        super().__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.target_feature_idx = target_feature_idx
        self.context_encoder = nn.Sequential(
            nn.Linear(seq_len * input_dim, context_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(context_dim, context_dim),
            nn.GELU(),
        )
        block_input_dim = seq_len + context_dim
        self.blocks = nn.ModuleList(
            [
                NBeatsXBlock(
                    input_dim=block_input_dim,
                    hidden_dim=hidden_dim,
                    num_layers=num_layers,
                    seq_len=seq_len,
                    pred_len=pred_len,
                    dropout=dropout,
                )
                for _ in range(num_blocks)
            ]
        )

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        target_history = x_enc[:, :, self.target_feature_idx]
        residual = target_history
        context = self.context_encoder(x_enc.reshape(x_enc.size(0), -1))
        forecast = torch.zeros(
            x_enc.size(0),
            self.pred_len,
            device=x_enc.device,
            dtype=x_enc.dtype,
        )
        for block in self.blocks:
            block_input = torch.cat([residual, context], dim=1)
            backcast, block_forecast = block(block_input)
            residual = residual - backcast
            forecast = forecast + block_forecast
        return forecast.unsqueeze(-1)


class DeepARLikeForecaster(nn.Module):
    def __init__(
        self,
        input_dim: int,
        pred_len: int,
        hidden_dim: int = 128,
        dropout: float = 0.1,
        target_feature_idx: int = -1,
        horizon_embed_dim: int = 32,
    ):
        super().__init__()
        self.pred_len = pred_len
        self.target_feature_idx = target_feature_idx
        self.encoder = nn.GRU(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=1,
            batch_first=True,
        )
        self.horizon_embedding = nn.Embedding(pred_len, horizon_embed_dim)
        self.decoder = nn.GRUCell(1 + horizon_embed_dim, hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.delta_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        _, hidden = self.encoder(x_enc)
        hidden = hidden[-1]
        prev = x_enc[:, -1, self.target_feature_idx].unsqueeze(-1)
        preds = []
        step_ids = torch.arange(self.pred_len, device=x_enc.device)
        horizon_embeds = self.horizon_embedding(step_ids)
        for step in range(self.pred_len):
            step_embed = horizon_embeds[step].unsqueeze(0).expand(x_enc.size(0), -1)
            decoder_input = torch.cat([prev, step_embed], dim=1)
            hidden = self.decoder(decoder_input, hidden)
            delta = self.delta_head(self.dropout(hidden))
            prev = prev + delta
            preds.append(prev)
        return torch.stack(preds, dim=1)


class PatchTSTExtremeModel(nn.Module):
    def __init__(self, configs: Config, patch_len: int, stride: int, horizon_indices: List[int]):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.horizon_indices = horizon_indices
        padding = stride

        self.patch_embedding = PatchEmbedding(
            configs.d_model, patch_len, stride, padding, configs.dropout
        )
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=False,
                        ),
                        configs.d_model,
                        configs.n_heads,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.Sequential(
                Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
            ),
        )

        self.head_nf = configs.d_model * int((configs.seq_len - patch_len) / stride + 2)
        self.base_head = FlattenHead(
            configs.enc_in, self.head_nf, configs.pred_len, head_dropout=configs.dropout
        )
        self.horizon_head = FlattenHead(
            configs.enc_in,
            self.head_nf,
            len(horizon_indices),
            head_dropout=configs.dropout,
        )
        self.horizon_gate = nn.Parameter(torch.zeros(len(horizon_indices)))

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> torch.Tensor:
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev

        x_enc = x_enc.permute(0, 2, 1)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return dec_out

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]
        raise NotImplementedError("PatchTSTExtremeModel only supports forecasting tasks")


class PatchTSTExtremeEventModel(nn.Module):
    def __init__(
        self,
        configs: Config,
        patch_len: int,
        stride: int,
        horizon_indices: List[int],
        target_feature_idx: int,
    ):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.horizon_indices = horizon_indices
        self.target_feature_idx = int(target_feature_idx)
        padding = stride

        self.patch_embedding = PatchEmbedding(
            configs.d_model, patch_len, stride, padding, configs.dropout
        )
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=False,
                        ),
                        configs.d_model,
                        configs.n_heads,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.Sequential(
                Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
            ),
        )

        self.head_nf = configs.d_model * int((configs.seq_len - patch_len) / stride + 2)
        self.base_head = FlattenHead(
            configs.enc_in, self.head_nf, configs.pred_len, head_dropout=configs.dropout
        )
        self.horizon_head = FlattenHead(
            configs.enc_in,
            self.head_nf,
            len(horizon_indices),
            head_dropout=configs.dropout,
        )
        self.target_delta_head = TargetTokenHead(
            self.head_nf,
            len(horizon_indices),
            dropout=configs.dropout,
        )
        self.target_event_head = TargetTokenHead(
            self.head_nf,
            len(horizon_indices) * 3,
            dropout=configs.dropout,
        )
        self.horizon_gate = nn.Parameter(torch.zeros(len(horizon_indices)))
        self.transition_mix_gate = nn.Parameter(torch.full((len(horizon_indices),), -0.5))
        self.tail_mix_gate = nn.Parameter(torch.full((len(horizon_indices),), -1.0))

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        current_target = x_enc[:, -1, self.target_feature_idx]

        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc / stdev
        current_target_norm = x_enc[:, -1, self.target_feature_idx]

        x_enc = x_enc.permute(0, 2, 1)
        enc_out, n_vars = self.patch_embedding(x_enc)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        target_tokens = enc_out[:, self.target_feature_idx, :, :]
        delta_pred_norm = self.target_delta_head(target_tokens).to(dec_out.dtype)
        event_logits = self.target_event_head(target_tokens).view(-1, len(self.horizon_indices), 3).to(dec_out.dtype)
        event_probs = torch.sigmoid(event_logits)
        tail_prob = torch.maximum(event_probs[:, :, 0], event_probs[:, :, 1])
        transition_prob = event_probs[:, :, 2]

        mix = (
            torch.sigmoid(self.transition_mix_gate).view(1, -1) * transition_prob
            + torch.sigmoid(self.tail_mix_gate).view(1, -1) * tail_prob
        ).clamp(max=0.95)
        target_base_selected = dec_out[:, self.horizon_indices, self.target_feature_idx]
        delta_level_selected = current_target_norm.unsqueeze(1).to(dec_out.dtype) + delta_pred_norm.to(dec_out.dtype)
        refined_target = target_base_selected + mix.to(dec_out.dtype) * (delta_level_selected - target_base_selected)
        dec_out[:, self.horizon_indices, self.target_feature_idx] = refined_target

        target_stdev = stdev[:, 0, self.target_feature_idx].unsqueeze(1)
        delta_pred = delta_pred_norm * target_stdev
        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return {
            "forecast": dec_out,
            "delta_pred": delta_pred,
            "event_logits": event_logits,
            "event_probs": event_probs,
            "current_target": current_target,
        }

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> Dict[str, torch.Tensor]:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            dec_out["forecast"] = dec_out["forecast"][:, -self.pred_len:, :]
            return dec_out
        raise NotImplementedError("PatchTSTExtremeEventModel only supports forecasting tasks")


class PatchTSTExtremeRefineModel(nn.Module):
    def __init__(
        self,
        configs: Config,
        patch_len: int,
        stride: int,
        horizon_indices: List[int],
        target_feature_idx: int,
    ):
        super().__init__()
        PatchEmbedding = load_tslib_symbol("layers.Embed", "PatchEmbedding")
        AttentionLayer = load_tslib_symbol("layers.SelfAttention_Family", "AttentionLayer")
        FullAttention = load_tslib_symbol("layers.SelfAttention_Family", "FullAttention")
        Encoder = load_tslib_symbol("layers.Transformer_EncDec", "Encoder")
        EncoderLayer = load_tslib_symbol("layers.Transformer_EncDec", "EncoderLayer")

        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.horizon_indices = horizon_indices
        self.target_feature_idx = int(target_feature_idx)
        padding = stride

        self.patch_embedding = PatchEmbedding(
            configs.d_model, patch_len, stride, padding, configs.dropout
        )
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            False,
                            configs.factor,
                            attention_dropout=configs.dropout,
                            output_attention=False,
                        ),
                        configs.d_model,
                        configs.n_heads,
                    ),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation,
                )
                for _ in range(configs.e_layers)
            ],
            norm_layer=nn.Sequential(
                Transpose(1, 2), nn.BatchNorm1d(configs.d_model), Transpose(1, 2)
            ),
        )

        self.head_nf = configs.d_model * int((configs.seq_len - patch_len) / stride + 2)
        self.base_head = FlattenHead(
            configs.enc_in, self.head_nf, configs.pred_len, head_dropout=configs.dropout
        )
        self.horizon_head = FlattenHead(
            configs.enc_in,
            self.head_nf,
            len(horizon_indices),
            head_dropout=configs.dropout,
        )
        self.horizon_gate = nn.Parameter(torch.zeros(len(horizon_indices)))

        refine_in = configs.enc_in * 2
        self.refine_proj = nn.Conv1d(refine_in, REFINE_BRANCH_HIDDEN, kernel_size=3, padding=1)
        self.refine_blocks = nn.ModuleList(
            [
                TemporalConvResBlock(REFINE_BRANCH_HIDDEN, dilation=1, dropout=configs.dropout),
                TemporalConvResBlock(REFINE_BRANCH_HIDDEN, dilation=2, dropout=configs.dropout),
                TemporalConvResBlock(REFINE_BRANCH_HIDDEN, dilation=4, dropout=configs.dropout),
                TemporalConvResBlock(REFINE_BRANCH_HIDDEN, dilation=8, dropout=configs.dropout),
            ]
        )
        rep_dim = REFINE_BRANCH_HIDDEN * 3
        self.refine_delta_head = nn.Sequential(
            nn.Linear(rep_dim, REFINE_BRANCH_HIDDEN),
            nn.GELU(),
            nn.Dropout(configs.dropout),
            nn.Linear(REFINE_BRANCH_HIDDEN, configs.pred_len),
        )
        self.refine_gate_head = nn.Sequential(
            nn.Linear(rep_dim, REFINE_BRANCH_HIDDEN // 2),
            nn.GELU(),
            nn.Dropout(configs.dropout),
            nn.Linear(REFINE_BRANCH_HIDDEN // 2, len(horizon_indices)),
        )
        self.event_head = nn.Sequential(
            nn.Linear(rep_dim, REFINE_BRANCH_HIDDEN // 2),
            nn.GELU(),
            nn.Dropout(configs.dropout),
            nn.Linear(REFINE_BRANCH_HIDDEN // 2, len(horizon_indices) * 3),
        )

    def forecast(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        current_target = x_enc[:, -1, self.target_feature_idx]

        means = x_enc.mean(1, keepdim=True).detach()
        x_norm = x_enc - means
        stdev = torch.sqrt(torch.var(x_norm, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_norm = x_norm / stdev
        current_target_norm = x_norm[:, -1, self.target_feature_idx]

        patch_in = x_norm.permute(0, 2, 1)
        enc_out, n_vars = self.patch_embedding(patch_in)
        enc_out, _ = self.encoder(enc_out)
        enc_out = torch.reshape(enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1]))
        enc_out = enc_out.permute(0, 1, 3, 2)

        dec_out = self.base_head(enc_out).permute(0, 2, 1)
        horizon_residual = self.horizon_head(enc_out).permute(0, 2, 1).to(dec_out.dtype)
        gates = torch.sigmoid(self.horizon_gate).view(1, -1, 1).to(dec_out.dtype)
        dec_out = dec_out.clone()
        dec_out[:, self.horizon_indices, :] = dec_out[:, self.horizon_indices, :] + gates * horizon_residual

        diff_norm = torch.diff(x_norm, dim=1, prepend=x_norm[:, :1, :])
        refine_input = torch.cat([x_norm, diff_norm], dim=-1).permute(0, 2, 1)
        refine_state = self.refine_proj(refine_input)
        for block in self.refine_blocks:
            refine_state = block(refine_state)

        rep_last = refine_state[:, :, -1]
        rep_mean = refine_state.mean(dim=-1)
        rep_max = refine_state.max(dim=-1).values
        rep = torch.cat([rep_last, rep_mean, rep_max], dim=1)

        delta_seq_norm = self.refine_delta_head(rep).to(dec_out.dtype)
        refine_gate = torch.sigmoid(self.refine_gate_head(rep)).to(dec_out.dtype)
        event_logits = self.event_head(rep).view(-1, len(self.horizon_indices), 3).to(dec_out.dtype)

        alt_target_seq = current_target_norm.unsqueeze(1).to(dec_out.dtype) + delta_seq_norm
        target_base_selected = dec_out[:, self.horizon_indices, self.target_feature_idx]
        alt_target_selected = alt_target_seq[:, self.horizon_indices]
        corrected_target = target_base_selected + refine_gate * (alt_target_selected - target_base_selected)
        dec_out[:, self.horizon_indices, self.target_feature_idx] = corrected_target

        target_stdev = stdev[:, 0, self.target_feature_idx].unsqueeze(1)
        delta_seq = delta_seq_norm * target_stdev
        dec_out = dec_out * (stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        dec_out = dec_out + (means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1))
        return {
            "forecast": dec_out,
            "delta_pred_full": delta_seq,
            "event_logits": event_logits,
            "current_target": current_target,
            "refine_gate": refine_gate,
        }

    def forward(
        self,
        x_enc: torch.Tensor,
        x_mark_enc: torch.Tensor,
        x_dec: torch.Tensor,
        x_mark_dec: torch.Tensor,
        mask: torch.Tensor = None,
    ) -> Dict[str, torch.Tensor]:
        if self.task_name in {"long_term_forecast", "short_term_forecast"}:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            dec_out["forecast"] = dec_out["forecast"][:, -self.pred_len:, :]
            return dec_out
        raise NotImplementedError("PatchTSTExtremeRefineModel only supports forecasting tasks")


class DensityAwareExtremeLoss(nn.Module):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
    ):
        super().__init__()
        self.horizon_indices = horizon_indices
        self.low_thresholds = [float(v) for v in low_thresholds]
        self.high_thresholds = [float(v) for v in high_thresholds]
        self.horizon_weights = [float(v) for v in horizon_weights]
        self.low_weights = [float(v) for v in low_weights]
        self.high_weights = [float(v) for v in high_weights]
        self.density_weight_blend = float(density_weight_blend)
        self.register_buffer(
            "density_bin_edges",
            torch.tensor(density_bin_edges, dtype=torch.float32),
        )
        self.register_buffer(
            "density_bin_weights",
            torch.tensor(density_bin_weights, dtype=torch.float32),
        )

    def _density_multiplier(self, horizon_pos: int, horizon_values: torch.Tensor) -> torch.Tensor:
        edges = self.density_bin_edges[horizon_pos]
        rarity = self.density_bin_weights[horizon_pos]
        bin_idx = torch.bucketize(horizon_values, edges[1:-1])
        density_mult = rarity[bin_idx]
        return 1.0 + self.density_weight_blend * (density_mult - 1.0)

    def _build_point_weights(self, true: torch.Tensor) -> torch.Tensor:
        weights = torch.ones_like(true)
        for horizon_pos, (idx, low_thr, high_thr, horizon_w, low_w, high_w) in enumerate(
            zip(
                self.horizon_indices,
                self.low_thresholds,
                self.high_thresholds,
                self.horizon_weights,
                self.low_weights,
                self.high_weights,
            )
        ):
            horizon_true = true[:, idx:idx + 1, :]
            horizon_weights = weights[:, idx:idx + 1, :] * horizon_w
            horizon_weights = torch.where(horizon_true <= low_thr, horizon_weights * low_w, horizon_weights)
            horizon_weights = torch.where(horizon_true >= high_thr, horizon_weights * high_w, horizon_weights)
            density_mult = self._density_multiplier(horizon_pos, horizon_true[:, 0, 0]).view(-1, 1, 1)
            horizon_weights = horizon_weights * density_mult
            weights[:, idx:idx + 1, :] = horizon_weights
        return weights

    def forward(self, pred: torch.Tensor, true: torch.Tensor) -> torch.Tensor:
        sq_err = (pred - true) ** 2
        weights = self._build_point_weights(true)
        weights = weights / weights.mean().clamp_min(1e-6)
        return (sq_err * weights).mean()


class AdaptiveDensityAwareExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        adaptive_extreme_strength: float,
        adaptive_direction_strength: float,
        adaptive_direction_error_power: float,
        adaptive_high_tail_scale: float,
        adaptive_low_tail_scale: float,
        adaptive_max_point_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.adaptive_extreme_strength = float(adaptive_extreme_strength)
        self.adaptive_direction_strength = float(adaptive_direction_strength)
        self.adaptive_direction_error_power = float(adaptive_direction_error_power)
        self.adaptive_high_tail_scale = float(adaptive_high_tail_scale)
        self.adaptive_low_tail_scale = float(adaptive_low_tail_scale)
        self.adaptive_max_point_weight = float(adaptive_max_point_weight)

    def _tail_scales(
        self,
        low_thr: float,
        high_thr: float,
        horizon_true: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        center = 0.5 * (low_thr + high_thr)
        low_scale = max(center - low_thr, 1.0) * self.adaptive_low_tail_scale
        high_scale = max(high_thr - center, 1.0) * self.adaptive_high_tail_scale
        return torch.full_like(horizon_true, low_scale), torch.full_like(horizon_true, high_scale)

    def _build_point_weights_adaptive(self, pred: torch.Tensor, true: torch.Tensor) -> torch.Tensor:
        weights = torch.ones_like(true)
        for horizon_pos, (idx, low_thr, high_thr, horizon_w, low_w, high_w) in enumerate(
            zip(
                self.horizon_indices,
                self.low_thresholds,
                self.high_thresholds,
                self.horizon_weights,
                self.low_weights,
                self.high_weights,
            )
        ):
            horizon_true = true[:, idx:idx + 1, :]
            horizon_pred = pred[:, idx:idx + 1, :]
            horizon_weights_t = weights[:, idx:idx + 1, :] * horizon_w

            low_scale, high_scale = self._tail_scales(low_thr, high_thr, horizon_true)
            low_degree = torch.relu((low_thr - horizon_true) / low_scale)
            high_degree = torch.relu((horizon_true - high_thr) / high_scale)

            low_amp = max(low_w - 1.0, 0.0)
            high_amp = max(1.0 - high_w, 0.0)
            low_tail_weight = 1.0 + low_amp * (1.0 + self.adaptive_extreme_strength * low_degree)
            high_tail_weight = 1.0 + high_amp * (1.0 + self.adaptive_extreme_strength * high_degree)

            over_low = torch.relu((horizon_pred - horizon_true) / low_scale)
            under_high = torch.relu((horizon_true - horizon_pred) / high_scale)
            over_low = torch.pow(over_low, self.adaptive_direction_error_power)
            under_high = torch.pow(under_high, self.adaptive_direction_error_power)

            low_dir_weight = 1.0 + self.adaptive_direction_strength * over_low * (1.0 + low_degree)
            high_dir_weight = 1.0 + self.adaptive_direction_strength * under_high * (1.0 + high_degree)

            low_mask = (horizon_true <= low_thr).to(horizon_true.dtype)
            high_mask = (horizon_true >= high_thr).to(horizon_true.dtype)
            neutral_mask = (1.0 - low_mask - high_mask).clamp_min(0.0)

            adaptive_tail_weight = (
                neutral_mask
                + low_mask * low_tail_weight * low_dir_weight
                + high_mask * high_tail_weight * high_dir_weight
            )

            density_mult = self._density_multiplier(horizon_pos, horizon_true[:, 0, 0]).view(-1, 1, 1)
            horizon_weights_t = horizon_weights_t * adaptive_tail_weight * density_mult
            horizon_weights_t = horizon_weights_t.clamp(max=self.adaptive_max_point_weight)
            weights[:, idx:idx + 1, :] = horizon_weights_t
        return weights

    def forward(self, pred: torch.Tensor, true: torch.Tensor) -> torch.Tensor:
        sq_err = (pred - true) ** 2
        weights = self._build_point_weights_adaptive(pred, true)
        weights = weights / weights.mean().clamp_min(1e-6)
        return (sq_err * weights).mean()


class EventAwareExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        transition_thresholds: List[float],
        event_pos_weights: np.ndarray,
        delta_loss_weight: float,
        event_loss_weight: float,
        transition_weight: float,
        tail_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.delta_loss_weight = float(delta_loss_weight)
        self.event_loss_weight = float(event_loss_weight)
        self.transition_weight = float(transition_weight)
        self.tail_weight = float(tail_weight)
        self.register_buffer(
            "transition_thresholds",
            torch.tensor(transition_thresholds, dtype=torch.float32),
        )
        self.register_buffer(
            "event_pos_weights",
            torch.tensor(event_pos_weights, dtype=torch.float32),
        )

    def forward(self, pred_bundle: Dict[str, torch.Tensor], true: torch.Tensor) -> torch.Tensor:
        forecast = pred_bundle["forecast"]
        current_target = pred_bundle["current_target"]
        delta_pred = pred_bundle["delta_pred"]
        event_logits = pred_bundle["event_logits"]

        base_loss = super().forward(forecast, true)

        delta_targets = []
        event_targets = []
        sample_weights = []
        for horizon_pos, idx in enumerate(self.horizon_indices):
            horizon_true = true[:, idx, 0]
            delta_true = horizon_true - current_target
            low_target = (horizon_true <= self.low_thresholds[horizon_pos]).float()
            high_target = (horizon_true >= self.high_thresholds[horizon_pos]).float()
            transition_target = (delta_true.abs() >= self.transition_thresholds[horizon_pos]).float()

            delta_targets.append(delta_true)
            event_targets.append(torch.stack([low_target, high_target, transition_target], dim=-1))

            tail_target = torch.maximum(low_target, high_target)
            weights = torch.ones_like(delta_true) * self.horizon_weights[horizon_pos]
            weights = weights * (1.0 + self.transition_weight * transition_target + self.tail_weight * tail_target)
            sample_weights.append(weights)

        delta_true = torch.stack(delta_targets, dim=1)
        event_target = torch.stack(event_targets, dim=1)
        sample_weight = torch.stack(sample_weights, dim=1)
        sample_weight = sample_weight / sample_weight.mean().clamp_min(1e-6)

        delta_loss = F.smooth_l1_loss(delta_pred, delta_true, reduction="none")
        delta_loss = (delta_loss * sample_weight).mean()

        pos_weight = self.event_pos_weights.view(1, len(self.horizon_indices), 3)
        event_loss = F.binary_cross_entropy_with_logits(
            event_logits,
            event_target,
            pos_weight=pos_weight,
            reduction="none",
        )
        event_loss = (event_loss * sample_weight.unsqueeze(-1)).mean()

        return base_loss + self.delta_loss_weight * delta_loss + self.event_loss_weight * event_loss


class RefineAwareExtremeLoss(DensityAwareExtremeLoss):
    def __init__(
        self,
        horizon_indices: List[int],
        low_thresholds: List[float],
        high_thresholds: List[float],
        horizon_weights: List[float],
        low_weights: List[float],
        high_weights: List[float],
        density_bin_edges: np.ndarray,
        density_bin_weights: np.ndarray,
        density_weight_blend: float,
        transition_thresholds: List[float],
        full_delta_threshold: float,
        event_pos_weights: np.ndarray,
        delta_loss_weight: float,
        event_loss_weight: float,
        transition_weight: float,
    ):
        super().__init__(
            horizon_indices=horizon_indices,
            low_thresholds=low_thresholds,
            high_thresholds=high_thresholds,
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_bin_edges,
            density_bin_weights=density_bin_weights,
            density_weight_blend=density_weight_blend,
        )
        self.delta_loss_weight = float(delta_loss_weight)
        self.event_loss_weight = float(event_loss_weight)
        self.transition_weight = float(transition_weight)
        self.register_buffer(
            "transition_thresholds",
            torch.tensor(transition_thresholds, dtype=torch.float32),
        )
        self.register_buffer(
            "event_pos_weights",
            torch.tensor(event_pos_weights, dtype=torch.float32),
        )
        self.full_delta_threshold = float(full_delta_threshold)

    def forward(self, pred_bundle: Dict[str, torch.Tensor], true: torch.Tensor) -> torch.Tensor:
        forecast = pred_bundle["forecast"]
        current_target = pred_bundle["current_target"]
        delta_pred_full = pred_bundle["delta_pred_full"]
        event_logits = pred_bundle["event_logits"]

        base_loss = super().forward(forecast, true)

        delta_true_full = true[:, :, 0] - current_target.unsqueeze(1)
        delta_weights = torch.ones_like(delta_true_full)
        delta_weights = torch.where(
            delta_true_full.abs() >= self.full_delta_threshold,
            delta_weights * (1.0 + self.transition_weight),
            delta_weights,
        )
        for horizon_pos, idx in enumerate(self.horizon_indices):
            delta_weights[:, idx] = delta_weights[:, idx] * self.horizon_weights[horizon_pos]
        delta_weights = delta_weights / delta_weights.mean().clamp_min(1e-6)

        delta_loss = F.smooth_l1_loss(delta_pred_full, delta_true_full, reduction="none")
        delta_loss = (delta_loss * delta_weights).mean()

        event_targets = []
        for horizon_pos, idx in enumerate(self.horizon_indices):
            horizon_true = true[:, idx, 0]
            delta_true = delta_true_full[:, idx]
            low_target = (horizon_true <= self.low_thresholds[horizon_pos]).float()
            high_target = (horizon_true >= self.high_thresholds[horizon_pos]).float()
            transition_target = (delta_true.abs() >= self.transition_thresholds[horizon_pos]).float()
            event_targets.append(torch.stack([low_target, high_target, transition_target], dim=-1))
        event_target = torch.stack(event_targets, dim=1)

        pos_weight = self.event_pos_weights.view(1, len(self.horizon_indices), 3)
        event_loss = F.binary_cross_entropy_with_logits(
            event_logits,
            event_target,
            pos_weight=pos_weight,
            reduction="none",
        )
        sample_weight = torch.ones_like(event_target[..., 0])
        for horizon_pos in range(len(self.horizon_indices)):
            sample_weight[:, horizon_pos] = sample_weight[:, horizon_pos] * self.horizon_weights[horizon_pos]
        sample_weight = sample_weight / sample_weight.mean().clamp_min(1e-6)
        event_loss = (event_loss * sample_weight.unsqueeze(-1)).mean()

        return base_loss + self.delta_loss_weight * delta_loss + self.event_loss_weight * event_loss


def load_tslib_time_features(tslib_root: str):
    module_path = os.path.join(tslib_root, "utils", "timefeatures.py")
    if not os.path.isfile(module_path):
        raise FileNotFoundError(f"Official TSLib timefeatures.py not found: {module_path}")

    spec = importlib.util.spec_from_file_location("tslib_timefeatures", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load TSLib timefeatures module from: {module_path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.time_features


TSLIB_TIME_FEATURES = load_tslib_time_features(TSLIB_ROOT)


def load_tslib_symbol(module_rel_path: str, symbol_name: str):
    module_path = os.path.join(TSLIB_ROOT, *module_rel_path.split(".")) + ".py"
    if not os.path.isfile(module_path):
        raise FileNotFoundError(f"Official TSLib module not found: {module_path}")

    cache_key = f"tslib_dynamic_{module_rel_path.replace('.', '_')}"
    if cache_key in sys.modules:
        module = sys.modules[cache_key]
    else:
        spec = importlib.util.spec_from_file_location(cache_key, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Unable to load TSLib module from: {module_path}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        sys.modules[cache_key] = module

    if not hasattr(module, symbol_name):
        raise AttributeError(f"Symbol '{symbol_name}' not found in {module_path}")
    return getattr(module, symbol_name)


# =========================
# 3. Utilities
# =========================
def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def safe_cols(df: pd.DataFrame, cols: List[str]) -> List[str]:
    return [c for c in cols if c in df.columns]


def evaluate_regression(y_true: np.ndarray, y_pred: np.ndarray) -> Tuple[float, float, float]:
    mae = mean_absolute_error(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    return mae, rmse, r2


def safe_regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Tuple[float, float]:
    if len(y_true) == 0:
        return np.nan, np.nan
    mae = mean_absolute_error(y_true, y_pred)
    rmse = math.sqrt(mean_squared_error(y_true, y_pred))
    return mae, rmse


def safe_bias(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    if len(y_true) == 0:
        return np.nan
    return float(np.mean(y_pred - y_true))


def classification_metrics_from_events(y_true_event: np.ndarray, y_pred_event: np.ndarray) -> Dict[str, float]:
    tp = np.sum((y_true_event == 1) & (y_pred_event == 1))
    fp = np.sum((y_true_event == 0) & (y_pred_event == 1))
    fn = np.sum((y_true_event == 1) & (y_pred_event == 0))
    tn = np.sum((y_true_event == 0) & (y_pred_event == 0))

    precision = tp / (tp + fp) if (tp + fp) > 0 else np.nan
    recall = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    if np.isnan(precision) or np.isnan(recall) or (precision + recall) == 0:
        f1 = np.nan
    else:
        f1 = 2 * precision * recall / (precision + recall)

    specificity = tn / (tn + fp) if (tn + fp) > 0 else np.nan
    false_alarm_rate = fp / (tp + fp) if (tp + fp) > 0 else np.nan
    miss_rate = fn / (tp + fn) if (tp + fn) > 0 else np.nan
    csi = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else np.nan
    balanced_accuracy = (
        (recall + specificity) / 2
        if not np.isnan(recall) and not np.isnan(specificity)
        else np.nan
    )
    alarm_rate = (tp + fp) / len(y_pred_event) if len(y_pred_event) > 0 else np.nan
    event_rate = (tp + fn) / len(y_true_event) if len(y_true_event) > 0 else np.nan

    return {
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "specificity": float(specificity),
        "false_alarm_rate": float(false_alarm_rate),
        "miss_rate": float(miss_rate),
        "csi": float(csi),
        "balanced_accuracy": float(balanced_accuracy),
        "alarm_rate": float(alarm_rate),
        "event_rate": float(event_rate),
        "tp": float(tp),
        "fp": float(fp),
        "fn": float(fn),
        "tn": float(tn),
    }


def empty_horizon_diagnostics() -> Dict[str, float]:
    metrics = {
        "mae_low": np.nan,
        "rmse_low": np.nan,
        "mae_high": np.nan,
        "rmse_high": np.nan,
        "bias_low": np.nan,
        "bias_high": np.nan,
        "rmse_delta_top10": np.nan,
        "rmse_delta_top10_persistence": np.nan,
        "n_low": np.nan,
        "n_high": np.nan,
        "n_delta_top10": np.nan,
    }
    cls_names = [
        "precision",
        "recall",
        "f1",
        "specificity",
        "false_alarm_rate",
        "miss_rate",
        "csi",
        "balanced_accuracy",
        "alarm_rate",
        "event_rate",
        "tp",
        "fp",
        "fn",
        "tn",
    ]
    for prefix in ["", "persistence_"]:
        for suffix in ["low", "high"]:
            for name in cls_names:
                metrics[f"{prefix}{name}_{suffix}"] = np.nan
    return metrics


def get_engineering_threshold(horizon: int, threshold_map: Dict[int, float]) -> float:
    value = threshold_map.get(horizon)
    if value is None:
        return np.nan
    return float(value)


def parse_threshold_arg(raw_value: str) -> Dict[int, float]:
    values = [v.strip() for v in str(raw_value).split(",") if v.strip()]
    if len(values) != len(HORIZON_MINS):
        raise ValueError(
            f"Threshold argument must provide {len(HORIZON_MINS)} comma-separated values "
            f"for horizons {HORIZON_MINS}, got: {raw_value}"
        )
    parsed: Dict[int, float] = {}
    for horizon, token in zip(HORIZON_MINS, values):
        if token.lower() in {"none", "nan", ""}:
            parsed[horizon] = None
        else:
            parsed[horizon] = float(token)
    return parsed


def normalize_target_label(value: str) -> str:
    raw = str(value).strip()
    key = raw.lower()
    if key in {"label1", "1", "north", "b", "bei", "beizu", "北组"}:
        return "Label1"
    if key in {"label2", "2", "south", "n", "nan", "nanzu", "南组"}:
        return "Label2"
    if raw in FEATURE_COLS_BY_TARGET:
        return raw
    raise ValueError(f"Unsupported target label: {value}. Use label1 or label2.")


def configure_target(target_label: str) -> None:
    global TARGET_COL, BASE_FEATURE_COLS, SSA_SOURCE_FEATURE_COLS, OUTPUT_NAME_TAG

    target_col = normalize_target_label(target_label)
    TARGET_COL = target_col
    BASE_FEATURE_COLS = list(FEATURE_COLS_BY_TARGET[target_col])
    SSA_SOURCE_FEATURE_COLS = list(SSA_SOURCE_FEATURES_BY_TARGET[target_col])
    OUTPUT_NAME_TAG = OUTPUT_TAG_BY_TARGET[target_col]


def get_experiment_output_dir(model_name: str, random_state: int) -> str:
    output_dir = os.path.join(
        OUTPUT_ROOT,
        OUTPUT_NAME_TAG,
        str(model_name),
        str(int(random_state)),
    )
    os.makedirs(output_dir, exist_ok=True)
    return output_dir


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Official TSLib model comparison with chronological split")
    parser.add_argument("--model-name", default=MODEL_NAME, help="Model name to run, e.g. PatchTST or PatchTSTExtreme")
    parser.add_argument(
        "--target-label",
        "--target-col",
        default=TARGET_COL,
        help="Prediction target: label1/Label1 for north aeration or label2/Label2 for south aeration",
    )
    parser.add_argument("--random-state", type=int, default=RANDOM_STATE, help="Random seed for reproducibility")
    parser.add_argument("--output-tag", default="", help="Optional suffix appended to output filenames")
    parser.add_argument(
        "--decomp-method",
        default="none",
        choices=SUPPORTED_DECOMP_METHODS,
        help="Enable the SSA-Conv-PatchTST pathway and generate auxiliary decomposition features",
    )
    parser.add_argument(
        "--decomp-components",
        type=int,
        default=4,
        help="Reserved compatibility flag for the SSA branch; fixed SSA config will be used",
    )
    parser.add_argument("--ablate-no-ssa", action="store_true", help="Disable SSA auxiliary features in the SSA-Conv-PatchTST branch.")
    parser.add_argument("--ablate-no-conv", action="store_true", help="Disable the local convolution stem in the SSA-Conv-PatchTST branch.")
    parser.add_argument("--use-density-loss", action="store_true", help="Use the density-aware loss in the SSA-Conv-PatchTST branch.")
    parser.add_argument(
        "--engineering-low-thresholds",
        default="",
        help="Comma-separated engineering low thresholds for 30,60,90 min; use none to disable",
    )
    parser.add_argument(
        "--engineering-high-thresholds",
        default="",
        help="Comma-separated engineering high thresholds for 30,60,90 min; use none to disable",
    )
    return parser.parse_args()


def use_ssa_conv_patchtst_branch(args: argparse.Namespace) -> bool:
    model_key = args.model_name.lower().strip()
    decomp_method = args.decomp_method.lower().strip()
    return (
        decomp_method != "none"
        or args.ablate_no_ssa
        or args.ablate_no_conv
        or args.use_density_loss
        or model_key == SSA_CONV_PATCHTST_MODEL_NAME.lower()
    )


def load_ssa_conv_framework_module():
    if not os.path.isfile(SSA_FRAMEWORK_FILE):
        raise FileNotFoundError(
            f"SSA framework file not found: {SSA_FRAMEWORK_FILE}"
        )

    module = sys.modules.get(SSA_FRAMEWORK_MODULE_NAME)
    if module is not None:
        return module

    spec = importlib.util.spec_from_file_location(SSA_FRAMEWORK_MODULE_NAME, SSA_FRAMEWORK_FILE)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load module spec from {SSA_FRAMEWORK_FILE}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[SSA_FRAMEWORK_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


def run_ssa_conv_patchtst_experiment(args: argparse.Namespace) -> None:
    global RANDOM_STATE, ENGINEERING_LOW_THRESHOLDS, ENGINEERING_HIGH_THRESHOLDS

    configure_target(args.target_label)
    RANDOM_STATE = args.random_state
    if args.engineering_low_thresholds.strip():
        ENGINEERING_LOW_THRESHOLDS = parse_threshold_arg(args.engineering_low_thresholds)
    if args.engineering_high_thresholds.strip():
        ENGINEERING_HIGH_THRESHOLDS = parse_threshold_arg(args.engineering_high_thresholds)

    framework = load_ssa_conv_framework_module()
    framework.MODEL_NAME = SSA_CONV_PATCHTST_MODEL_NAME
    framework.RANDOM_STATE = RANDOM_STATE
    framework.TIME_COL = TIME_COL
    framework.TARGET_COL = TARGET_COL
    framework.BASE_FEATURE_COLS = list(BASE_FEATURE_COLS)
    framework.VMD_FEATURE_SOURCE_COLS = list(SSA_SOURCE_FEATURE_COLS)
    framework.HORIZON_MINS = list(HORIZON_STEPS)
    framework.ABLATE_NO_SSA = bool(args.ablate_no_ssa)
    framework.ABLATE_NO_CONV = bool(args.ablate_no_conv)
    framework.ABLATE_NO_ASYM = False
    framework.ABLATE_NO_DENSITY = not bool(args.use_density_loss)
    framework.ABLATE_NO_TRANSITION = False
    framework.USE_DENSITY_LOSS = bool(args.use_density_loss)

    requested_method = args.decomp_method.lower().strip()
    effective_method = "none" if args.ablate_no_ssa else requested_method
    output_tag = args.output_tag.strip() or ("ablate_no_ssa" if args.ablate_no_ssa else effective_method)

    print("=" * 80)
    print(f"{OUTPUT_NAME_TAG} SSA-Conv-PatchTST experiment")
    print("=" * 80)
    print(f"MODEL_NAME: {SSA_CONV_PATCHTST_MODEL_NAME}")
    print(f"DEVICE: {DEVICE}")
    print(f"TSLIB_ROOT: {TSLIB_ROOT}")
    print(f"SSA_FRAMEWORK_FILE: {SSA_FRAMEWORK_FILE}")
    print(f"INPUT_FILE: {INPUT_FILE}")
    print(f"OUTPUT_ROOT: {OUTPUT_ROOT}")
    print(f"TARGET_COL: {TARGET_COL}")
    print(f"BASE_FEATURE_COLS: {BASE_FEATURE_COLS}")
    print(f"SSA_SOURCE_FEATURE_COLS: {SSA_SOURCE_FEATURE_COLS}")
    print(f"HORIZON_MINS: {HORIZON_MINS}")
    print(f"HORIZON_STEPS: {HORIZON_STEPS}")
    print(f"SAMPLE_INTERVAL_MIN: {SAMPLE_INTERVAL_MIN}")
    print(f"SEQ_LEN: {SEQ_LEN}")
    print(f"LABEL_LEN: {LABEL_LEN}")
    print(f"PRED_LEN: {PRED_LEN}")
    print(f"PATCH_LEN: {PATCH_LEN}")
    print(f"BATCH_SIZE: {BATCH_SIZE}")
    print(f"NUM_WORKERS: {NUM_WORKERS}")
    print(f"PIN_MEMORY: {PIN_MEMORY}")
    print(f"USE_AMP: {USE_AMP}")
    print(f"EFFECTIVE_AMP: {framework.amp_enabled_for_model(SSA_CONV_PATCHTST_MODEL_NAME, DEVICE)}")
    print(f"RANDOM_STATE: {RANDOM_STATE}")
    print(f"OUTPUT_TAG: {output_tag or '(none)'}")
    print(f"ENGINEERING_LOW_THRESHOLDS: {ENGINEERING_LOW_THRESHOLDS}")
    print(f"ENGINEERING_HIGH_THRESHOLDS: {ENGINEERING_HIGH_THRESHOLDS}")
    print(f"DECOMP_METHOD: {effective_method}")
    print(
        "BRANCH_SWITCHES: "
        f"no_ssa={args.ablate_no_ssa}, "
        f"no_conv={args.ablate_no_conv}, "
        f"use_density_loss={args.use_density_loss}"
    )

    set_seed(RANDOM_STATE)

    df = pd.read_csv(INPUT_FILE)
    df[TIME_COL] = pd.to_datetime(df[TIME_COL], errors="coerce")
    df = df.dropna(subset=[TIME_COL]).sort_values(TIME_COL).reset_index(drop=True)
    df = df[df[TARGET_COL].notna()].copy().reset_index(drop=True)

    base_feature_cols = safe_cols(df, BASE_FEATURE_COLS)
    if not base_feature_cols:
        raise ValueError("No valid feature columns found.")
    if base_feature_cols[-1] != TARGET_COL:
        raise ValueError("TARGET_COL must be the last feature in BASE_FEATURE_COLS.")

    df[base_feature_cols] = df[base_feature_cols].ffill().bfill()

    decomp_source_cols = safe_cols(df, SSA_SOURCE_FEATURE_COLS)
    decomp_components = 0
    decomp_kwargs: Dict[str, object] = {}
    if effective_method == "ssa":
        decomp_components = int(framework.SSA_FIXED_NUM_COMPONENTS)
        decomp_kwargs = {"window": int(framework.SSA_FIXED_WINDOW)}
        print(
            "SSA_FIXED_CONFIG_INFO: "
            f"using fixed selected best SSA parameters "
            f"num_components={decomp_components}, window={decomp_kwargs['window']}"
        )
    elif effective_method != "none":
        raise ValueError(f"Unsupported decomposition method for this script: {effective_method}")

    df_feat, feature_cols, decomp_cols = framework.add_decomposition_features(
        df_in=df,
        base_feature_cols=base_feature_cols,
        method=effective_method,
        source_cols_override=decomp_source_cols,
        num_components=max(1, decomp_components) if effective_method != "none" else 0,
        alpha=float(framework.VMD_ALPHA),
        decomp_kwargs=decomp_kwargs,
    )
    print(
        "DECOMP_FEATURE_INFO: "
        f"method={effective_method}, "
        f"sources={decomp_source_cols if effective_method != 'none' else []}, "
        f"generated={len(decomp_cols)}, "
        f"total_features={len(feature_cols)}"
    )

    X_seq, Y_seq, X_mark, Y_mark, y_true_seq, t_seq = build_official_seq_dataset(
        df_in=df_feat,
        feature_cols=feature_cols,
        seq_len=SEQ_LEN,
        label_len=LABEL_LEN,
        pred_len=PRED_LEN,
        freq="t",
    )

    n = len(X_seq)
    split_idx = int(n * TRAIN_RATIO)

    X_train, X_test = X_seq[:split_idx], X_seq[split_idx:]
    Y_train, Y_test = Y_seq[:split_idx], Y_seq[split_idx:]
    X_mark_train, X_mark_test = X_mark[:split_idx], X_mark[split_idx:]
    Y_mark_train, Y_mark_test = Y_mark[:split_idx], Y_mark[split_idx:]
    y_true_train, y_true_test = y_true_seq[:split_idx], y_true_seq[split_idx:]
    t_test = t_seq[split_idx:]

    n_features = X_train.shape[2]
    x_scaler = MinMaxScaler()
    x_scaler.fit(X_train.reshape(-1, n_features))

    X_train_scaled = scale_sequence_tensor(X_train, x_scaler)
    X_test_scaled = scale_sequence_tensor(X_test, x_scaler)
    Y_train_scaled = scale_sequence_tensor(Y_train, x_scaler)
    Y_test_scaled = scale_sequence_tensor(Y_test, x_scaler)

    target_idx = feature_cols.index(TARGET_COL)
    selected_horizon_indices = [h - 1 for h in HORIZON_STEPS]

    y_true_train_selected = y_true_train[:, selected_horizon_indices]
    y_true_test_selected = y_true_test[:, selected_horizon_indices]
    y_pred_persistence_selected = np.repeat(
        X_test[:, -1, target_idx][:, None],
        len(HORIZON_MINS),
        axis=1,
    )
    train_low_thresholds = np.quantile(y_true_train_selected, EXTREME_TAIL_QUANTILE, axis=0)
    train_high_thresholds = np.quantile(y_true_train_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0)
    test_low_thresholds = np.quantile(y_true_test_selected, EXTREME_TAIL_QUANTILE, axis=0)
    test_high_thresholds = np.quantile(y_true_test_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0)

    split_val = int(len(X_train_scaled) * 0.9)
    X_tr, X_val = X_train_scaled[:split_val], X_train_scaled[split_val:]
    Y_tr, Y_val = Y_train_scaled[:split_val], Y_train_scaled[split_val:]
    X_mark_tr, X_mark_val = X_mark_train[:split_val], X_mark_train[split_val:]
    Y_mark_tr, Y_mark_val = Y_mark_train[:split_val], Y_mark_train[split_val:]

    train_ds = TensorDataset(
        torch.tensor(X_tr, dtype=torch.float32),
        torch.tensor(Y_tr, dtype=torch.float32),
        torch.tensor(X_mark_tr, dtype=torch.float32),
        torch.tensor(Y_mark_tr, dtype=torch.float32),
    )
    val_ds = TensorDataset(
        torch.tensor(X_val, dtype=torch.float32),
        torch.tensor(Y_val, dtype=torch.float32),
        torch.tensor(X_mark_val, dtype=torch.float32),
        torch.tensor(Y_mark_val, dtype=torch.float32),
    )

    loader_kwargs = {
        "batch_size": BATCH_SIZE,
        "shuffle": False,
        "num_workers": NUM_WORKERS,
        "pin_memory": PIN_MEMORY,
    }
    if NUM_WORKERS > 0:
        loader_kwargs["persistent_workers"] = True

    train_loader = DataLoader(train_ds, **loader_kwargs)
    val_loader = DataLoader(val_ds, **loader_kwargs)

    cfg = framework.Config(
        seq_len=SEQ_LEN,
        label_len=LABEL_LEN,
        pred_len=PRED_LEN,
        patch_len=PATCH_LEN,
        stride=PATCH_LEN,
        enc_in=len(feature_cols),
        dec_in=len(feature_cols),
        c_out=len(feature_cols),
    )
    model = framework.build_model(SSA_CONV_PATCHTST_MODEL_NAME, cfg).to(DEVICE)
    criterion = framework.build_training_criterion(
        SSA_CONV_PATCHTST_MODEL_NAME,
        y_true_train_selected,
        X_train[:, -1, target_idx],
        y_true_train,
    )
    model = framework.train_model(
        model,
        train_loader,
        val_loader,
        cfg,
        SSA_CONV_PATCHTST_MODEL_NAME,
        criterion,
        EPOCHS,
        LR,
        PATIENCE,
        DEVICE,
    )

    y_pred_test_scaled = framework.predict_in_batches(
        model=model,
        X_np=X_test_scaled,
        Y_np=Y_test_scaled,
        X_mark_np=X_mark_test,
        Y_mark_np=Y_mark_test,
        cfg=cfg,
        model_name=SSA_CONV_PATCHTST_MODEL_NAME,
        batch_size=256,
        device=DEVICE,
    )
    y_pred_test_scaled_full = np.asarray(y_pred_test_scaled, dtype=np.float32)
    y_pred_test_full = inverse_target_scale(
        y_pred_test_scaled_full.reshape(-1),
        x_scaler,
        target_idx,
    ).reshape(-1, PRED_LEN)
    y_pred_test_selected = y_pred_test_full[:, selected_horizon_indices]

    summary_rows = []
    diagnostic_rows = []
    for idx, horizon in enumerate(HORIZON_MINS):
        p_mae, p_rmse, p_r2 = evaluate_regression(
            y_true_test_selected[:, idx],
            y_pred_persistence_selected[:, idx],
        )
        m_mae, m_rmse, m_r2 = evaluate_regression(
            y_true_test_selected[:, idx],
            y_pred_test_selected[:, idx],
        )
        summary_rows.append(
            {
                "horizon_min": horizon,
                "model_type": "persistence",
                "mae": p_mae,
                "rmse": p_rmse,
                "r2": p_r2,
            }
        )
        summary_rows.append(
            {
                "horizon_min": horizon,
                "model_type": SSA_CONV_PATCHTST_MODEL_NAME,
                "mae": m_mae,
                "rmse": m_rmse,
                "r2": m_r2,
            }
        )

        train_threshold_metrics = compute_horizon_diagnostics(
            y_true=y_true_test_selected[:, idx],
            y_pred=y_pred_test_selected[:, idx],
            persistence_pred=y_pred_persistence_selected[:, idx],
            baseline_now=X_test[:, -1, target_idx],
            low_threshold=float(train_low_thresholds[idx]),
            high_threshold=float(train_high_thresholds[idx]),
        )
        test_relative_metrics = compute_horizon_diagnostics(
            y_true=y_true_test_selected[:, idx],
            y_pred=y_pred_test_selected[:, idx],
            persistence_pred=y_pred_persistence_selected[:, idx],
            baseline_now=X_test[:, -1, target_idx],
            low_threshold=float(test_low_thresholds[idx]),
            high_threshold=float(test_high_thresholds[idx]),
        )
        eng_low_threshold = get_engineering_threshold(horizon, ENGINEERING_LOW_THRESHOLDS)
        eng_high_threshold = get_engineering_threshold(horizon, ENGINEERING_HIGH_THRESHOLDS)
        if not np.isnan(eng_low_threshold) and not np.isnan(eng_high_threshold):
            engineering_metrics = compute_horizon_diagnostics(
                y_true=y_true_test_selected[:, idx],
                y_pred=y_pred_test_selected[:, idx],
                persistence_pred=y_pred_persistence_selected[:, idx],
                baseline_now=X_test[:, -1, target_idx],
                low_threshold=eng_low_threshold,
                high_threshold=eng_high_threshold,
            )
        else:
            engineering_metrics = empty_horizon_diagnostics()
        diagnostic_rows.append(
            {
                "horizon_min": horizon,
                "model_type": SSA_CONV_PATCHTST_MODEL_NAME,
                "train_low_threshold": float(train_low_thresholds[idx]),
                "train_high_threshold": float(train_high_thresholds[idx]),
                "test_low_threshold": float(test_low_thresholds[idx]),
                "test_high_threshold": float(test_high_thresholds[idx]),
                "eng_low_threshold": eng_low_threshold,
                "eng_high_threshold": eng_high_threshold,
                **prefix_metric_keys(train_threshold_metrics, "trainthr"),
                **prefix_metric_keys(test_relative_metrics, "testrel"),
                **prefix_metric_keys(engineering_metrics, "eng"),
            }
        )

    summary_df = pd.DataFrame(summary_rows)
    diagnostic_df = pd.DataFrame(diagnostic_rows)

    pred_dict = {TIME_COL: pd.to_datetime(t_test)}
    for idx, horizon in enumerate(HORIZON_MINS):
        pred_dict[f"y_true_t{horizon}"] = y_true_test_selected[:, idx]
        pred_dict[f"y_pred_persistence_t{horizon}"] = y_pred_persistence_selected[:, idx]
        pred_dict[f"y_pred_{SSA_CONV_PATCHTST_MODEL_NAME}_scaled_t{horizon}"] = y_pred_test_scaled_full[:, selected_horizon_indices[idx]]
        pred_dict[f"y_pred_{SSA_CONV_PATCHTST_MODEL_NAME}_t{horizon}"] = y_pred_test_selected[:, idx]

    pred_df = pd.DataFrame(pred_dict)

    horizon_tag = "_".join(str(h) for h in HORIZON_MINS)
    output_dir = get_experiment_output_dir("SSA-Conv-PatchTST", RANDOM_STATE)
    file_suffix = f"{OUTPUT_NAME_TAG}_{SSA_CONV_PATCHTST_MODEL_NAME}_seed{RANDOM_STATE}_h{horizon_tag}"
    if output_tag:
        file_suffix = f"{file_suffix}_{output_tag}"
    summary_path = os.path.join(output_dir, f"summary_{file_suffix}.csv")
    diagnostic_path = os.path.join(output_dir, f"diagnostics_{file_suffix}.csv")
    pred_path = os.path.join(output_dir, f"predictions_{file_suffix}.csv")
    summary_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
    diagnostic_df.to_csv(diagnostic_path, index=False, encoding="utf-8-sig")
    pred_df.to_csv(pred_path, index=False, encoding="utf-8-sig")

    print("\n" + "=" * 80)
    print("Results")
    print("=" * 80)
    print(summary_df.to_string(index=False))
    print("\nDiagnostics")
    print("=" * 80)
    print(diagnostic_df.to_string(index=False))
    print(f"\nSaved summary to: {summary_path}")
    print(f"Saved diagnostics to: {diagnostic_path}")
    print(f"Saved predictions to: {pred_path}")


def compute_horizon_diagnostics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    persistence_pred: np.ndarray,
    baseline_now: np.ndarray,
    low_threshold: float,
    high_threshold: float,
    delta_quantile: float = 0.9,
) -> Dict[str, float]:
    metrics: Dict[str, float] = {}

    low_mask = y_true <= low_threshold
    high_mask = y_true >= high_threshold
    delta = y_true - baseline_now
    change_mask = np.abs(delta) >= np.quantile(np.abs(delta), delta_quantile)

    metrics["mae_low"], metrics["rmse_low"] = safe_regression_metrics(y_true[low_mask], y_pred[low_mask])
    metrics["mae_high"], metrics["rmse_high"] = safe_regression_metrics(y_true[high_mask], y_pred[high_mask])
    metrics["bias_low"] = safe_bias(y_true[low_mask], y_pred[low_mask])
    metrics["bias_high"] = safe_bias(y_true[high_mask], y_pred[high_mask])
    _, metrics["rmse_delta_top10"] = safe_regression_metrics(y_true[change_mask], y_pred[change_mask])
    _, metrics["rmse_delta_top10_persistence"] = safe_regression_metrics(
        y_true[change_mask], persistence_pred[change_mask]
    )

    pred_low_event = (y_pred <= low_threshold).astype(int)
    pred_high_event = (y_pred >= high_threshold).astype(int)
    persistence_low_event = (persistence_pred <= low_threshold).astype(int)
    persistence_high_event = (persistence_pred >= high_threshold).astype(int)
    true_low_event = low_mask.astype(int)
    true_high_event = high_mask.astype(int)

    low_cls = classification_metrics_from_events(true_low_event, pred_low_event)
    high_cls = classification_metrics_from_events(true_high_event, pred_high_event)
    low_cls_persist = classification_metrics_from_events(true_low_event, persistence_low_event)
    high_cls_persist = classification_metrics_from_events(true_high_event, persistence_high_event)

    metrics["n_low"] = float(low_mask.sum())
    metrics["n_high"] = float(high_mask.sum())
    metrics["n_delta_top10"] = float(change_mask.sum())

    for key, value in low_cls.items():
        metrics[f"{key}_low"] = value
    for key, value in high_cls.items():
        metrics[f"{key}_high"] = value
    for key, value in low_cls_persist.items():
        metrics[f"persistence_{key}_low"] = value
    for key, value in high_cls_persist.items():
        metrics[f"persistence_{key}_high"] = value

    return metrics


def prefix_metric_keys(metrics: Dict[str, float], prefix: str) -> Dict[str, float]:
    return {f"{prefix}_{k}": v for k, v in metrics.items()}


def build_time_mark_array(ts: pd.Series, freq: str) -> np.ndarray:
    idx = pd.DatetimeIndex(pd.to_datetime(ts))
    return TSLIB_TIME_FEATURES(idx, freq=freq).transpose(1, 0).astype(np.float32)


def inverse_target_scale(values_scaled: np.ndarray, scaler: MinMaxScaler, target_idx: int) -> np.ndarray:
    return (values_scaled - scaler.min_[target_idx]) / scaler.scale_[target_idx]


def scale_sequence_tensor(
    values: np.ndarray,
    scaler: MinMaxScaler,
    chunk_size: int = 512,
) -> np.ndarray:
    num_samples, seq_len, num_features = values.shape
    scaled = np.empty((num_samples, seq_len, num_features), dtype=np.float32)
    chunk_size = max(1, int(chunk_size))

    for start in range(0, num_samples, chunk_size):
        end = min(num_samples, start + chunk_size)
        block = values[start:end].reshape(-1, num_features)
        block_scaled = scaler.transform(block).reshape(end - start, seq_len, num_features)
        scaled[start:end] = block_scaled.astype(np.float32, copy=False)
    return scaled


def build_official_seq_dataset(
    df_in: pd.DataFrame,
    feature_cols: List[str],
    seq_len: int,
    label_len: int,
    pred_len: int,
    freq: str,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    keep_cols = [TIME_COL] + feature_cols
    temp = df_in[keep_cols].dropna().copy().reset_index(drop=True)
    feature_data = temp[feature_cols].to_numpy(dtype=np.float32)
    time_data = pd.to_datetime(temp[TIME_COL]).reset_index(drop=True)
    time_mark = build_time_mark_array(time_data, freq=freq)
    target_idx = feature_cols.index(TARGET_COL)

    X_seq, Y_seq, X_mark, Y_mark, y_true, t_ref = [], [], [], [], [], []
    max_end = len(temp) - pred_len

    for end_idx in range(seq_len - 1, max_end):
        x_start = end_idx - seq_len + 1
        label_start = end_idx - label_len + 1
        future_start = end_idx + 1
        future_end = future_start + pred_len

        enc_x = feature_data[x_start:end_idx + 1]
        enc_mark = time_mark[x_start:end_idx + 1]

        dec_hist = feature_data[label_start:end_idx + 1]
        dec_future = feature_data[future_start:future_end]
        dec_y = np.concatenate([dec_hist, dec_future], axis=0)

        dec_hist_mark = time_mark[label_start:end_idx + 1]
        dec_future_mark = time_mark[future_start:future_end]
        dec_mark = np.concatenate([dec_hist_mark, dec_future_mark], axis=0)

        X_seq.append(enc_x)
        X_mark.append(enc_mark)
        Y_seq.append(dec_y)
        Y_mark.append(dec_mark)
        y_true.append(dec_future[:, target_idx])
        t_ref.append(time_data.iloc[end_idx])

    return (
        np.asarray(X_seq, dtype=np.float32),
        np.asarray(Y_seq, dtype=np.float32),
        np.asarray(X_mark, dtype=np.float32),
        np.asarray(Y_mark, dtype=np.float32),
        np.asarray(y_true, dtype=np.float32),
        np.asarray(t_ref),
    )


def build_density_weight_tables(
    train_targets_selected: np.ndarray,
    num_bins: int,
    smooth_sigma: float,
    rarity_power: float,
) -> Tuple[np.ndarray, np.ndarray]:
    edge_tables = []
    rarity_tables = []

    radius = max(1, int(math.ceil(3 * smooth_sigma)))
    offsets = np.arange(-radius, radius + 1, dtype=np.float32)
    kernel = np.exp(-0.5 * (offsets / smooth_sigma) ** 2)
    kernel = kernel / kernel.sum()

    for col in range(train_targets_selected.shape[1]):
        values = train_targets_selected[:, col].astype(np.float32)
        vmin, vmax = float(values.min()), float(values.max())
        if vmax <= vmin:
            vmax = vmin + 1.0
        edges = np.linspace(vmin, vmax, num_bins + 1, dtype=np.float32)
        hist, _ = np.histogram(values, bins=edges)
        hist = hist.astype(np.float32)
        smooth = np.convolve(hist, kernel, mode="same") + 1e-6
        rarity = np.power(smooth.mean() / smooth, rarity_power).astype(np.float32)
        rarity = rarity / rarity.mean()
        edge_tables.append(edges)
        rarity_tables.append(rarity)

    return np.stack(edge_tables, axis=0), np.stack(rarity_tables, axis=0)


def build_model(model_name: str, configs: Config) -> nn.Module:
    model_key = model_name.lower()
    if model_key not in MODEL_MODULES:
        raise ValueError(f"Unsupported MODEL_NAME: {model_name}")

    if model_key == "patchtstkan":
        return PatchTSTKANModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            target_feature_idx=configs.enc_in - 1,
        )
    if model_key == "patchtstextremerefine":
        return PatchTSTExtremeRefineModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_STEPS],
            target_feature_idx=configs.enc_in - 1,
        )
    if model_key == "patchtstextremeevent":
        return PatchTSTExtremeEventModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_STEPS],
            target_feature_idx=configs.enc_in - 1,
        )
    if model_key in {"patchtsthead", "patchtstheadtail", "patchtstheadhorizon", "patchtstextreme", "patchtstextremeadaptive"}:
        return PatchTSTExtremeModel(
            configs=configs,
            patch_len=configs.patch_len,
            stride=configs.stride,
            horizon_indices=[h - 1 for h in HORIZON_STEPS],
        )
    if model_key == "tcn":
        return TCNForecaster(
            input_dim=configs.enc_in,
            pred_len=configs.pred_len,
            hidden_dim=configs.tcn_hidden_dim,
            num_layers=configs.tcn_num_layers,
            dropout=configs.tcn_dropout,
        )
    if model_key == "nbeatsx":
        return NBeatsXForecaster(
            input_dim=configs.enc_in,
            seq_len=configs.seq_len,
            pred_len=configs.pred_len,
            hidden_dim=configs.nbeats_hidden_dim,
            num_blocks=configs.nbeats_num_blocks,
            num_layers=configs.nbeats_num_layers,
            context_dim=configs.nbeats_context_dim,
            dropout=configs.nbeats_dropout,
            target_feature_idx=configs.enc_in - 1,
        )
    if model_key == "deeparlike":
        return DeepARLikeForecaster(
            input_dim=configs.enc_in,
            pred_len=configs.pred_len,
            hidden_dim=configs.deepar_hidden_dim,
            dropout=configs.deepar_dropout,
            target_feature_idx=configs.enc_in - 1,
            horizon_embed_dim=configs.deepar_horizon_embed_dim,
        )
    if model_key in {"lstm", "gru"}:
        return DirectRNNForecaster(
            input_dim=configs.enc_in,
            pred_len=configs.pred_len,
            hidden_dim=128,
            dense_dim=64,
            dropout=0.1,
            cell_type=model_key,
        )

    module = importlib.import_module(f"models.{MODEL_MODULES[model_key]}")

    if model_key == "patchtst":
        return module.Model(configs, patch_len=configs.patch_len, stride=configs.stride)
    if model_key == "dlinear":
        return module.Model(configs, individual=configs.individual)
    return module.Model(configs)


def build_training_criterion(
    model_name: str,
    train_targets_selected: np.ndarray,
    train_current_targets: np.ndarray,
    train_targets_full: np.ndarray,
) -> nn.Module:
    model_key = model_name.lower()
    if model_key not in {
        "patchtstheadtail",
        "patchtstheadhorizon",
        "patchtstextreme",
        "patchtstextremeadaptive",
        "patchtstextremeevent",
        "patchtstextremerefine",
    }:
        return nn.MSELoss()

    low_thresholds = np.quantile(train_targets_selected, EXTREME_TAIL_QUANTILE, axis=0).astype(np.float32)
    high_thresholds = np.quantile(train_targets_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0).astype(np.float32)

    if model_key == "patchtstheadtail":
        horizon_weights = [UNIFORM_HORIZON_WEIGHT] * len(HORIZON_MINS)
        low_weights = [UNIFORM_LOW_WEIGHT] * len(HORIZON_MINS)
        high_weights = [UNIFORM_HIGH_WEIGHT] * len(HORIZON_MINS)
        density_edges = np.zeros((len(HORIZON_MINS), 2), dtype=np.float32)
        density_weights = np.ones((len(HORIZON_MINS), 1), dtype=np.float32)
        density_blend = 0.0
        mode_name = "uniform_tail"
    elif model_key == "patchtstheadhorizon":
        horizon_weights = EXTREME_HORIZON_WEIGHTS
        low_weights = EXTREME_LOW_WEIGHTS
        high_weights = EXTREME_HIGH_WEIGHTS
        density_edges = np.zeros((len(HORIZON_MINS), 2), dtype=np.float32)
        density_weights = np.ones((len(HORIZON_MINS), 1), dtype=np.float32)
        density_blend = 0.0
        mode_name = "horizon_specific"
    else:
        horizon_weights = EXTREME_HORIZON_WEIGHTS
        low_weights = EXTREME_LOW_WEIGHTS
        high_weights = EXTREME_HIGH_WEIGHTS
        density_edges, density_weights = build_density_weight_tables(
            train_targets_selected=train_targets_selected,
            num_bins=DENSITY_NUM_BINS,
            smooth_sigma=DENSITY_SMOOTH_SIGMA,
            rarity_power=DENSITY_WEIGHT_POWER,
        )
        density_blend = DENSITY_WEIGHT_BLEND
        mode_name = "density_aware"
        if model_key == "patchtstextremeevent":
            mode_name = "density_event_aware"
        elif model_key == "patchtstextremeadaptive":
            mode_name = "density_adaptive"

    horizon_pairs = ", ".join(
        f"h{h}:lw={lw:.2f},hw={hw:.2f},pw={pw:.2f}"
        for h, lw, hw, pw in zip(HORIZON_MINS, low_weights, high_weights, horizon_weights)
    )
    print(
        "EXTREME_LOSS_INFO: "
        f"mode={mode_name}, "
        f"q={EXTREME_TAIL_QUANTILE}, "
        f"low_thr={[round(float(v), 3) for v in low_thresholds]}, "
        f"high_thr={[round(float(v), 3) for v in high_thresholds]}, "
        f"{horizon_pairs}, "
        f"density_bins={DENSITY_NUM_BINS}, sigma={DENSITY_SMOOTH_SIGMA}, "
        f"blend={density_blend}, power={DENSITY_WEIGHT_POWER}"
    )
    if model_key == "patchtstextremeadaptive":
        print(
            "EXTREME_ADAPTIVE_INFO: "
            f"extreme_strength={ADAPTIVE_EXTREME_STRENGTH}, "
            f"direction_strength={ADAPTIVE_DIRECTION_STRENGTH}, "
            f"error_power={ADAPTIVE_DIRECTION_ERROR_POWER}, "
            f"high_tail_scale={ADAPTIVE_HIGH_TAIL_SCALE}, "
            f"low_tail_scale={ADAPTIVE_LOW_TAIL_SCALE}, "
            f"max_point_weight={ADAPTIVE_MAX_POINT_WEIGHT}"
        )
        return AdaptiveDensityAwareExtremeLoss(
            horizon_indices=[h - 1 for h in HORIZON_STEPS],
            low_thresholds=low_thresholds.tolist(),
            high_thresholds=high_thresholds.tolist(),
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_edges,
            density_bin_weights=density_weights,
            density_weight_blend=density_blend,
            adaptive_extreme_strength=ADAPTIVE_EXTREME_STRENGTH,
            adaptive_direction_strength=ADAPTIVE_DIRECTION_STRENGTH,
            adaptive_direction_error_power=ADAPTIVE_DIRECTION_ERROR_POWER,
            adaptive_high_tail_scale=ADAPTIVE_HIGH_TAIL_SCALE,
            adaptive_low_tail_scale=ADAPTIVE_LOW_TAIL_SCALE,
            adaptive_max_point_weight=ADAPTIVE_MAX_POINT_WEIGHT,
        )

    if model_key == "patchtstextremeevent":
        delta_train = train_targets_selected - train_current_targets[:, None]
        transition_thresholds = np.quantile(np.abs(delta_train), TRANSITION_TOP_QUANTILE, axis=0).astype(np.float32)

        low_targets = (train_targets_selected <= low_thresholds[None, :]).astype(np.float32)
        high_targets = (train_targets_selected >= high_thresholds[None, :]).astype(np.float32)
        transition_targets = (np.abs(delta_train) >= transition_thresholds[None, :]).astype(np.float32)
        stacked_targets = np.stack([low_targets, high_targets, transition_targets], axis=-1)
        positive_rate = stacked_targets.mean(axis=0)
        event_pos_weights = (1.0 - positive_rate) / np.clip(positive_rate, 1e-4, None)
        event_pos_weights = np.clip(event_pos_weights, 1.0, 20.0).astype(np.float32)

        print(
            "EXTREME_EVENT_INFO: "
            f"transition_q={TRANSITION_TOP_QUANTILE}, "
            f"transition_thr={[round(float(v), 3) for v in transition_thresholds]}, "
            f"delta_loss_w={EVENT_DELTA_LOSS_WEIGHT}, "
            f"event_bce_w={EVENT_BCE_LOSS_WEIGHT}, "
            f"transition_weight={EVENT_TRANSITION_WEIGHT}, "
            f"tail_weight={EVENT_TAIL_WEIGHT}"
        )
        return EventAwareExtremeLoss(
            horizon_indices=[h - 1 for h in HORIZON_STEPS],
            low_thresholds=low_thresholds.tolist(),
            high_thresholds=high_thresholds.tolist(),
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_edges,
            density_bin_weights=density_weights,
            density_weight_blend=density_blend,
            transition_thresholds=transition_thresholds.tolist(),
            event_pos_weights=event_pos_weights,
            delta_loss_weight=EVENT_DELTA_LOSS_WEIGHT,
            event_loss_weight=EVENT_BCE_LOSS_WEIGHT,
            transition_weight=EVENT_TRANSITION_WEIGHT,
            tail_weight=EVENT_TAIL_WEIGHT,
        )

    if model_key == "patchtstextremerefine":
        delta_train_selected = train_targets_selected - train_current_targets[:, None]
        transition_thresholds = np.quantile(
            np.abs(delta_train_selected),
            TRANSITION_TOP_QUANTILE,
            axis=0,
        ).astype(np.float32)
        delta_train_full = train_targets_full - train_current_targets[:, None]
        full_delta_threshold = float(np.quantile(np.abs(delta_train_full), TRANSITION_TOP_QUANTILE))

        low_targets = (train_targets_selected <= low_thresholds[None, :]).astype(np.float32)
        high_targets = (train_targets_selected >= high_thresholds[None, :]).astype(np.float32)
        transition_targets = (np.abs(delta_train_selected) >= transition_thresholds[None, :]).astype(np.float32)
        stacked_targets = np.stack([low_targets, high_targets, transition_targets], axis=-1)
        positive_rate = stacked_targets.mean(axis=0)
        event_pos_weights = (1.0 - positive_rate) / np.clip(positive_rate, 1e-4, None)
        event_pos_weights = np.clip(event_pos_weights, 1.0, 20.0).astype(np.float32)

        print(
            "EXTREME_REFINE_INFO: "
            f"transition_q={TRANSITION_TOP_QUANTILE}, "
            f"selected_transition_thr={[round(float(v), 3) for v in transition_thresholds]}, "
            f"full_delta_thr={round(full_delta_threshold, 3)}, "
            f"delta_loss_w={REFINE_DELTA_LOSS_WEIGHT}, "
            f"event_loss_w={REFINE_EVENT_LOSS_WEIGHT}, "
            f"transition_weight={REFINE_TRANSITION_WEIGHT}"
        )
        return RefineAwareExtremeLoss(
            horizon_indices=[h - 1 for h in HORIZON_STEPS],
            low_thresholds=low_thresholds.tolist(),
            high_thresholds=high_thresholds.tolist(),
            horizon_weights=horizon_weights,
            low_weights=low_weights,
            high_weights=high_weights,
            density_bin_edges=density_edges,
            density_bin_weights=density_weights,
            density_weight_blend=density_blend,
            transition_thresholds=transition_thresholds.tolist(),
            full_delta_threshold=full_delta_threshold,
            event_pos_weights=event_pos_weights,
            delta_loss_weight=REFINE_DELTA_LOSS_WEIGHT,
            event_loss_weight=REFINE_EVENT_LOSS_WEIGHT,
            transition_weight=REFINE_TRANSITION_WEIGHT,
        )

    return DensityAwareExtremeLoss(
        horizon_indices=[h - 1 for h in HORIZON_STEPS],
        low_thresholds=low_thresholds.tolist(),
        high_thresholds=high_thresholds.tolist(),
        horizon_weights=horizon_weights,
        low_weights=low_weights,
        high_weights=high_weights,
        density_bin_edges=density_edges,
        density_bin_weights=density_weights,
        density_weight_blend=density_blend,
    )


def amp_enabled_for_model(model_name: str, device: str) -> bool:
    return USE_AMP and device.startswith("cuda") and model_name.lower() not in AMP_UNSAFE_MODELS


def extract_forecast_tensor(model_output: torch.Tensor | Dict[str, torch.Tensor]) -> torch.Tensor:
    if isinstance(model_output, dict):
        return model_output["forecast"]
    return model_output


def forward_official(
    model: nn.Module,
    batch_x: torch.Tensor,
    batch_y: torch.Tensor,
    batch_x_mark: torch.Tensor,
    batch_y_mark: torch.Tensor,
    cfg: Config,
) -> Tuple[torch.Tensor, torch.Tensor]:
    true = batch_y[:, -cfg.pred_len:, -1:]

    if isinstance(model, DirectRNNForecaster):
        outputs = model(batch_x, batch_x_mark, None, None)
        pred = outputs[:, -cfg.pred_len:, :]
        return pred, true

    dec_inp = torch.zeros_like(batch_y[:, -cfg.pred_len:, :], device=batch_y.device)
    dec_inp = torch.cat([batch_y[:, :cfg.label_len, :], dec_inp], dim=1)

    outputs = model(batch_x, batch_x_mark, dec_inp, batch_y_mark)
    pred_full = extract_forecast_tensor(outputs)
    f_dim = -1 if cfg.features == "MS" else 0
    pred = pred_full[:, -cfg.pred_len:, f_dim:]
    if isinstance(outputs, dict):
        pred_bundle = dict(outputs)
        pred_bundle["forecast"] = pred
        if "current_target" not in pred_bundle:
            pred_bundle["current_target"] = batch_x[:, -1, -1]
        return pred_bundle, true
    return pred, true


def train_model(
    model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader,
    cfg: Config,
    model_name: str,
    criterion: nn.Module,
    epochs: int,
    lr: float,
    patience: int,
    device: str,
) -> nn.Module:
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=WEIGHT_DECAY)
    amp_enabled = amp_enabled_for_model(model_name, device)
    scaler = torch.cuda.amp.GradScaler(enabled=amp_enabled)

    model.to(device)
    criterion = criterion.to(device)
    best_val = float("inf")
    best_state = None
    wait = 0
    epoch_times = []

    for epoch in range(1, epochs + 1):
        epoch_start = time.perf_counter()
        model.train()
        train_losses = []
        for xb, yb, xb_mark, yb_mark in train_loader:
            xb = xb.to(device, non_blocking=PIN_MEMORY)
            yb = yb.to(device, non_blocking=PIN_MEMORY)
            xb_mark = xb_mark.to(device, non_blocking=PIN_MEMORY)
            yb_mark = yb_mark.to(device, non_blocking=PIN_MEMORY)

            optimizer.zero_grad()
            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled):
                pred, true = forward_official(model, xb, yb, xb_mark, yb_mark, cfg)
                loss = criterion(pred, true)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            train_losses.append(loss.item())

        model.eval()
        val_losses = []
        with torch.no_grad():
            for xb, yb, xb_mark, yb_mark in val_loader:
                xb = xb.to(device, non_blocking=PIN_MEMORY)
                yb = yb.to(device, non_blocking=PIN_MEMORY)
                xb_mark = xb_mark.to(device, non_blocking=PIN_MEMORY)
                yb_mark = yb_mark.to(device, non_blocking=PIN_MEMORY)

                with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled):
                    pred, true = forward_official(model, xb, yb, xb_mark, yb_mark, cfg)
                    loss = criterion(pred, true)
                val_losses.append(loss.item())

        train_loss = float(np.mean(train_losses)) if train_losses else np.nan
        val_loss = float(np.mean(val_losses)) if val_losses else np.nan
        epoch_time = time.perf_counter() - epoch_start
        epoch_times.append(epoch_time)
        print(
            f"Epoch [{epoch}/{epochs}] Train Loss: {train_loss:.6f} | "
            f"Val Loss: {val_loss:.6f} | Epoch Time: {epoch_time:.2f}s ({epoch_time / 60:.2f} min)"
        )

        if val_loss < best_val:
            best_val = val_loss
            best_state = copy.deepcopy(model.state_dict())
            wait = 0
        else:
            wait += 1
            if wait >= patience:
                print(f"Early stopping at epoch {epoch}")
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    if epoch_times:
        total_time = float(sum(epoch_times))
        avg_time = total_time / len(epoch_times)
        print(
            f"Training Time Summary | Total: {total_time:.2f}s ({total_time / 60:.2f} min) | "
            f"Epochs Run: {len(epoch_times)} | Avg/Epoch: {avg_time:.2f}s ({avg_time / 60:.2f} min)"
        )
    return model


def predict_in_batches(
    model: nn.Module,
    X_np: np.ndarray,
    Y_np: np.ndarray,
    X_mark_np: np.ndarray,
    Y_mark_np: np.ndarray,
    cfg: Config,
    model_name: str,
    batch_size: int,
    device: str,
) -> np.ndarray:
    model.eval()
    preds = []
    amp_enabled = amp_enabled_for_model(model_name, device)
    with torch.no_grad():
        for start in range(0, len(X_np), batch_size):
            end = start + batch_size
            xb = torch.tensor(X_np[start:end], dtype=torch.float32, device=device)
            yb = torch.tensor(Y_np[start:end], dtype=torch.float32, device=device)
            xb_mark = torch.tensor(X_mark_np[start:end], dtype=torch.float32, device=device)
            yb_mark = torch.tensor(Y_mark_np[start:end], dtype=torch.float32, device=device)

            with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled):
                pred, _ = forward_official(model, xb, yb, xb_mark, yb_mark, cfg)
            forecast = extract_forecast_tensor(pred)
            preds.append(forecast.detach().cpu().numpy().squeeze(-1))

    return np.concatenate(preds, axis=0)


# =========================
# 4. Main
# =========================
def main() -> None:
    global MODEL_NAME, RANDOM_STATE, ENGINEERING_LOW_THRESHOLDS, ENGINEERING_HIGH_THRESHOLDS
    args = parse_args()
    configure_target(args.target_label)
    if use_ssa_conv_patchtst_branch(args):
        run_ssa_conv_patchtst_experiment(args)
        return

    MODEL_NAME = args.model_name
    RANDOM_STATE = args.random_state
    output_tag = args.output_tag.strip()
    if args.engineering_low_thresholds.strip():
        ENGINEERING_LOW_THRESHOLDS = parse_threshold_arg(args.engineering_low_thresholds)
    if args.engineering_high_thresholds.strip():
        ENGINEERING_HIGH_THRESHOLDS = parse_threshold_arg(args.engineering_high_thresholds)

    print("=" * 80)
    print("Official TSLib model comparison with user's chronological split")
    print("=" * 80)
    print(f"MODEL_NAME: {MODEL_NAME}")
    print(f"DEVICE: {DEVICE}")
    print(f"TSLIB_ROOT: {TSLIB_ROOT}")
    print(f"INPUT_FILE: {INPUT_FILE}")
    print(f"OUTPUT_ROOT: {OUTPUT_ROOT}")
    print(f"TARGET_COL: {TARGET_COL}")
    print(f"HORIZON_MINS: {HORIZON_MINS}")
    print(f"HORIZON_STEPS: {HORIZON_STEPS}")
    print(f"SAMPLE_INTERVAL_MIN: {SAMPLE_INTERVAL_MIN}")
    print(f"SEQ_LEN: {SEQ_LEN}")
    print(f"LABEL_LEN: {LABEL_LEN}")
    print(f"PRED_LEN: {PRED_LEN}")
    print(f"PATCH_LEN: {PATCH_LEN}")
    print(f"BATCH_SIZE: {BATCH_SIZE}")
    print(f"NUM_WORKERS: {NUM_WORKERS}")
    print(f"PIN_MEMORY: {PIN_MEMORY}")
    print(f"USE_AMP: {USE_AMP}")
    print(f"EFFECTIVE_AMP: {amp_enabled_for_model(MODEL_NAME, DEVICE)}")
    print(f"RANDOM_STATE: {RANDOM_STATE}")
    print(f"OUTPUT_TAG: {output_tag or '(none)'}")
    print(f"ENGINEERING_LOW_THRESHOLDS: {ENGINEERING_LOW_THRESHOLDS}")
    print(f"ENGINEERING_HIGH_THRESHOLDS: {ENGINEERING_HIGH_THRESHOLDS}")

    set_seed(RANDOM_STATE)

    df = pd.read_csv(INPUT_FILE)
    df[TIME_COL] = pd.to_datetime(df[TIME_COL], errors="coerce")
    df = df.dropna(subset=[TIME_COL]).sort_values(TIME_COL).reset_index(drop=True)
    df = df[df[TARGET_COL].notna()].copy().reset_index(drop=True)

    feature_cols = safe_cols(df, BASE_FEATURE_COLS)
    if not feature_cols:
        raise ValueError("No valid feature columns found.")
    if feature_cols[-1] != TARGET_COL:
        raise ValueError("TARGET_COL must be the last feature in BASE_FEATURE_COLS.")

    # Public dataset has intermittent sensor gaps; fill only within the labeled subset
    # so the sequence builder can use the full supervised span for Label1.
    df[feature_cols] = df[feature_cols].ffill().bfill()

    X_seq, Y_seq, X_mark, Y_mark, y_true_seq, t_seq = build_official_seq_dataset(
        df_in=df,
        feature_cols=feature_cols,
        seq_len=SEQ_LEN,
        label_len=LABEL_LEN,
        pred_len=PRED_LEN,
        freq="t",
    )

    n = len(X_seq)
    split_idx = int(n * TRAIN_RATIO)

    X_train, X_test = X_seq[:split_idx], X_seq[split_idx:]
    Y_train, Y_test = Y_seq[:split_idx], Y_seq[split_idx:]
    X_mark_train, X_mark_test = X_mark[:split_idx], X_mark[split_idx:]
    Y_mark_train, Y_mark_test = Y_mark[:split_idx], Y_mark[split_idx:]
    y_true_train, y_true_test = y_true_seq[:split_idx], y_true_seq[split_idx:]
    t_test = t_seq[split_idx:]

    n_features = X_train.shape[2]
    x_scaler = MinMaxScaler()
    x_scaler.fit(X_train.reshape(-1, n_features))

    X_train_scaled = scale_sequence_tensor(X_train, x_scaler)
    X_test_scaled = scale_sequence_tensor(X_test, x_scaler)
    Y_train_scaled = scale_sequence_tensor(Y_train, x_scaler)
    Y_test_scaled = scale_sequence_tensor(Y_test, x_scaler)

    target_idx = feature_cols.index(TARGET_COL)
    selected_horizon_indices = [h - 1 for h in HORIZON_STEPS]

    y_true_train_selected = y_true_train[:, selected_horizon_indices]
    y_true_test_selected = y_true_test[:, selected_horizon_indices]
    y_pred_persistence_selected = np.repeat(
        X_test[:, -1, target_idx][:, None],
        len(HORIZON_MINS),
        axis=1,
    )
    train_low_thresholds = np.quantile(y_true_train_selected, EXTREME_TAIL_QUANTILE, axis=0)
    train_high_thresholds = np.quantile(y_true_train_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0)
    test_low_thresholds = np.quantile(y_true_test_selected, EXTREME_TAIL_QUANTILE, axis=0)
    test_high_thresholds = np.quantile(y_true_test_selected, 1.0 - EXTREME_TAIL_QUANTILE, axis=0)

    split_val = int(len(X_train_scaled) * 0.9)
    X_tr, X_val = X_train_scaled[:split_val], X_train_scaled[split_val:]
    Y_tr, Y_val = Y_train_scaled[:split_val], Y_train_scaled[split_val:]
    X_mark_tr, X_mark_val = X_mark_train[:split_val], X_mark_train[split_val:]
    Y_mark_tr, Y_mark_val = Y_mark_train[:split_val], Y_mark_train[split_val:]

    train_ds = TensorDataset(
        torch.tensor(X_tr, dtype=torch.float32),
        torch.tensor(Y_tr, dtype=torch.float32),
        torch.tensor(X_mark_tr, dtype=torch.float32),
        torch.tensor(Y_mark_tr, dtype=torch.float32),
    )
    val_ds = TensorDataset(
        torch.tensor(X_val, dtype=torch.float32),
        torch.tensor(Y_val, dtype=torch.float32),
        torch.tensor(X_mark_val, dtype=torch.float32),
        torch.tensor(Y_mark_val, dtype=torch.float32),
    )

    loader_kwargs = {
        "batch_size": BATCH_SIZE,
        "shuffle": False,
        "num_workers": NUM_WORKERS,
        "pin_memory": PIN_MEMORY,
    }
    if NUM_WORKERS > 0:
        loader_kwargs["persistent_workers"] = True

    train_loader = DataLoader(train_ds, **loader_kwargs)
    val_loader = DataLoader(val_ds, **loader_kwargs)

    cfg = Config(
        enc_in=len(feature_cols),
        dec_in=len(feature_cols),
        c_out=len(feature_cols),
    )
    model = build_model(MODEL_NAME, cfg)
    model = model.to(DEVICE)
    criterion = build_training_criterion(
        MODEL_NAME,
        y_true_train_selected,
        X_train[:, -1, target_idx],
        y_true_train,
    )
    model = train_model(model, train_loader, val_loader, cfg, MODEL_NAME, criterion, EPOCHS, LR, PATIENCE, DEVICE)

    y_pred_test_scaled = predict_in_batches(
        model=model,
        X_np=X_test_scaled,
        Y_np=Y_test_scaled,
        X_mark_np=X_mark_test,
        Y_mark_np=Y_mark_test,
        cfg=cfg,
        model_name=MODEL_NAME,
        batch_size=256,
        device=DEVICE,
    )
    y_pred_test_scaled_full = np.asarray(y_pred_test_scaled, dtype=np.float32)
    y_pred_test_full = inverse_target_scale(
        y_pred_test_scaled_full.reshape(-1),
        x_scaler,
        target_idx,
    ).reshape(-1, PRED_LEN)
    y_pred_test_selected = y_pred_test_full[:, selected_horizon_indices]

    summary_rows = []
    diagnostic_rows = []
    for idx, horizon in enumerate(HORIZON_MINS):
        p_mae, p_rmse, p_r2 = evaluate_regression(
            y_true_test_selected[:, idx],
            y_pred_persistence_selected[:, idx],
        )
        m_mae, m_rmse, m_r2 = evaluate_regression(
            y_true_test_selected[:, idx],
            y_pred_test_selected[:, idx],
        )
        summary_rows.append(
            {
                "horizon_min": horizon,
                "model_type": "persistence",
                "mae": p_mae,
                "rmse": p_rmse,
                "r2": p_r2,
            }
        )
        summary_rows.append(
            {
                "horizon_min": horizon,
                "model_type": MODEL_NAME,
                "mae": m_mae,
                "rmse": m_rmse,
                "r2": m_r2,
            }
        )

        train_threshold_metrics = compute_horizon_diagnostics(
            y_true=y_true_test_selected[:, idx],
            y_pred=y_pred_test_selected[:, idx],
            persistence_pred=y_pred_persistence_selected[:, idx],
            baseline_now=X_test[:, -1, target_idx],
            low_threshold=float(train_low_thresholds[idx]),
            high_threshold=float(train_high_thresholds[idx]),
        )
        test_relative_metrics = compute_horizon_diagnostics(
            y_true=y_true_test_selected[:, idx],
            y_pred=y_pred_test_selected[:, idx],
            persistence_pred=y_pred_persistence_selected[:, idx],
            baseline_now=X_test[:, -1, target_idx],
            low_threshold=float(test_low_thresholds[idx]),
            high_threshold=float(test_high_thresholds[idx]),
        )
        eng_low_threshold = get_engineering_threshold(horizon, ENGINEERING_LOW_THRESHOLDS)
        eng_high_threshold = get_engineering_threshold(horizon, ENGINEERING_HIGH_THRESHOLDS)
        if not np.isnan(eng_low_threshold) and not np.isnan(eng_high_threshold):
            engineering_metrics = compute_horizon_diagnostics(
                y_true=y_true_test_selected[:, idx],
                y_pred=y_pred_test_selected[:, idx],
                persistence_pred=y_pred_persistence_selected[:, idx],
                baseline_now=X_test[:, -1, target_idx],
                low_threshold=eng_low_threshold,
                high_threshold=eng_high_threshold,
            )
        else:
            engineering_metrics = empty_horizon_diagnostics()
        diagnostic_rows.append(
            {
                "horizon_min": horizon,
                "model_type": MODEL_NAME,
                "train_low_threshold": float(train_low_thresholds[idx]),
                "train_high_threshold": float(train_high_thresholds[idx]),
                "test_low_threshold": float(test_low_thresholds[idx]),
                "test_high_threshold": float(test_high_thresholds[idx]),
                "eng_low_threshold": eng_low_threshold,
                "eng_high_threshold": eng_high_threshold,
                **prefix_metric_keys(train_threshold_metrics, "trainthr"),
                **prefix_metric_keys(test_relative_metrics, "testrel"),
                **prefix_metric_keys(engineering_metrics, "eng"),
            }
        )

    summary_df = pd.DataFrame(summary_rows)
    diagnostic_df = pd.DataFrame(diagnostic_rows)

    pred_dict = {TIME_COL: pd.to_datetime(t_test)}
    for idx, horizon in enumerate(HORIZON_MINS):
        pred_dict[f"y_true_t{horizon}"] = y_true_test_selected[:, idx]
        pred_dict[f"y_pred_persistence_t{horizon}"] = y_pred_persistence_selected[:, idx]
        pred_dict[f"y_pred_{MODEL_NAME}_scaled_t{horizon}"] = y_pred_test_scaled_full[:, selected_horizon_indices[idx]]
        pred_dict[f"y_pred_{MODEL_NAME}_t{horizon}"] = y_pred_test_selected[:, idx]

    pred_df = pd.DataFrame(pred_dict)

    horizon_tag = "_".join(str(h) for h in HORIZON_MINS)
    output_dir = get_experiment_output_dir(MODEL_NAME, RANDOM_STATE)
    file_suffix = f"{OUTPUT_NAME_TAG}_{MODEL_NAME}_seed{RANDOM_STATE}_h{horizon_tag}"
    if output_tag:
        file_suffix = f"{file_suffix}_{output_tag}"
    summary_path = os.path.join(output_dir, f"summary_{file_suffix}.csv")
    diagnostic_path = os.path.join(output_dir, f"diagnostics_{file_suffix}.csv")
    pred_path = os.path.join(output_dir, f"predictions_{file_suffix}.csv")
    summary_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
    diagnostic_df.to_csv(diagnostic_path, index=False, encoding="utf-8-sig")
    pred_df.to_csv(pred_path, index=False, encoding="utf-8-sig")

    print("\n" + "=" * 80)
    print("Results")
    print("=" * 80)
    print(summary_df.to_string(index=False))
    print("\nDiagnostics")
    print("=" * 80)
    print(diagnostic_df.to_string(index=False))
    print(f"\nSaved summary to: {summary_path}")
    print(f"Saved diagnostics to: {diagnostic_path}")
    print(f"Saved predictions to: {pred_path}")


if __name__ == "__main__":
    main()
