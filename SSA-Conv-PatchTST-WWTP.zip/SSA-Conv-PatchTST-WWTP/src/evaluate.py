# -*- coding: utf-8 -*-
"""Print compact summaries of released result CSV files."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[1]
RESULT_FILES = [
    REPO_ROOT / "results" / "main_results.csv",
    REPO_ROOT / "results" / "external_validation.csv",
    REPO_ROOT / "results" / "efficiency_results.csv",
]


def read_csv_flexible(path: Path) -> pd.DataFrame:
    for encoding in ("utf-8-sig", "utf-8", "gbk", "gb18030"):
        try:
            return pd.read_csv(path, encoding=encoding)
        except UnicodeDecodeError:
            continue
    return pd.read_csv(path, encoding="latin1")


def main() -> None:
    for path in RESULT_FILES:
        if not path.exists():
            print(f"Missing: {path}")
            continue
        df = read_csv_flexible(path)
        print(f"\n{path.relative_to(REPO_ROOT)}")
        print(df.head(12).to_string(index=False))


if __name__ == "__main__":
    main()
