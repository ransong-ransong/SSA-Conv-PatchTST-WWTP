# -*- coding: utf-8 -*-
"""Basic preprocessing utility for the main WWTP dataset.

The manuscript experiments use the processed CSV already included in
`data/processed/`. This script documents and reproduces the lightweight
chronological sorting and forward-fill workflow when starting from the raw CSV.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RAW = REPO_ROOT / "data" / "raw" / "device_data_wide_final_1min1.csv"
DEFAULT_OUTPUT = REPO_ROOT / "data" / "processed" / "device_data_wide_final_1min1_filtered_ffill.csv"


def preprocess(input_file: Path, output_file: Path) -> None:
    df = pd.read_csv(input_file)
    if "sample_time" in df.columns:
        df["sample_time"] = pd.to_datetime(df["sample_time"], errors="coerce")
        df = df.sort_values("sample_time").reset_index(drop=True)
    df = df.ffill().bfill()
    output_file.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_file, index=False, encoding="utf-8-sig")


def main() -> None:
    parser = argparse.ArgumentParser(description="Preprocess the WWTP raw dataset")
    parser.add_argument("--input-file", default=str(DEFAULT_RAW))
    parser.add_argument("--output-file", default=str(DEFAULT_OUTPUT))
    args = parser.parse_args()
    preprocess(Path(args.input_file), Path(args.output_file))


if __name__ == "__main__":
    main()

