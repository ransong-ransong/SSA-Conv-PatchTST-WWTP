$ErrorActionPreference = "Stop"

$seeds = @(7, 17, 27, 37, 47)
$baselines = @("PatchTST", "TimeXer", "TiDE", "iTransformer", "DLinear", "SCINet", "Crossformer", "GRU", "LSTM")

foreach ($seed in $seeds) {
    python src/train.py --mode ssa --model-name SSA-Conv-PatchTST --decomp-method ssa --ssa-window 120 --ssa-components 4 --random-state $seed
    foreach ($model in $baselines) {
        python src/train.py --mode baseline --model-name $model --random-state $seed
    }
}
