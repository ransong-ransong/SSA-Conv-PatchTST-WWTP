#!/usr/bin/env bash
set -euo pipefail

SEEDS=(7 17 27 37 47)
BASELINES=(PatchTST TimeXer TiDE iTransformer DLinear SCINet Crossformer GRU LSTM)

for seed in "${SEEDS[@]}"; do
  python src/train.py --mode ssa --model-name SSA-Conv-PatchTST --decomp-method ssa --ssa-window 120 --ssa-components 4 --random-state "$seed"
  for model in "${BASELINES[@]}"; do
    python src/train.py --mode baseline --model-name "$model" --random-state "$seed"
  done
done
