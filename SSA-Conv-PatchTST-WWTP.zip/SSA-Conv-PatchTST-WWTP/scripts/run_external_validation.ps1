$ErrorActionPreference = "Stop"

$seeds = @(7, 17, 27, 37, 47)
$targets = @("label1", "label2")

foreach ($seed in $seeds) {
    foreach ($target in $targets) {
        python src/train.py --mode external --model-name SSA-Conv-PatchTST --target-label $target --decomp-method ssa --random-state $seed
    }
}
