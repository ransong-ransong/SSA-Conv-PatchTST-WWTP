#!/usr/bin/env bash
set -euo pipefail

SEEDS=(7 17 27 37 47)
TARGETS=(label1 label2)

for seed in "${SEEDS[@]}"; do
  for target in "${TARGETS[@]}"; do
    python src/train.py --mode external --model-name SSA-Conv-PatchTST --target-label "$target" --decomp-method ssa --random-state "$seed"
  done
done
